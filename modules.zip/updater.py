# -*- coding: utf-8 -*-
"""線上更新（GitHub Releases）。與視窗無關，方便測試。
流程：查最新 Release → 比對版本 → 下載新的 EXE → 關閉本程式 → 小批次檔換檔並重開。"""
import hashlib
import json
import os
import re
import subprocess
import sys
import tempfile
import urllib.request

API = 'https://api.github.com'
UA = 'bridge-toolbox-updater'


def parse_version(v):
    """'v1.3.4' -> (1,3,4)；解析不了回傳 None"""
    m = re.search(r'(\d+)\.(\d+)(?:\.(\d+))?', v or '')
    if not m:
        return None
    return tuple(int(x or 0) for x in m.groups())


def read_repo(dirs):
    """更新來源：在這些資料夾裡找 update_repo.txt（第一行 帳號/專案名，例如 abc123/bridge-toolbox）"""
    for d in dirs:
        if not d:
            continue
        p = os.path.join(d, 'update_repo.txt')
        if os.path.exists(p):
            try:
                t = open(p, encoding='utf-8-sig').read().strip().splitlines()[0].strip()
                if re.fullmatch(r'[\w.\-]+/[\w.\-]+', t):
                    return t
            except Exception:
                pass
    return ''


def check(repo, current, timeout=10, api=API):
    """有新版本就回傳 dict(version, tag, notes, url, name, size, sha256, page)；沒有或失敗回傳 None"""
    if not repo:
        return None
    req = urllib.request.Request('%s/repos/%s/releases/latest' % (api, repo),
                                 headers={'User-Agent': UA, 'Accept': 'application/vnd.github+json'})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        j = json.loads(r.read().decode('utf8'))
    latest, cur = parse_version(j.get('tag_name')), parse_version(current)
    if not latest or not cur or latest <= cur:
        return None
    asset = None
    for a in j.get('assets', []):
        if a.get('name', '').lower().endswith('.exe'):
            asset = a
            break
    sha = ''
    if asset and str(asset.get('digest', '')).startswith('sha256:'):
        sha = asset['digest'][7:]
    return dict(version='.'.join(map(str, latest)), tag=j.get('tag_name'), notes=(j.get('body') or '').strip(),
                url=asset['browser_download_url'] if asset else '', name=asset['name'] if asset else '',
                size=asset.get('size', 0) if asset else 0, sha256=sha, page=j.get('html_url', ''))


def download(url, dest, progress=None, cancel=None, sha256='', timeout=30):
    req = urllib.request.Request(url, headers={'User-Agent': UA})
    h = hashlib.sha256()
    with urllib.request.urlopen(req, timeout=timeout) as r, open(dest, 'wb') as f:
        total = int(r.headers.get('Content-Length') or 0)
        got = 0
        while True:
            if cancel is not None and cancel():
                raise RuntimeError('已取消')
            b = r.read(1 << 16)
            if not b:
                break
            f.write(b)
            h.update(b)
            got += len(b)
            if progress and total:
                progress(got / total)
    if total and got != total:
        raise RuntimeError('下載不完整')
    if sha256 and h.hexdigest().lower() != sha256.lower():
        raise RuntimeError('檔案檢查碼不符，已放棄更新')
    with open(dest, 'rb') as f:
        if f.read(2) != b'MZ':
            raise RuntimeError('下載的不是可執行檔')
    return dest


def is_frozen():
    return bool(getattr(sys, 'frozen', False))


def apply_update(new_exe, cur_exe=None):
    """用隱藏的 PowerShell 等本程式結束 → 換檔 → 重開。呼叫後請立刻結束程式。
    路徑用環境變數傳（避免批次檔處理中文路徑出錯），腳本本身只有英文。"""
    cur_exe = cur_exe or sys.executable
    script = ("$c=$env:TB_CUR;$n=$env:TB_NEW;$ok=$false;"
              "for($i=0;$i -lt 120;$i++){try{Move-Item -LiteralPath $n -Destination $c -Force -ErrorAction Stop;"
              "$ok=$true;break}catch{Start-Sleep -Milliseconds 700}};"
              "Start-Process -FilePath $c")
    env = {k: v for k, v in os.environ.items() if not (k.startswith('_MEI') or k.startswith('_PYI'))}
    env['TB_CUR'] = cur_exe
    env['TB_NEW'] = new_exe
    flags = getattr(subprocess, 'CREATE_NO_WINDOW', 0) | getattr(subprocess, 'CREATE_NEW_PROCESS_GROUP', 0)
    subprocess.Popen(['powershell', '-NoProfile', '-NonInteractive', '-WindowStyle', 'Hidden',
                      '-ExecutionPolicy', 'Bypass', '-Command', script],
                     env=env, creationflags=flags, close_fds=True)


# ======================================================================
# 程式碼更新（v1.8.0 起）：只下載一個小 zip（.py 檔），放進使用者資料夾，下次啟動優先載入。
# EXE 本身不用換。來源：repo 的 main 分支根目錄 version.json + modules.zip
# ======================================================================
import shutil
import zipfile

SHELL_API = 1          # 外殼（EXE 裡的 launcher）版本；新程式碼需要更新的外殼時，version.json 的 "shell" 會比它大
RAW = 'https://raw.githubusercontent.com'


def data_root():
    base = os.environ.get('LOCALAPPDATA') or os.path.expanduser('~')
    return os.path.join(base, '橋梁檢測工具箱')


def module_dir():
    return os.path.join(data_root(), '模組')


def check_modules(repo, current, timeout=10, raw=RAW):
    """查 repo 的 version.json。回傳 None（已是最新／沒來源），或 dict：
    kind='modules'（可程式碼更新）或 kind='exe'（需要新的 EXE）"""
    if not repo:
        return None
    req = urllib.request.Request('%s/%s/main/version.json?t=%d' % (raw, repo, int(__import__('time').time())),
                                 headers={'User-Agent': UA, 'Cache-Control': 'no-cache'})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        j = json.loads(r.read().decode('utf-8-sig'))
    latest, cur = parse_version(j.get('version')), parse_version(current)
    if not latest or not cur or latest <= cur:
        return None
    need_shell = int(j.get('shell', 1) or 1)
    return dict(kind='modules' if need_shell <= SHELL_API else 'exe', version='.'.join(map(str, latest)),
                notes=(j.get('notes') or '').strip(), sha256=j.get('sha256', ''), size=int(j.get('size', 0) or 0),
                url='%s/%s/main/%s' % (raw, repo, j.get('zip', 'modules.zip')), repo=repo)


def _safe_members(z):
    names = z.namelist()
    for n in names:
        if n.endswith('/'):
            continue
        if '/' in n or '\\' in n or n.startswith('.') or not n.lower().endswith(('.py', '.json', '.txt', '.ico')):
            raise RuntimeError('更新包內容不合規定：%s' % n)
    if 'toolbox.py' not in names or 'version.json' not in names:
        raise RuntimeError('更新包缺少 toolbox.py 或 version.json')
    return [n for n in names if not n.endswith('/')]


def apply_modules(info, progress=None, cancel=None, dest_root=None):
    """下載 → 驗證 → 解開到暫存 → 換掉『模組』資料夾。成功後請重新啟動程式。"""
    root = dest_root or data_root()
    os.makedirs(root, exist_ok=True)
    tmp_zip = os.path.join(root, 'modules.download')
    new_dir, mod, old = [os.path.join(root, n) for n in ('模組.new', '模組', '模組.old')]
    try:
        download_any(info['url'], tmp_zip, progress, cancel, info.get('sha256', ''))
    except Exception:
        try:
            os.remove(tmp_zip)
        except OSError:
            pass
        raise
    try:
        with zipfile.ZipFile(tmp_zip) as z:
            members = _safe_members(z)
            shutil.rmtree(new_dir, ignore_errors=True)
            os.makedirs(new_dir)
            for n in members:
                with open(os.path.join(new_dir, n), 'wb') as f:
                    f.write(z.read(n))
        for n in members:      # 語法檢查：壞檔不換
            if n.endswith('.py'):
                compile(open(os.path.join(new_dir, n), 'rb').read(), n, 'exec')
        v = json.load(open(os.path.join(new_dir, 'version.json'), encoding='utf-8-sig')).get('version')
        if parse_version(v) != parse_version(info['version']):
            raise RuntimeError('更新包版本（%s）與預期（%s）不符，稍後再試' % (v, info['version']))
    except Exception:
        shutil.rmtree(new_dir, ignore_errors=True)
        raise
    finally:
        try:
            os.remove(tmp_zip)
        except OSError:
            pass
    shutil.rmtree(old, ignore_errors=True)
    if os.path.isdir(mod):
        os.replace(mod, old)
    os.replace(new_dir, mod)
    shutil.rmtree(old, ignore_errors=True)
    return mod


def download_any(url, dest, progress=None, cancel=None, sha256='', timeout=30):
    req = urllib.request.Request(url, headers={'User-Agent': UA, 'Cache-Control': 'no-cache'})
    h = hashlib.sha256()
    with urllib.request.urlopen(req, timeout=timeout) as r, open(dest, 'wb') as f:
        total = int(r.headers.get('Content-Length') or 0)
        got = 0
        while True:
            if cancel is not None and cancel():
                raise RuntimeError('已取消')
            b = r.read(1 << 16)
            if not b:
                break
            f.write(b)
            h.update(b)
            got += len(b)
            if progress and total:
                progress(got / total)
    if sha256 and h.hexdigest().lower() != sha256.lower():
        raise RuntimeError('更新包檢查碼不符（可能剛上傳還沒同步），請幾分鐘後再按「檢查更新」')
    return dest


def relaunch():
    """等本程式結束後重新開啟自己（隱藏的 PowerShell）。呼叫後請立刻結束程式。"""
    cmd = [sys.executable] if is_frozen() else [sys.executable, os.path.abspath(sys.argv[0])]
    script = ("Start-Sleep -Milliseconds 1500; if($env:TB_ARGS){Start-Process -FilePath $env:TB_CUR -ArgumentList $env:TB_ARGS}"
              "else{Start-Process -FilePath $env:TB_CUR}")
    env = {k: v for k, v in os.environ.items() if not (k.startswith('_MEI') or k.startswith('_PYI'))}
    env['TB_CUR'] = cmd[0]
    env['TB_ARGS'] = ('"%s"' % cmd[1]) if len(cmd) > 1 else ''
    flags = getattr(subprocess, 'CREATE_NO_WINDOW', 0) | getattr(subprocess, 'CREATE_NEW_PROCESS_GROUP', 0)
    if os.name == 'nt':
        subprocess.Popen(['powershell', '-NoProfile', '-NonInteractive', '-WindowStyle', 'Hidden',
                          '-ExecutionPolicy', 'Bypass', '-Command', script], env=env, creationflags=flags, close_fds=True)
    else:
        subprocess.Popen(cmd, env=env, close_fds=True)
