# -*- coding: utf-8 -*-
"""
橋梁定期檢測表整理工具
功能：
  1. 刪除 D=1（無損傷）與 E=0 的缺失頁（前面的彙總表一律保留）
  2. 每個缺失只留「位置圖＋遠＋近」兩張照片（自動刪除平板拍的大範圍照片）
  3. 缺失依橋梁位置排序（ASP 交錯 / PS 交錯 / 不排序）
  4. 每頁固定 N 個缺失（預設 3）
  5. 清掉不再使用的圖片，檔案變小；檔名不變，輸出到「整理後」資料夾

需求：Python 3.8+，套件 lxml（pip install lxml）
用法：雙擊「執行.bat」開啟視窗；或命令列
      python bridge_tidy.py 檔案1.docx 檔案2.docx --sort ASP
"""
import argparse
import copy
import os
import re
import sys
import threading
import zipfile
from collections import Counter

from lxml import etree

NS = {
    'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main',
    'a': 'http://schemas.openxmlformats.org/drawingml/2006/main',
    'r': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships',
    'wp': 'http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing',
    'v': 'urn:schemas-microsoft-com:vml',
}
W = '{%s}' % NS['w']
R = '{%s}' % NS['r']
REL_NS = 'http://schemas.openxmlformats.org/package/2006/relationships'


def txt(e):
    return ''.join(e.itertext()).strip()


# ----------------------------------------------------------------------------
# 表格辨識
# ----------------------------------------------------------------------------
def is_defect_table(tbl):
    """缺失表：7 列，第一列為 檢測項目/位置/編號/D/E/R/U ..."""
    rs = tbl.findall('w:tr', NS)
    if len(rs) != 7:
        return False
    h = [txt(c) for c in rs[0].findall('w:tc', NS)]
    return len(h) >= 5 and h[0] == '檢測項目' and 'D' in h and 'E' in h


def is_summary_table(tbl):
    """彙總表：第一列「檢測項目xxx」，第二列為欄位名稱（含 D、E）"""
    rs = tbl.findall('w:tr', NS)
    if len(rs) < 3 or is_defect_table(tbl):
        return False
    if not txt(rs[0]).startswith('檢測項目'):
        return False
    h = [txt(c) for c in rs[1].findall('w:tc', NS)]
    return 'D' in h and 'E' in h


def no_damage(vals, di, ei):
    d = vals[di] if len(vals) > di else ''
    e = vals[ei] if len(vals) > ei else ''
    return d == '1' or e == '0'


OPS = {
    '=': lambda a, b: a == b, '>=': lambda a, b: a >= b, '<=': lambda a, b: a <= b,
    '>': lambda a, b: a > b, '<': lambda a, b: a < b,
}


def parse_conds(texts):
    """['D>=2', 'R=3'] -> [('D','>=',2), ('R','=',3)]"""
    out = []
    for t in texts:
        m = re.match(r'^\s*([DERUdeur])\s*(>=|<=|=|>|<)\s*(\d+)\s*$', t)
        if not m:
            raise ValueError('條件格式錯誤：%s（例如 D>=2）' % t)
        out.append((m.group(1).upper(), m.group(2), int(m.group(3))))
    return out


def match_conds(get, conds, match):
    """get(field)->字串。空白視為不符合。match: 'any'（任一）或 'all'（全部）"""
    if not conds:
        return True
    res = []
    for f, op, n in conds:
        v = get(f).strip()
        res.append(v.isdigit() and OPS[op](int(v), n))
    return any(res) if match == 'any' else all(res)


def remove_with_spacer(tbl):
    nxt = tbl.getnext()
    par = tbl.getparent()
    par.remove(tbl)
    if (nxt is not None and etree.QName(nxt).localname == 'p' and txt(nxt) == ''
            and nxt.find('.//w:br', NS) is None and nxt.find('.//w:sectPr', NS) is None):
        par.remove(nxt)


# ----------------------------------------------------------------------------
# 排序
# ----------------------------------------------------------------------------
def location_key(cells):
    """回傳 (字母, 編號)，例如 ('P', 3)；無法辨識回傳 None"""
    comp = cells[0]
    c1 = cells[1] if len(cells) > 1 else ''
    c2 = cells[2] if len(cells) > 2 else ''
    dl = cells[7] if len(cells) > 7 else ''
    try:
        if comp in ('橋梁排水設施', '橋護欄'):
            m = re.search(r'(\d*)S(\d*)', dl)
            if m:
                return 'S', int(m.group(1) or m.group(2))
            return None
        if comp in ('伸縮縫', '防落設施', '支承／支承墊／阻尼裝置'):
            if '橋台' in c1:
                n = re.sub(r'\D', '', c2)
                m = re.search(r'[Aa]0*(\d+)', dl)
                return 'A', int(n or (m.group(1) if m else 0))
            n = re.sub(r'\D', '', c2)
            if n:
                return 'P', int(n)
            return None
        m = re.match(r'([aApPsS])0*(\d+)', c1)
        if m:
            return m.group(1).upper(), int(m.group(2))
        # 位置欄為「橋頭/橋尾」(翼牆、橋台基礎…) 時，以損壞位置或編號判斷
        if '橋頭' in c1:
            return 'A', 1
        if '橋尾' in c1:
            return 'A', 99
        m = re.match(r'[Aa]0*(\d+)', c2)
        if m:
            return 'A', int(m.group(1))
    except ValueError:
        pass
    return None


def sort_rank(k, mode, a_last):
    """排序用數字。ASP: A1,S1,P1,S2,P2…A2 ；PS: A1,P1,S1,P2,S2…A2"""
    L, n = k
    if L == 'A':
        return 0 if n == a_last['first'] else 10 ** 6
    if mode == 'ASP':
        return 2 * n - 1 if L == 'S' else 2 * n
    # PS
    return 2 * n - 1 if L == 'P' else 2 * n


def sort_items(items, mode):
    """items: list of (table, cells)；穩定排序，無法辨識者跟著前一個"""
    if mode == 'none':
        return items
    keys = [location_key(c) for _, c in items]
    a_nums = sorted({k[1] for k in keys if k and k[0] == 'A'})
    a_last = {'first': a_nums[0] if a_nums else 1}
    ranks = []
    prev = 0
    for k in keys:
        if k is None:
            ranks.append(prev)
        else:
            prev = sort_rank(k, mode, a_last)
            ranks.append(prev)
    order = sorted(range(len(items)), key=lambda i: (ranks[i], i))
    return [items[i] for i in order]


# ----------------------------------------------------------------------------
# 照片
# ----------------------------------------------------------------------------
def image_runs(p):
    return [r for r in p.findall('w:r', NS)
            if r.find('.//w:drawing', NS) is not None or r.find('.//w:pict', NS) is not None]


def run_rid(r):
    bl = r.find('.//a:blip', NS)
    if bl is not None:
        return bl.get(R + 'embed')
    im = r.find('.//v:imagedata', NS)
    if im is not None:
        return im.get(R + 'id')
    return None


def run_aspect(r):
    ex = r.find('.//wp:extent', NS)
    if ex is not None and int(ex.get('cy') or 0):
        return int(ex.get('cx')) / int(ex.get('cy'))
    sh = r.find('.//v:shape', NS)
    if sh is not None:
        st = sh.get('style') or ''
        w = re.search(r'width:([\d.]+)', st)
        h = re.search(r'height:([\d.]+)', st)
        if w and h and float(h.group(1)):
            return float(w.group(1)) / float(h.group(1))
    return 1.0


def photo_paragraph(tbl):
    """檢測照片列的圖片儲存格，回傳 (paragraph) 或 None（多段落則不處理）"""
    for tr in tbl.findall('w:tr', NS):
        tcs = tr.findall('w:tc', NS)
        if len(tcs) >= 2 and txt(tcs[0]) == '檢測照片':
            ps = tcs[1].findall('w:p', NS)
            with_img = [p for p in ps if image_runs(p)]
            if len(with_img) == 1:
                return with_img[0]
    return None


def choose_far_near(photos, reused, size_of):
    """photos: [(run, rid, aspect)] 不含位置圖。回傳要保留的 run（遠、近）"""
    def ordered(two):
        # 一律「遠照在前、近照在後」：檔案較大（內容多）的當遠照
        return [p[0] for p in sorted(two, key=lambda p: -size_of(p[1]))]
    if len(photos) <= 2:
        return ordered(photos)
    rest = list(photos)
    # 1) 同一張照片重複出現在多個缺失 => 平板拍的大範圍照片
    cand = [p for p in rest if reused.get(p[1], 0) >= 2]
    # 2) 長寬比與多數不同（直式）
    if not cand:
        asp = Counter(round(p[2], 1) for p in rest)
        major = asp.most_common(1)[0][0]
        cand = [p for p in rest if round(p[2], 1) != major]
    # 3) 檔案最大者（畫面內容最多的全景）
    if not cand:
        cand = [max(rest, key=lambda p: size_of(p[1]))]
    for c in cand:
        if len(rest) > 2:
            rest.remove(c)
    if len(rest) == 2:
        return ordered(rest)
    # 仍多於 2 張：遠 = 檔案較大（內容多）、近 = 檔案較小（特寫）
    far = max(rest, key=lambda p: size_of(p[1]))
    near = min(rest, key=lambda p: size_of(p[1]))
    return [far[0], near[0]]


# ----------------------------------------------------------------------------
# 主流程
# ----------------------------------------------------------------------------
POST_ITEMS = {'河道', '橋台基礎', '橋台', '橋墩基礎', '橋墩墩體/帽梁', '橋墩/帽梁', '護床工'}
CLEAR_COLS = ('D', 'E', 'R', 'U', '劣化類型', '維修工法', '數量', '單位', '備註')


def is_post_item(name):
    n = (name or '').replace(' ', '').replace('\u3000', '').replace('／', '/')
    return n in POST_ITEMS or '橋基保護設施' in n


def clear_cell(tc):
    for t in tc.iter(W + 't'):
        t.text = ''


FOOTER_XML = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
              '<w:ftr xmlns:w="%s"><w:p><w:pPr><w:jc w:val="center"/></w:pPr>'
              '<w:r><w:t xml:space="preserve">第 </w:t></w:r><w:fldSimple w:instr=" PAGE "><w:r><w:t>1</w:t></w:r></w:fldSimple>'
              '<w:r><w:t xml:space="preserve"> 頁，共 </w:t></w:r><w:fldSimple w:instr=" NUMPAGES "><w:r><w:t>1</w:t></w:r></w:fldSimple>'
              '<w:r><w:t xml:space="preserve"> 頁</w:t></w:r></w:p></w:ftr>') % NS['w']


def add_page_numbers(root, files, rels_root):
    """每個章節的頁尾都換成置中「第 X 頁，共 Y 頁」"""
    files['word/footer_pn.xml'] = FOOTER_XML.encode('utf-8')
    rid = 'rIdPageNum1'
    el = etree.SubElement(rels_root, '{%s}Relationship' % REL_NS)
    el.set('Id', rid)
    el.set('Type', 'http://schemas.openxmlformats.org/officeDocument/2006/relationships/footer')
    el.set('Target', 'footer_pn.xml')
    ct = etree.fromstring(files['[Content_Types].xml'])
    ov = etree.SubElement(ct, '{http://schemas.openxmlformats.org/package/2006/content-types}Override')
    ov.set('PartName', '/word/footer_pn.xml')
    ov.set('ContentType', 'application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml')
    files['[Content_Types].xml'] = etree.tostring(ct, xml_declaration=True, encoding='UTF-8', standalone=True)
    for sp in root.iter(W + 'sectPr'):
        for fr in sp.findall('w:footerReference', NS):
            sp.remove(fr)
        for tp in sp.findall('w:titlePg', NS):
            sp.remove(tp)
        fr = etree.Element(W + 'footerReference')
        fr.set(W + 'type', 'default')
        fr.set(R + 'id', rid)
        sp.insert(0, fr)


def process(src, dst, del_d1=True, del_e0=True, far_near=True, per_page=3,
            sort_mode='ASP', conds=None, match='any', log=print, post_only=False, page_numbers=False):
    conds = conds or []
    zin = zipfile.ZipFile(src)
    files = {n: zin.read(n) for n in zin.namelist()}
    order = zin.namelist()
    zin.close()

    root = etree.fromstring(files['word/document.xml'])
    body = root.find('w:body', NS)
    rels_root = etree.fromstring(files['word/_rels/document.xml.rels'])
    rid2target = {r.get('Id'): r.get('Target') for r in rels_root}

    def size_of(rid):
        t = rid2target.get(rid)
        if not t:
            return 0
        name = 'word/' + t if not t.startswith('/') else t[1:]
        return len(files.get(name, b''))

    # ---- 1) 前面的彙總表（總表）一律保留，不刪除任何內容
    if post_only:
        cleared, drop = [], []
        for tbl in body.iter(W + 'tbl'):
            if not is_summary_table(tbl):
                continue
            name = txt(tbl.findall('w:tr', NS)[0])[4:].strip()
            if not is_post_item(name):
                drop.append(tbl)
                cleared.append(name)
        for tbl in drop:
            remove_with_spacer(tbl)
        log('彙總表：只留汛期後構件，已刪除 %d 張其他構件的表（%s）' % (len(cleared), '、'.join(dict.fromkeys(cleared))))
    else:
        log('彙總表：全部保留')

    # ---- 2) 缺失表
    children = list(body)
    first = None
    defects = []
    for i, c in enumerate(children):
        if etree.QName(c).localname == 'tbl' and is_defect_table(c):
            if first is None:
                first = i
            defects.append(c)
    if first is None:
        raise RuntimeError('找不到缺失表（檢測項目／位置／編號／D／E…），這份檔案格式可能不同')
    total = len(defects)
    kept = []
    for c in defects:
        rs = c.findall('w:tr', NS)
        h = [txt(x) for x in rs[0].findall('w:tc', NS)]
        v = [txt(x) for x in rs[1].findall('w:tc', NS)]
        di, ei = h.index('D'), h.index('E')
        if post_only and not is_post_item(v[0] if v else ''):
            continue
        if (del_d1 and len(v) > di and v[di] == '1') or (del_e0 and len(v) > ei and v[ei] == '0'):
            continue
        get = lambda f, v=v, h=h: v[h.index(f)] if f in h and h.index(f) < len(v) else ''
        if not match_conds(get, conds, match):
            continue
        kept.append((c, v))
    log('缺失表：原 %d 個，刪除 %d 個（無損傷或不符條件），剩 %d 個' % (total, total - len(kept), len(kept)))

    # ---- 3) 照片：遠／近
    if far_near:
        reused = Counter()
        for c, _ in kept:
            p = photo_paragraph(c)
            if p is None:
                continue
            seen = set()
            for r in image_runs(p)[1:]:
                rid = run_rid(r)
                if rid and rid not in seen:
                    reused[rid] += 1
                    seen.add(rid)
        n_photo_del = 0
        for c, _ in kept:
            p = photo_paragraph(c)
            if p is None:
                continue
            runs = image_runs(p)
            if len(runs) <= 3:
                if len(runs) < 3:
                    continue
            diagram, photos = runs[0], [(r, run_rid(r), run_aspect(r)) for r in runs[1:]]
            keep = choose_far_near(photos, reused, size_of)
            if keep == [x[0] for x in photos]:
                continue
            kids = list(p)
            sep = None
            for k in kids:
                if k.tag == W + 'r' and k.find('.//w:drawing', NS) is None and k.find('.//w:pict', NS) is None \
                        and k.find('w:t', NS) is not None:
                    sep = k
            for k in kids:
                if k.tag == W + 'r':
                    p.remove(k)
            for r in [diagram] + keep:
                p.append(r)
                if sep is not None:
                    p.append(copy.deepcopy(sep))
            n_photo_del += len(photos) - len(keep)
        log('照片：刪除 %d 張（平板大範圍／多餘照片）' % n_photo_del)

    # ---- 4) 排序
    items = sort_items(kept, sort_mode)
    if sort_mode != 'none':
        log('排序：%s' % ('A1,S1,P1,S2,P2…A2' if sort_mode == 'ASP' else 'A1,P1,S1,P2,S2…A2'))

    # ---- 5) 重排版面：每頁 N 個
    spacer = copy.deepcopy(children[first + 1]) if txt(children[first + 1]) == '' else None
    if spacer is None:
        spacer = etree.fromstring('<w:p xmlns:w="%s"/>' % NS['w'])
    pb = None
    for c in reversed(children[max(0, first - 4):first]):
        if etree.QName(c).localname == 'p' and c.find('.//w:br[@w:type="page"]', NS) is not None:
            pb = copy.deepcopy(c)
            break
    if pb is None:
        pb = etree.fromstring('<w:p xmlns:w="%s"><w:r><w:br w:type="page"/></w:r></w:p>' % NS['w'])
    sect = children[-1]
    for c in children[first:-1]:
        body.remove(c)
    for k, (tb, _) in enumerate(items):
        sect.addprevious(tb)
        sect.addprevious(copy.deepcopy(spacer))
        if per_page and k % per_page == per_page - 1 and k != len(items) - 1:
            sect.addprevious(copy.deepcopy(pb))
    log('版面：每頁 %d 個缺失' % per_page)

    if page_numbers:
        add_page_numbers(root, files, rels_root)
        log('頁碼：已加入（第 X 頁，共 Y 頁）')
    files['word/document.xml'] = etree.tostring(
        root, xml_declaration=True, encoding='UTF-8', standalone=True)

    # ---- 6) 清掉沒用到的圖片
    doc = files['word/document.xml'].decode('utf8')
    used = set(re.findall(r'r:(?:embed|id|link)="([^"]+)"', doc))
    removed_media = 0
    for rel in list(rels_root):
        if rel.get('Type', '').endswith('/image') and rel.get('Id') not in used:
            rels_root.remove(rel)
            removed_media += 1
    files['word/_rels/document.xml.rels'] = etree.tostring(
        rels_root, xml_declaration=True, encoding='UTF-8', standalone=True)
    referenced = set()
    for n, data in files.items():
        if n.endswith('.rels'):
            for t in re.findall(rb'Target="([^"]+)"', data):
                t = t.decode('utf8')
                referenced.add(os.path.normpath(os.path.join(os.path.dirname(os.path.dirname(n)), t)).replace('\\', '/')
                               if not t.startswith('/') else t[1:])
    for n in list(files):
        if n.startswith('word/media/') and n not in referenced:
            del files[n]
    log('圖片：清除 %d 個未使用的圖片關聯' % removed_media)

    os.makedirs(os.path.dirname(os.path.abspath(dst)), exist_ok=True)
    with zipfile.ZipFile(dst, 'w', zipfile.ZIP_DEFLATED) as zout:
        for n in order:
            if n in files:
                zout.writestr(n, files[n])
        for n in files:
            if n not in order and not n.startswith('word/media/'):
                zout.writestr(n, files[n])
    a = os.path.getsize(src) / 1e6
    b = os.path.getsize(dst) / 1e6
    log('完成：%s  (%.1fMB → %.1fMB)' % (os.path.basename(dst), a, b))
    return dict(total=total, kept=len(items))


# ----------------------------------------------------------------------------
# 視窗
# ----------------------------------------------------------------------------
def run_gui():
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk

    try:
        from tkinterdnd2 import TkinterDnD, DND_FILES
        root = TkinterDnD.Tk()
        dnd = True
    except Exception:  # 沒裝 tkinterdnd2 時退回一般視窗（仍可點選加入檔案）
        root = tk.Tk()
        dnd = False

    BG, CARD, LINE = '#F3F5F9', '#FFFFFF', '#DCE2EC'
    ACC, ACC_D, ACC_L = '#1E5799', '#164678', '#E8F0FB'
    TXT, SUB = '#1F2937', '#6B7280'
    FONT = 'Microsoft JhengHei UI'

    root.title('橋梁定期檢測表整理工具')
    root.geometry('980x800')
    root.minsize(900, 720)
    root.configure(bg=BG)
    try:
        base = getattr(sys, '_MEIPASS', os.path.dirname(os.path.abspath(__file__)))
        root.iconbitmap(os.path.join(base, 'icon.ico'))
    except Exception:
        pass

    st = ttk.Style()
    try:
        st.theme_use('clam')
    except Exception:
        pass
    st.configure('Card.TCheckbutton', background=CARD, foreground=TXT, font=(FONT, 10))
    st.map('Card.TCheckbutton', background=[('active', CARD)])
    st.configure('Card.TRadiobutton', background=CARD, foreground=TXT, font=(FONT, 10))
    st.map('Card.TRadiobutton', background=[('active', CARD)])
    st.configure('Card.TLabel', background=CARD, foreground=TXT, font=(FONT, 10))
    st.configure('Sub.TLabel', background=CARD, foreground=SUB, font=(FONT, 9))
    st.configure('TCombobox', font=(FONT, 10))
    st.configure('Acc.Horizontal.TProgressbar', troughcolor=LINE, background=ACC, bordercolor=LINE,
                 lightcolor=ACC, darkcolor=ACC)

    files = []
    state = {'outdir': None}

    # ---------- 標題列
    head = tk.Frame(root, bg=ACC)
    head.pack(fill='x')
    tk.Label(head, text='橋梁定期檢測表整理工具', bg=ACC, fg='white',
             font=(FONT, 18, 'bold')).pack(anchor='w', padx=24, pady=(16, 0))
    tk.Label(head, text='刪除無損傷構件・只留遠近照片・依位置排序・每頁固定缺失數', bg=ACC, fg='#C9DBF2',
             font=(FONT, 10)).pack(anchor='w', padx=24, pady=(2, 16))
    tk.Label(head, text='製作：泓銘', bg=ACC, fg='#C9DBF2', font=(FONT, 10)).place(
        relx=1.0, rely=1.0, anchor='se', x=-20, y=-10)

    body = tk.Frame(root, bg=BG)
    body.pack(fill='both', expand=True, padx=20, pady=16)
    body.columnconfigure(0, weight=3, uniform='c')
    body.columnconfigure(1, weight=2, uniform='c')
    body.rowconfigure(0, weight=1)
    left = tk.Frame(body, bg=BG)
    right = tk.Frame(body, bg=BG)
    left.grid(row=0, column=0, sticky='nsew', padx=(0, 10))
    right.grid(row=0, column=1, sticky='nsew', padx=(10, 0))

    def card(parent, title, expand=False):
        outer = tk.Frame(parent, bg=CARD, highlightthickness=1, highlightbackground=LINE)
        outer.pack(fill='both' if expand else 'x', expand=expand, pady=(0, 12))
        tk.Label(outer, text=title, bg=CARD, fg=TXT, font=(FONT, 11, 'bold')).pack(
            anchor='w', padx=14, pady=(10, 4))
        inner = tk.Frame(outer, bg=CARD)
        inner.pack(fill='both', expand=True, padx=14, pady=(0, 12))
        return inner

    def button(parent, text, cmd, primary=False, size=10):
        bgc, hov = (ACC, ACC_D) if primary else (ACC_L, '#D3E3F8')
        fgc = 'white' if primary else ACC
        b = tk.Label(parent, text=text, bg=bgc, fg=fgc, font=(FONT, size, 'bold'),
                     padx=14, pady=7, cursor='hand2')
        b.bind('<Enter>', lambda e: b.configure(bg=hov))
        b.bind('<Leave>', lambda e: b.configure(bg=bgc))
        b.bind('<Button-1>', lambda e: cmd())
        return b

    # ---------- 左：檔案
    fc = card(left, '1　選擇 Word 檔')
    zone = tk.Canvas(fc, height=120, bg=ACC_L, highlightthickness=0, cursor='hand2')
    zone.pack(fill='x')

    def draw_zone(_e=None):
        zone.delete('all')
        w, h = zone.winfo_width(), zone.winfo_height()
        zone.create_rectangle(6, 6, w - 6, h - 6, outline=ACC, dash=(6, 4), width=2)
        zone.create_text(w // 2, h // 2 - 14, text='把 Word 檔拖進這裡' if dnd else '點這裡選擇 Word 檔',
                         fill=ACC, font=(FONT, 14, 'bold'))
        zone.create_text(w // 2, h // 2 + 16, text='或點一下選擇檔案（可一次選多個 .docx）',
                         fill=SUB, font=(FONT, 10))
    zone.bind('<Configure>', draw_zone)

    lf = tk.Frame(fc, bg=CARD)
    lf.pack(fill='both', expand=True, pady=(10, 0))
    lb = tk.Listbox(lf, height=5, bd=0, highlightthickness=1, highlightbackground=LINE,
                    font=(FONT, 10), activestyle='none', selectmode='extended',
                    selectbackground=ACC_L, selectforeground=TXT)
    sb = ttk.Scrollbar(lf, orient='vertical', command=lb.yview)
    lb.configure(yscrollcommand=sb.set)
    lb.pack(side='left', fill='both', expand=True)
    sb.pack(side='right', fill='y')

    def add_paths(paths):
        n = 0
        for p in paths:
            p = os.path.normpath(p)
            if (p.lower().endswith('.docx') and not os.path.basename(p).startswith('~$')
                    and p not in files):
                files.append(p)
                lb.insert('end', os.path.basename(p) + '    ' + os.path.dirname(p))
                n += 1
        if n:
            log('已加入 %d 個檔案' % n)

    def pick(_e=None):
        add_paths(filedialog.askopenfilenames(title='選擇 Word 檔', filetypes=[('Word 檔', '*.docx')]))

    def remove_sel():
        for i in reversed(lb.curselection()):
            lb.delete(i)
            del files[i]

    def clear_all():
        files.clear()
        lb.delete(0, 'end')

    zone.bind('<Button-1>', pick)
    lb.bind('<Delete>', lambda e: remove_sel())
    br = tk.Frame(fc, bg=CARD)
    br.pack(fill='x', pady=(8, 0))
    button(br, '移除選取', remove_sel).pack(side='left')
    button(br, '清空', clear_all).pack(side='left', padx=8)

    if dnd:
        def on_drop(e):
            add_paths(root.tk.splitlist(e.data))
        for w in (zone, lb):
            w.drop_target_register(DND_FILES)
            w.dnd_bind('<<Drop>>', on_drop)

    # ---------- 左：紀錄
    lc = card(left, '執行紀錄', expand=True)
    prog = ttk.Progressbar(lc, style='Acc.Horizontal.TProgressbar', maximum=100)
    prog.pack(fill='x', pady=(0, 8))
    txtf = tk.Frame(lc, bg=CARD)
    txtf.pack(fill='both', expand=True)
    out = tk.Text(txtf, height=8, bd=0, highlightthickness=1, highlightbackground=LINE,
                  font=(FONT, 9), bg='#FAFBFD', fg=TXT, state='disabled', wrap='word')
    osb = ttk.Scrollbar(txtf, orient='vertical', command=out.yview)
    out.configure(yscrollcommand=osb.set)
    out.pack(side='left', fill='both', expand=True)
    osb.pack(side='right', fill='y')

    def log(s):
        def w():
            out.configure(state='normal')
            out.insert('end', s + '\n')
            out.see('end')
            out.configure(state='disabled')
        root.after(0, w)

    # ---------- 右：選項
    oc = card(right, '2　整理項目')
    v_d1, v_e0, v_fn = tk.BooleanVar(value=True), tk.BooleanVar(value=True), tk.BooleanVar(value=True)
    ttk.Checkbutton(oc, text='刪除 D=1（無損傷）的構件', variable=v_d1, style='Card.TCheckbutton').pack(anchor='w', pady=2)
    ttk.Checkbutton(oc, text='刪除 E=0 的構件', variable=v_e0, style='Card.TCheckbutton').pack(anchor='w', pady=2)
    ttk.Checkbutton(oc, text='每個缺失只留 遠／近 兩張照片', variable=v_fn, style='Card.TCheckbutton').pack(anchor='w', pady=2)
    pf = tk.Frame(oc, bg=CARD)
    pf.pack(anchor='w', pady=(6, 0))
    ttk.Label(pf, text='每頁缺失數', style='Card.TLabel').pack(side='left')
    v_pp = tk.IntVar(value=3)
    ttk.Spinbox(pf, from_=1, to=6, width=4, textvariable=v_pp, font=(FONT, 10)).pack(side='left', padx=8)

    cc = card(right, '3　只保留符合條件的缺失')
    v_cf = tk.BooleanVar(value=False)
    ttk.Checkbutton(cc, text='啟用條件篩選（其餘刪除）', variable=v_cf, style='Card.TCheckbutton').pack(anchor='w')
    cond_rows = []
    for i in range(3):
        row = tk.Frame(cc, bg=CARD)
        row.pack(anchor='w', pady=3)
        f_, o_, n_ = tk.StringVar(value=['D', 'R', 'U'][i]), tk.StringVar(value='>='), tk.StringVar(value='')
        ttk.Label(row, text='條件%d' % (i + 1), style='Card.TLabel').pack(side='left', padx=(0, 8))
        ttk.Combobox(row, textvariable=f_, values=['D', 'E', 'R', 'U'], width=3, state='readonly').pack(side='left')
        ttk.Combobox(row, textvariable=o_, values=['=', '>=', '<=', '>', '<'], width=3, state='readonly').pack(side='left', padx=4)
        tk.Entry(row, textvariable=n_, width=4, font=(FONT, 10), relief='solid', bd=1).pack(side='left')
        cond_rows.append((f_, o_, n_))
    v_m = tk.StringVar(value='any')
    mr = tk.Frame(cc, bg=CARD)
    mr.pack(anchor='w', pady=(4, 0))
    ttk.Radiobutton(mr, text='任一符合', variable=v_m, value='any', style='Card.TRadiobutton').pack(side='left')
    ttk.Radiobutton(mr, text='全部符合', variable=v_m, value='all', style='Card.TRadiobutton').pack(side='left', padx=10)
    ttk.Label(cc, text='數字留空的條件不使用', style='Sub.TLabel').pack(anchor='w')

    sc = card(right, '4　缺失排序')
    v_sort = tk.StringVar(value='ASP')
    for val, t1, t2 in (('ASP', 'ASP 交錯', 'A1 → S1 → P1 → S2 → P2 … → A2'),
                        ('PS', 'PS 交錯', 'A1 → P1 → S1 → P2 → S2 … → A2'),
                        ('none', '不排序', '保持原本順序')):
        ttk.Radiobutton(sc, text=t1, variable=v_sort, value=val, style='Card.TRadiobutton').pack(anchor='w')
        ttk.Label(sc, text='     ' + t2, style='Sub.TLabel').pack(anchor='w', pady=(0, 3))

    # ---------- 底部：開始
    bot = tk.Frame(right, bg=BG)
    bot.pack(fill='x', side='bottom')
    start = button(bot, '開始整理', lambda: go(), primary=True, size=13)
    start.pack(fill='x', ipady=4)
    openb = button(bot, '開啟輸出資料夾', lambda: open_out())
    note = tk.Label(bot, text='輸出到原檔旁的「整理後」資料夾，檔名不變，原檔不會被修改',
                    bg=BG, fg=SUB, font=(FONT, 9), wraplength=340, justify='left')
    note.pack(anchor='w', pady=(6, 0))

    def open_out():
        d = state['outdir']
        if d and os.path.isdir(d):
            try:
                os.startfile(d)  # Windows
            except Exception:
                pass

    busy = {'v': False}

    def work(fl, opts):
        n = len(fl)
        for i, f in enumerate(fl):
            log('== ' + os.path.basename(f))
            try:
                d = os.path.join(os.path.dirname(f), '整理後')
                state['outdir'] = d
                process(f, os.path.join(d, os.path.basename(f)), log=log, **opts)
            except Exception as e:  # noqa
                log('失敗：%s' % e)
            root.after(0, lambda v=(i + 1) * 100 / n: prog.configure(value=v))
        log('全部結束。請用 Word 開啟檢查分頁與照片。')

        def fin():
            busy['v'] = False
            start.configure(text='開始整理')
            openb.pack(fill='x', pady=(8, 0), before=note)
        root.after(0, fin)

    def go():
        if busy['v']:
            return
        if not files:
            messagebox.showinfo('提示', '請先把 Word 檔拖進來，或點選加入')
            return
        conds = []
        if v_cf.get():
            for f_, o_, n_ in cond_rows:
                if n_.get().strip():
                    conds.append('%s%s%s' % (f_.get(), o_.get(), n_.get().strip()))
            try:
                conds = parse_conds(conds)
            except ValueError as e:
                messagebox.showerror('條件錯誤', str(e))
                return
        try:
            pp = int(v_pp.get())
        except Exception:
            pp = 3
        opts = dict(conds=conds, match=v_m.get(), del_d1=v_d1.get(), del_e0=v_e0.get(),
                    far_near=v_fn.get(), per_page=pp, sort_mode=v_sort.get())
        busy['v'] = True
        start.configure(text='整理中…')
        prog.configure(value=0)
        threading.Thread(target=work, args=(list(files), opts), daemon=True).start()

    if not dnd:
        log('提示：未安裝 tkinterdnd2，暫時不能拖曳，請點選區塊加入檔案。')
    root.mainloop()


def main():
    ap = argparse.ArgumentParser(description='橋梁定期檢測表整理工具')
    ap.add_argument('files', nargs='*', help='.docx 檔案；不給則開啟視窗')
    ap.add_argument('--sort', choices=['ASP', 'PS', 'none'], default='ASP')
    ap.add_argument('--per-page', type=int, default=3)
    ap.add_argument('--keep-d1', action='store_true', help='不刪 D=1')
    ap.add_argument('--keep-e0', action='store_true', help='不刪 E=0')
    ap.add_argument('--keep-photos', action='store_true', help='不刪照片')
    ap.add_argument('--keep', action='append', default=[], metavar='條件',
                    help='只保留符合的缺失，例如 --keep D>=2 --keep R=3（可重複）')
    ap.add_argument('--match', choices=['any', 'all'], default='any',
                    help='多個條件：any=任一符合（預設）、all=全部符合')
    ap.add_argument('--out', help='輸出資料夾（預設為原檔旁的「整理後」）')
    a = ap.parse_args()
    if not a.files:
        run_gui()
        return
    for f in a.files:
        outdir = a.out or os.path.join(os.path.dirname(os.path.abspath(f)), '整理後')
        print('==', f)
        process(f, os.path.join(outdir, os.path.basename(f)), del_d1=not a.keep_d1,
                del_e0=not a.keep_e0, far_near=not a.keep_photos, per_page=a.per_page,
                sort_mode=a.sort, conds=parse_conds(a.keep), match=a.match)


if __name__ == '__main__':
    main()
