# -*- coding: utf-8 -*-
"""PDF 操作：合併、送印拆分（彩色版／黑白版）。與視窗無關。"""
import io
import os

from pypdf import PdfReader, PdfWriter

SENS = {'一般': 0.01, '敏感': 0.002, '非常敏感（小標誌也算彩色）': 0.0003}


# ----------------------------------------------------------------------------
# 核心
# ----------------------------------------------------------------------------
def open_pdf(path):
    r = PdfReader(path)
    if r.is_encrypted:
        try:
            ok = r.decrypt('')
        except Exception:
            ok = 0
        if not ok:
            raise ValueError('檔案有密碼保護')
    return r


def unique_path(path):
    if not os.path.exists(path):
        return path
    stem, ext = os.path.splitext(path)
    n = 2
    while os.path.exists('%s (%d)%s' % (stem, n, ext)):
        n += 1
    return '%s (%d)%s' % (stem, n, ext)


def page_count(path):
    try:
        return len(open_pdf(path).pages)
    except Exception:
        return None


def _png_bytes(pil):
    bio = io.BytesIO()
    pil.save(bio, 'PNG')
    return bio.getvalue()


def _backend():
    try:
        import pypdfium2 as pdfium
        return 'pdfium', pdfium
    except Exception:
        pass
    try:
        import fitz
        return 'fitz', fitz
    except Exception:
        pass
    return None, None


def _pil_pages(path, scale=0.5):
    """逐頁 yield PIL 圖（RGB）"""
    kind, mod = _backend()
    if kind == 'pdfium':
        pdf = mod.PdfDocument(path)
        try:
            for i in range(len(pdf)):
                yield pdf[i].render(scale=scale).to_pil().convert('RGB')
        finally:
            try:
                pdf.close()
            except Exception:
                pass
    elif kind == 'fitz':
        from PIL import Image
        doc = mod.open(path)
        for i in range(len(doc)):
            pm = doc[i].get_pixmap(matrix=mod.Matrix(scale, scale), alpha=False)
            yield Image.frombytes('RGB', (pm.width, pm.height), pm.samples)
    else:
        raise RuntimeError('需要 pypdfium2（請執行：pip install pypdfium2）')


def color_fraction(im):
    """回傳圖中「有顏色的像素」比例（飽和度夠高才算）"""
    try:
        import numpy as np
        a = np.asarray(im).astype(int)
        return float(((a.max(2) - a.min(2)) > 40).mean())
    except Exception:
        px = im.getdata()
        n = c = 0
        for r, g, b in px:
            n += 1
            if max(r, g, b) - min(r, g, b) > 40:
                c += 1
        return c / max(n, 1)


def analyze(path, box=(116, 156), cancel=None):
    """逐頁分析：yield (頁序, 縮圖png, 寬, 高, 彩色比例)"""
    for i, im in enumerate(_pil_pages(path, 0.5)):
        if cancel is not None and cancel():
            return
        frac = color_fraction(im)
        s = min(box[0] / im.width, box[1] / im.height)
        th = im.resize((max(1, int(im.width * s)), max(1, int(im.height * s))))
        yield i, _png_bytes(th), th.width, th.height, frac


def render_page_png(path, index, width=560):
    kind, mod = _backend()
    if kind == 'pdfium':
        pdf = mod.PdfDocument(path)
        try:
            w, _h = pdf[index].get_size()
            return _png_bytes(pdf[index].render(scale=width / w).to_pil().convert('RGB'))
        finally:
            pdf.close()
    if kind == 'fitz':
        doc = mod.open(path)
        pg = doc[index]
        sc = width / pg.rect.width
        return pg.get_pixmap(matrix=mod.Matrix(sc, sc)).tobytes('png')
    raise RuntimeError('需要 pypdfium2')


def n_sheets(n_pages, per):
    return (n_pages + per - 1) // per


def auto_color_sheets(fracs, per, thr):
    """一張紙只要任何一面有彩色，就算彩色紙"""
    out = set()
    for s in range(n_sheets(len(fracs), per)):
        if any(f > thr for f in fracs[s * per:(s + 1) * per]):
            out.add(s)
    return out


def pages_to_sheets(spec, n_pages, per):
    """'1-3,7,9-' -> 這些頁所在的紙張編號集合（0 起算）"""
    out = set()
    for part in spec.replace('，', ',').replace('、', ',').replace(' ', '').split(','):
        if not part:
            continue
        if '-' in part:
            a, _, b = part.partition('-')
            lo = int(a) if a else 1
            hi = int(b) if b else n_pages
        else:
            lo = hi = int(part)
        if lo < 1 or hi > n_pages or lo > hi:
            raise ValueError('頁碼超出範圍（1～%d）：%s' % (n_pages, part))
        out |= {(p - 1) // per for p in range(lo, hi + 1)}
    return out


def sheet_pages(sheets, per, n_pages):
    idx = []
    for s in sorted(sheets):
        idx += [p for p in range(s * per, (s + 1) * per) if p < n_pages]
    return idx


def spec_of(idxs):
    """[0,1,6,7] -> '1-2,7-8'"""
    idxs = sorted(idxs)
    out, i = [], 0
    while i < len(idxs):
        j = i
        while j + 1 < len(idxs) and idxs[j + 1] == idxs[j] + 1:
            j += 1
        a, b = idxs[i] + 1, idxs[j] + 1
        out.append(str(a) if a == b else '%d-%d' % (a, b))
        i = j + 1
    return ','.join(out)


def _write(reader, idxs, out, pad_even):
    w = PdfWriter()
    for i in idxs:
        w.add_page(reader.pages[i])
    padded = False
    if pad_even and len(idxs) % 2 == 1:
        last = reader.pages[idxs[-1]]
        w.add_blank_page(width=float(last.mediabox.width), height=float(last.mediabox.height))
        padded = True
    with open(out, 'wb') as f:
        w.write(f)
    return padded


_SIZES = [('A0', 841, 1189), ('A1', 594, 841), ('A2', 420, 594), ('A3', 297, 420), ('A4', 210, 297),
          ('A5', 148, 210), ('Letter', 216, 279)]


def size_label(w_pt, h_pt):
    """頁面尺寸（pt）→ 'A4'、'A3'…；不認得就用 '寬x高mm'（不分直橫）"""
    a, b = sorted((w_pt * 25.4 / 72, h_pt * 25.4 / 72))
    for name, sw, sh in _SIZES:
        if abs(a - sw) <= sw * 0.04 and abs(b - sh) <= sh * 0.04:
            return name
    return '%dx%dmm' % (round(a), round(b))


def page_labels(path):
    r = open_pdf(path)
    out = []
    for pg in r.pages:
        w, h = float(pg.mediabox.width), float(pg.mediabox.height)
        out.append(size_label(w, h))
    return out


def sheet_labels(labels, per):
    """每張紙的尺寸＝該張第一頁的尺寸"""
    return [labels[s * per] for s in range(n_sheets(len(labels), per))]


def split_print(path, color_sheets, per=2, outdir=None, log=print, by_size=True):
    """輸出到「原檔名_送印」資料夾，檔名固定如：A4雙面彩色.pdf、A4雙面黑白.pdf、A3雙面彩色.pdf…
    回傳輸出檔路徑 tuple。by_size：不同紙張尺寸各自輸出；關閉則全部當同一尺寸（取第一頁的尺寸名稱）"""
    r = open_pdf(path)
    n = len(r.pages)
    real = sheet_labels(page_labels(path), per)
    labels = real if by_size else [real[0]] * len(real)
    sizes = []
    for lb in labels:
        if lb not in sizes:
            sizes.append(lb)
    base = os.path.splitext(os.path.basename(path))[0]
    od = os.path.join(outdir or os.path.dirname(os.path.abspath(path)), base + '_送印')
    os.makedirs(od, exist_ok=True)
    side = '雙面' if per == 2 else '單面'
    if len(sizes) > 1:
        log('  偵測到多種紙張尺寸：%s，將分開輸出' % '、'.join('%s（%d 張）' % (z, labels.count(z)) for z in sizes))
    res = []
    for z in sizes:
        mine = {s for s in range(len(labels)) if labels[s] == z}
        for name, want in (('彩色', True), ('黑白', False)):
            sheets = {s for s in mine if (s in color_sheets) == want}
            idxs = sheet_pages(sheets, per, n)
            if not idxs:
                continue
            fn = '%s%s%s.pdf' % (z, side, name)
            out = unique_path(os.path.join(od, fn))
            padded = _write(r, idxs, out, pad_even=(per == 2))
            log('  %s：%d 頁（原第 %s 頁）%s' % (os.path.basename(out)[:-4], len(idxs), spec_of(idxs),
                                          '＋補 1 張空白頁' if padded else ''))
            res.append(out)
    if not res:
        log('  沒有輸出任何頁面')
    return tuple(res)


# ----------------------------------------------------------------------------
# 版面（不依賴 tkinter）
# ----------------------------------------------------------------------------
class SheetGrid:
    def __init__(self, per=2, cw=128, ch=186, gap=14):
        self.per, self.cw, self.ch, self.gap = per, cw, ch, gap
        self.n = 0
        self.width = 600

    @property
    def bw(self):
        return self.per * self.cw + self.gap

    @property
    def cols(self):
        return max(1, self.width // self.bw)

    def sheets(self):
        return n_sheets(self.n, self.per)

    def total_height(self):
        return ((self.sheets() + self.cols - 1) // self.cols) * self.ch + 8

    def page_pos(self, i):
        s, k = divmod(i, self.per)
        return (s % self.cols) * self.bw + k * self.cw, (s // self.cols) * self.ch

    def sheet_pos(self, s):
        return (s % self.cols) * self.bw, (s // self.cols) * self.ch

    def hit_sheet(self, x, y):
        c, r = int(x // self.bw), int(y // self.ch)
        if x < 0 or y < 0 or c >= self.cols:
            return None
        s = r * self.cols + c
        return s if s < self.sheets() else None


# ---- 合併
def merge_pdfs(paths, out, bookmarks=True, log=print):
    w = PdfWriter()
    for p in paths:
        r = open_pdf(p)
        start = len(w.pages)
        for pg in r.pages:
            w.add_page(pg)
        if bookmarks and len(r.pages):
            w.add_outline_item(os.path.splitext(os.path.basename(p))[0], start)
        log('  + %s（%d 頁）' % (os.path.basename(p), len(r.pages)))
    out = unique_path(out)
    os.makedirs(os.path.dirname(os.path.abspath(out)), exist_ok=True)
    with open(out, 'wb') as f:
        w.write(f)
    return out, len(w.pages)
