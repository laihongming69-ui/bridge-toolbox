# -*- coding: utf-8 -*-
"""照片壓縮：資料夾／圖檔／Word（docx 內嵌照片）。與視窗無關。
- 自動依 EXIF 轉正，縮小長邊、調整品質；可指定「每張不超過 N KB」。
- 壓完比原檔還大就直接沿用原檔，不會越壓越大。
- Word／PowerPoint／Excel：只重壓 */media 裡的 JPG／PNG，檔名與格式不變，版面不受影響。"""
import io
import os
import zipfile
from concurrent.futures import ThreadPoolExecutor

from PIL import Image, ImageOps

IMG_EXT = ('.jpg', '.jpeg', '.png', '.bmp', '.tif', '.tiff', '.webp')
DOCX_EXT = ('.docx', '.docm', '.pptx', '.pptm', '.potx', '.xlsx', '.xlsm')   # Word／PowerPoint／Excel（都是 zip，圖片放在 */media/）
MEDIA_DIRS = ('word/media/', 'ppt/media/', 'xl/media/')
MARK = 'BridgeToolbox'        # 壓縮過的照片會被寫入這個標記（JPG：EXIF Software；PNG：Software 文字）
EXIF_SOFTWARE = 0x0131


def is_target(path):
    n = os.path.basename(path)
    if n.startswith('~$'):
        return False
    return n.lower().endswith(IMG_EXT + DOCX_EXT)


def is_marked(data):
    """這張照片是不是本程式壓縮過的"""
    try:
        im = Image.open(io.BytesIO(data))
        if (im.format or '').upper() == 'PNG':
            return str(im.info.get('Software', '')).startswith(MARK)
        return str(im.getexif().get(EXIF_SOFTWARE, '')).startswith(MARK)
    except Exception:
        return False


def low_priority():
    """把目前的執行緒降為「低於標準」優先權，讓視窗保持順暢（只在 Windows 有作用）"""
    try:
        import ctypes
        k = ctypes.windll.kernel32
        k.SetThreadPriority(k.GetCurrentThread(), -1)
    except Exception:
        pass


FLOOR_Q, CEIL_Q = 25, 92
SOFT = 1.15          # 允許超出目標多少（700KB 的上限約 805KB）


def _to_target(data, target_kb, force_jpeg=False):
    """解析度完全不動，只調 JPG 品質，讓檔案大小落在目標附近。
    回傳 (bytes, 副檔名)；原本就夠小／不適合壓的回傳 (data, '') 代表略過。"""
    soft = int(target_kb * 1024 * SOFT)
    low = int(target_kb * 1024 * 0.85)
    if len(data) <= soft:
        return data, ''
    im = Image.open(io.BytesIO(data))
    fmt = (im.format or '').upper()
    if (fmt == 'PNG' and not force_jpeg) or im.mode in ('RGBA', 'LA') or (im.mode == 'P' and 'transparency' in im.info):
        return data, ''
    exif = None
    try:
        ex = im.getexif()                         # 方向標記原樣保留，不轉動像素
        ex[EXIF_SOFTWARE] = '%s-t%d' % (MARK, target_kb)
        exif = ex.tobytes()
    except Exception:
        pass
    im.load()
    if im.mode not in ('RGB', 'L'):
        im = im.convert('RGB')
    import math
    tried = {}

    def enc(q):
        q = int(max(FLOOR_Q, min(CEIL_Q, round(q))))
        if q not in tried:
            buf = io.BytesIO()
            kw = dict(quality=q, optimize=False)
            if exif:
                kw['exif'] = exif
            im.save(buf, 'JPEG', **kw)
            tried[q] = buf.getvalue()
        return q, len(tried[q])
    q, s = enc(55)
    for _ in range(3):
        if low <= s <= soft:
            break
        # 品質每差 1，大小約差 2.5%（取對數線性估計），逼近目標
        k = 0.025
        if len(tried) >= 2:
            qs = sorted(tried)
            pts = [(a, math.log(len(tried[a]))) for a in qs]
            (a1, l1), (a2, l2) = min(zip(pts, pts[1:]), key=lambda pr: abs(pr[0][1] - math.log(target_kb * 1024)) + abs(pr[1][1] - math.log(target_kb * 1024)))
            if a2 != a1 and l2 != l1:
                k = max(0.005, min(0.06, (l1 - l2) / (a1 - a2)))
        nq = q + math.log(target_kb * 1024.0 / s) / k
        if int(round(nq)) == q or int(round(nq)) in tried:
            nq = q + (1 if s < target_kb * 1024 else -1)
        q, s = enc(nq)
    ok = [(len(b), qq) for qq, b in tried.items() if len(b) <= soft]
    best = max(ok)[1] if ok else min(tried, key=lambda qq: len(tried[qq]))
    out = tried[best]
    try:                                         # 最後一次用較省空間的編碼（同畫質、檔案再小幾 %）
        buf = io.BytesIO()
        kw = dict(quality=best, optimize=True)
        if exif:
            kw['exif'] = exif
        im.save(buf, 'JPEG', **kw)
        if len(buf.getvalue()) < len(out):
            out = buf.getvalue()
    except Exception:
        pass
    if len(out) >= len(data):
        return data, '.jpg' if fmt == 'JPEG' else ''
    return out, '.jpg'


def _encode(im, fmt, quality, exif):
    buf = io.BytesIO()
    if fmt == 'PNG':
        from PIL import PngImagePlugin
        pi = PngImagePlugin.PngInfo()
        pi.add_text('Software', '%s-q%d' % (MARK, quality))
        im.save(buf, 'PNG', optimize=True, pnginfo=pi)
    else:
        if im.mode not in ('RGB', 'L'):
            im = im.convert('RGB')
        kw = dict(quality=quality, optimize=False, progressive=False)
        if exif:
            kw['exif'] = exif
        im.save(buf, 'JPEG', **kw)
    return buf.getvalue()


def _png_strong(data, target_kb):
    """強化壓縮的 PNG：格式、解析度、透明度都不變，只把顏色縮成 256 色（地圖、圖面、截圖幾乎看不出差別）"""
    if len(data) <= int(target_kb * 1024 * SOFT):
        return data, ''
    im = Image.open(io.BytesIO(data))
    if im.mode == 'P' and 'transparency' not in im.info:
        return data, ''
    info = dict(im.info)
    im.load()
    if im.mode == 'P':
        im = im.convert('RGBA')
    elif im.mode in ('LA', 'PA'):
        im = im.convert('RGBA')
    elif im.mode not in ('RGB', 'RGBA'):
        im = im.convert('RGB')
    q = im.quantize(colors=256, method=Image.Quantize.FASTOCTREE)
    from PIL import PngImagePlugin
    pi = PngImagePlugin.PngInfo()
    pi.add_text('Software', '%s-s%d' % (MARK, target_kb))
    kw = dict(optimize=True, pnginfo=pi)
    if 'dpi' in info:
        kw['dpi'] = info['dpi']
    buf = io.BytesIO()
    q.save(buf, 'PNG', **kw)
    out = buf.getvalue()
    if len(out) >= len(data) * 0.85:
        return data, ''
    return out, '.png'


def compress_bytes(data, max_edge=0, quality=80, max_kb=0, force_jpeg=False, skip_marked=True, target_kb=0, strong=False):
    """回傳 (新的 bytes, 副檔名)。新的比較大就回傳原 bytes。"""
    if skip_marked and is_marked(data):
        return data, ''
    if target_kb:
        if strong:
            try:
                if (Image.open(io.BytesIO(data)).format or '').upper() == 'PNG':
                    return _png_strong(data, target_kb)
            except Exception:
                return data, ''
        return _to_target(data, target_kb, force_jpeg)
    im = Image.open(io.BytesIO(data))
    src_fmt = (im.format or '').upper()
    if src_fmt == 'JPEG' and max_edge and max(im.size) > max_edge:     # 解碼時直接縮小，速度快數倍
        r = max_edge / float(max(im.size))
        im.draft('RGB', (int(im.width * r) + 1, int(im.height * r) + 1))
    exif = None
    try:
        ex = im.getexif()
        if ex and 0x0112 in ex:
            im = ImageOps.exif_transpose(im)
            ex = im.getexif()
            ex[0x0112] = 1
        ex[EXIF_SOFTWARE] = '%s-q%d' % (MARK, quality)
        exif = ex.tobytes()
    except Exception:
        exif = None
    has_alpha = im.mode in ('RGBA', 'LA') or (im.mode == 'P' and 'transparency' in im.info)
    fmt = 'PNG' if (src_fmt == 'PNG' and not force_jpeg) or has_alpha else 'JPEG'
    if max_edge and max(im.size) > max_edge:
        r = max_edge / float(max(im.size))
        im = im.resize((max(1, round(im.width * r)), max(1, round(im.height * r))), Image.LANCZOS)
    out = _encode(im, fmt, quality, exif)
    if max_kb and fmt == 'JPEG':
        q, tries = quality, 0
        while len(out) > max_kb * 1024 and tries < 12:
            if q > 45:
                q -= 5
            else:                       # 品質已很低 → 再縮小 10%
                im = im.resize((max(1, int(im.width * 0.9)), max(1, int(im.height * 0.9))), Image.LANCZOS)
            out = _encode(im, fmt, q, exif)
            tries += 1
    ext = '.png' if fmt == 'PNG' else '.jpg'
    same_kind = (src_fmt == 'PNG') == (fmt == 'PNG') and (src_fmt in ('JPEG', 'PNG'))
    if same_kind and len(out) >= len(data):
        return data, ext
    return out, ext


def compress_image(src, dst_dir, max_edge=0, quality=80, max_kb=0, tag='', skip_marked=True, target_kb=0, strong=False):
    """壓一張圖，存到 dst_dir，回傳 (輸出路徑, 原大小, 新大小)"""
    data = open(src, 'rb').read()
    out, ext = compress_bytes(data, max_edge, quality, max_kb, force_jpeg=src.lower().endswith(('.bmp', '.tif', '.tiff', '.webp')),
                              skip_marked=skip_marked, target_kb=target_kb, strong=strong)
    if out is data and not ext:
        return None, len(data), len(data)           # 已壓縮過，略過
    os.makedirs(dst_dir, exist_ok=True)
    stem = os.path.splitext(os.path.basename(src))[0] + tag
    low = os.path.splitext(src)[1].lower()
    if out is data:
        ext = low
    dst = _unique(os.path.join(dst_dir, stem + ext))
    with open(dst, 'wb') as f:
        f.write(out)
    return dst, len(data), len(out)


def compress_docx(src, dst_dir, max_edge=0, quality=80, max_kb=0, log=None, cancel=None, tag='', workers=4, skip_marked=True, pool=None, target_kb=0, strong=False):
    """重壓 docx 內嵌照片，回傳 (輸出路徑, 原大小, 新大小, 張數)"""
    n = 0
    with zipfile.ZipFile(src) as zi:
        infos = zi.infolist()
        datas = {}
        todo = []
        for it in infos:
            datas[it.filename] = zi.read(it.filename)
            low = it.filename.lower()
            if low.startswith(MEDIA_DIRS) and low.endswith(('.jpg', '.jpeg', '.png')):
                todo.append(it.filename)

    def finish(name, out):
        nonlocal n
        if out is not None and (out[1] == '.png') == name.lower().endswith('.png'):   # 格式要和副檔名一致，不改 rels
            datas[name] = out[0]
            n += 1
    if pool is not None:                       # 交給程序池（多核心、不影響視窗）
        futs = [(name, pool.submit(process_media, datas[name], max_edge, quality, max_kb, skip_marked, target_kb, strong)) for name in todo]
        for name, fu in futs:
            if cancel is not None and cancel():
                for _n, f2 in futs:
                    f2.cancel()
                raise RuntimeError('已取消')
            try:
                finish(name, fu.result())
            except Exception as e:  # noqa
                if log:
                    log('  略過無法處理的圖：%s（%s）' % (name, e))
    else:
        for name in todo:
            if cancel is not None and cancel():
                raise RuntimeError('已取消')
            try:
                finish(name, process_media(datas[name], max_edge, quality, max_kb, skip_marked, target_kb, strong))
            except Exception as e:  # noqa
                if log:
                    log('  略過無法處理的圖：%s（%s）' % (name, e))
    if n == 0:
        return None, os.path.getsize(src), os.path.getsize(src), 0
    os.makedirs(dst_dir, exist_ok=True)
    dst = _unique(os.path.join(dst_dir, os.path.splitext(os.path.basename(src))[0] + tag + os.path.splitext(src)[1]))
    with zipfile.ZipFile(dst, 'w') as zo:
        for it in infos:
            zo.writestr(it, datas[it.filename], compress_type=zipfile.ZIP_DEFLATED if it.compress_type else zipfile.ZIP_STORED)
    return dst, os.path.getsize(src), os.path.getsize(dst), n


def _unique(path):
    if not os.path.exists(path):
        return path
    stem, ext = os.path.splitext(path)
    k = 2
    while os.path.exists('%s (%d)%s' % (stem, k, ext)):
        k += 1
    return '%s (%d)%s' % (stem, k, ext)


def process_media(data, max_edge, quality, max_kb, skip_marked, target_kb=0, strong=False):
    """（在子程序執行）壓一張內嵌圖。回傳 (新 bytes, 副檔名) 或 None（不變）"""
    out, ext = compress_bytes(data, max_edge, quality, max_kb, skip_marked=skip_marked, target_kb=target_kb, strong=strong)
    return None if out is data else (out, ext)


def process_file(src, dst_dir, max_edge, quality, max_kb, skip_marked, target_kb=0, strong=False):
    """（在子程序執行）壓一個圖檔，回傳 (輸出路徑或 None, 原大小, 新大小)"""
    return compress_image(src, dst_dir, max_edge, quality, max_kb, skip_marked=skip_marked, target_kb=target_kb, strong=strong)


def _child_init(moddir=''):
    """子程序啟動：降低優先權（視窗不卡）；若主程式用的是線上更新版，子程序也改用更新版"""
    try:
        _watch_parent()
    except Exception:
        pass
    try:
        import ctypes
        k = ctypes.windll.kernel32
        k.SetPriorityClass(k.GetCurrentProcess(), 0x4000)     # BELOW_NORMAL_PRIORITY_CLASS
    except Exception:
        pass
    if moddir and os.path.isdir(moddir):
        import importlib.machinery
        import sys

        class _F:
            def find_spec(self, name, path=None, target=None):
                if name == 'photo_compress':
                    return importlib.machinery.PathFinder.find_spec(name, [moddir])
        sys.meta_path.insert(0, _F())
        sys.modules.pop('photo_compress', None)


ACTIVE_POOLS = []


def kill_all():
    """立刻結束所有背景壓縮程序（關閉視窗或按停止時用）"""
    for pool in list(ACTIVE_POOLS):
        try:
            for pr in list(getattr(pool, '_processes', {}).values()):
                try:
                    pr.terminate()
                except Exception:
                    pass
            pool.shutdown(wait=False)
        except Exception:
            pass
    del ACTIVE_POOLS[:]


def _watch_parent():
    """子程序：主程式一消失（被關掉或當掉）就自己結束，不留殘留程序"""
    import multiprocessing
    import threading
    pp = multiprocessing.parent_process()
    if pp is None:
        return

    def run():
        try:
            from multiprocessing.connection import wait
            wait([pp.sentinel])
        finally:
            os._exit(0)
    threading.Thread(target=run, daemon=True).start()


def make_pool(workers, log=None):
    """建立程序池；失敗就退回執行緒池（比較慢、畫面可能較卡，但能用）"""
    from concurrent.futures import ProcessPoolExecutor
    import sys
    try:
        if getattr(sys, 'frozen', False) and not getattr(sys, 'tb_mp_ok', False):
            # 舊版外殼（EXE）不支援多程序：硬開會讓每個子程序都重新啟動整個軟體，電腦會卡死
            raise RuntimeError('目前的 EXE 是舊版外殼，請用最新的「打包成EXE.bat」重新打包一次，才能使用多核心')
        moddir = ''
        try:
            import updater
            md = updater.module_dir()
            if os.path.abspath(__file__).lower().startswith(os.path.abspath(md).lower()):
                moddir = md
        except Exception:
            pass
        pool = ProcessPoolExecutor(max_workers=max(1, workers), initializer=_child_init, initargs=(moddir,))
        ACTIVE_POOLS.append(pool)
        pool.submit(abs, 1).result(timeout=90)               # 健康檢查
        return pool, True
    except Exception as e:  # noqa
        if log:
            log('多核心程序啟動失敗（%s），改用單程序多執行緒' % e)
        return ThreadPoolExecutor(max_workers=max(1, min(workers, 3)), initializer=low_priority), False


def default_workers():
    return max(1, min(os.cpu_count() or 2, 16))      # 子程序是低優先權，視窗不會被搶


def fmt_size(n):
    return '%.1f MB' % (n / 1048576.0) if n >= 1048576 else '%d KB' % round(n / 1024.0)
