# -*- coding: utf-8 -*-
"""照片壓縮：資料夾／圖檔／Word（docx 內嵌照片）。與視窗無關。
- 自動依 EXIF 轉正，縮小長邊、調整品質；可指定「每張不超過 N KB」。
- 壓完比原檔還大就直接沿用原檔，不會越壓越大。
- docx：只重壓 word/media 裡的 JPG／PNG，檔名與格式不變，版面不受影響。"""
import io
import os
import zipfile

from PIL import Image, ImageOps

IMG_EXT = ('.jpg', '.jpeg', '.png', '.bmp', '.tif', '.tiff', '.webp')
DOCX_EXT = ('.docx', '.docm')


def is_target(path):
    n = os.path.basename(path)
    if n.startswith('~$'):
        return False
    return n.lower().endswith(IMG_EXT + DOCX_EXT)


def _encode(im, fmt, quality, exif):
    buf = io.BytesIO()
    if fmt == 'PNG':
        im.save(buf, 'PNG', optimize=True)
    else:
        if im.mode not in ('RGB', 'L'):
            im = im.convert('RGB')
        kw = dict(quality=quality, optimize=True, progressive=False)
        if exif:
            kw['exif'] = exif
        im.save(buf, 'JPEG', **kw)
    return buf.getvalue()


def compress_bytes(data, max_edge=1920, quality=80, max_kb=0, force_jpeg=False):
    """回傳 (新的 bytes, 副檔名)。新的比較大就回傳原 bytes。"""
    im = Image.open(io.BytesIO(data))
    src_fmt = (im.format or '').upper()
    exif = None
    try:
        ex = im.getexif()
        if ex and 0x0112 in ex:
            im = ImageOps.exif_transpose(im)
            ex = im.getexif() if im.getexif() else ex
            ex[0x0112] = 1
        exif = ex.tobytes() if ex else None
    except Exception:
        exif = None
    has_alpha = im.mode in ('RGBA', 'LA') or (im.mode == 'P' and 'transparency' in im.info)
    fmt = 'PNG' if (src_fmt == 'PNG' and not force_jpeg) or has_alpha else 'JPEG'
    if max_edge and max(im.size) > max_edge:
        r = max_edge / float(max(im.size))
        im = im.resize((max(1, round(im.width * r)), max(1, round(im.height * r))), Image.LANCZOS)
    out = _encode(im, fmt, quality, exif)
    if max_kb and fmt == 'JPEG':
        q, tries = quality, 0
        while len(out) > max_kb * 1024 and tries < 12:
            if q > 45:
                q -= 5
            else:                       # 品質已很低 → 再縮小 10%
                im = im.resize((max(1, int(im.width * 0.9)), max(1, int(im.height * 0.9))), Image.LANCZOS)
            out = _encode(im, fmt, q, exif)
            tries += 1
    ext = '.png' if fmt == 'PNG' else '.jpg'
    same_kind = (src_fmt == 'PNG') == (fmt == 'PNG') and (src_fmt in ('JPEG', 'PNG'))
    if same_kind and len(out) >= len(data):
        return data, ext
    return out, ext


def compress_image(src, dst_dir, max_edge=1920, quality=80, max_kb=0, tag=''):
    """壓一張圖，存到 dst_dir，回傳 (輸出路徑, 原大小, 新大小)"""
    data = open(src, 'rb').read()
    out, ext = compress_bytes(data, max_edge, quality, max_kb, force_jpeg=src.lower().endswith(('.bmp', '.tif', '.tiff', '.webp')))
    os.makedirs(dst_dir, exist_ok=True)
    stem = os.path.splitext(os.path.basename(src))[0] + tag
    low = os.path.splitext(src)[1].lower()
    if out is data:
        ext = low
    dst = _unique(os.path.join(dst_dir, stem + ext))
    with open(dst, 'wb') as f:
        f.write(out)
    return dst, len(data), len(out)


def compress_docx(src, dst_dir, max_edge=1920, quality=80, max_kb=0, log=None, cancel=None, tag=''):
    """重壓 docx 內嵌照片，回傳 (輸出路徑, 原大小, 新大小, 張數)"""
    os.makedirs(dst_dir, exist_ok=True)
    dst = _unique(os.path.join(dst_dir, os.path.splitext(os.path.basename(src))[0] + tag + os.path.splitext(src)[1]))
    n = 0
    with zipfile.ZipFile(src) as zi, zipfile.ZipFile(dst, 'w') as zo:
        for it in zi.infolist():
            if cancel is not None and cancel():
                raise RuntimeError('已取消')
            data = zi.read(it.filename)
            low = it.filename.lower()
            if low.startswith('word/media/') and low.endswith(('.jpg', '.jpeg', '.png')):
                try:
                    out, ext = compress_bytes(data, max_edge, quality, max_kb)
                    keep_png = low.endswith('.png')
                    if out is not data and (ext == '.png') == keep_png:   # 格式要和副檔名一致，不改 rels
                        data = out
                        n += 1
                except Exception as e:  # noqa
                    if log:
                        log('  略過無法處理的圖：%s（%s）' % (it.filename, e))
            zo.writestr(it, data, compress_type=zipfile.ZIP_DEFLATED if it.compress_type else zipfile.ZIP_STORED)
    return dst, os.path.getsize(src), os.path.getsize(dst), n


def _unique(path):
    if not os.path.exists(path):
        return path
    stem, ext = os.path.splitext(path)
    k = 2
    while os.path.exists('%s (%d)%s' % (stem, k, ext)):
        k += 1
    return '%s (%d)%s' % (stem, k, ext)


def fmt_size(n):
    return '%.1f MB' % (n / 1048576.0) if n >= 1048576 else '%d KB' % round(n / 1024.0)
