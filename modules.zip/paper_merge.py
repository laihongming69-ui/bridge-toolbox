# -*- coding: utf-8 -*-
"""汛期前外業紙表：汛期前檢測表的非汛期構件 + 汛期後檢測表的汛期後構件 → 新的一份"""
import copy
import os
import re
import tempfile
import zipfile
import collections

from lxml import etree

import bridge_tidy as bt
from bridge_tidy import NS, W, R, REL_NS, txt, is_defect_table, is_summary_table, is_post_item

RELS_PATH = 'word/_rels/document.xml.rels'
IMG_TYPE = '/image'


def _load(path):
    z = zipfile.ZipFile(path)
    files = {n: z.read(n) for n in z.namelist()}
    order = z.namelist()
    z.close()
    root = etree.fromstring(files['word/document.xml'])
    rels = etree.fromstring(files[RELS_PATH])
    return files, order, root, rels


def _cover(body):
    for t in body.iter(W + 'tbl'):
        rs = t.findall('w:tr', NS)
        if rs and txt(rs[0].findall('w:tc', NS)[0]) == '橋梁名稱':
            return t
    return None


def _field(cover, label):
    if cover is None:
        return ''
    for r in cover.findall('w:tr', NS):
        cells = [txt(c) for c in r.findall('w:tc', NS)]
        for k, x in enumerate(cells):
            if x.replace(' ', '') == label and k + 1 < len(cells):
                return cells[k + 1].strip()
    return ''


def info(path):
    """回傳 (橋梁編號, 橋名, 檢測日期)"""
    z = zipfile.ZipFile(path)
    root = etree.fromstring(z.read('word/document.xml'))
    z.close()
    cv = _cover(root.find('w:body', NS))
    name = ''
    if cv is not None:
        cells = [txt(c) for c in cv.findall('w:tr', NS)[0].findall('w:tc', NS)]
        name = cells[1] if len(cells) > 1 else ''
    return _field(cv, '橋梁編號'), name, _field(cv, '檢測日期')


class Importer:
    """把另一份 docx 的元素搬進目標檔，圖片關聯重新編號"""

    def __init__(self, src_files, src_rels, dst_files, dst_rels, tag):
        self.sf, self.sr, self.df, self.dr, self.tag = src_files, src_rels, dst_files, dst_rels, tag
        self.map = {}
        self.src = {r.get('Id'): r for r in src_rels}
        self.n = 0
        ct = etree.fromstring(dst_files['[Content_Types].xml'])
        self.ct = ct
        self.exts = {d.get('Extension', '').lower() for d in ct if d.tag.endswith('Default')}

    def rid(self, old):
        if old in self.map:
            return self.map[old]
        r = self.src.get(old)
        new = old
        if r is not None and r.get('Type', '').endswith(IMG_TYPE) and r.get('TargetMode') != 'External':
            t = r.get('Target')
            sname = 'word/' + t if not t.startswith('/') else t[1:]
            data = self.sf.get(sname)
            if data is not None:
                self.n += 1
                base = os.path.basename(t)
                dname = 'word/media/%s_%d_%s' % (self.tag, self.n, base)
                self.df[dname] = data
                new = 'rId%s%d' % (self.tag, self.n)
                el = etree.SubElement(self.dr, '{%s}Relationship' % REL_NS)
                el.set('Id', new)
                el.set('Type', r.get('Type'))
                el.set('Target', dname[5:])
                ext = base.rsplit('.', 1)[-1].lower()
                if ext not in self.exts:
                    mime = {'png': 'image/png', 'jpg': 'image/jpeg', 'jpeg': 'image/jpeg', 'gif': 'image/gif',
                            'bmp': 'image/bmp', 'tif': 'image/tiff', 'tiff': 'image/tiff', 'emf': 'image/x-emf',
                            'wmf': 'image/x-wmf'}.get(ext, 'application/octet-stream')
                    d = etree.SubElement(self.ct, '{http://schemas.openxmlformats.org/package/2006/content-types}Default')
                    d.set('Extension', ext)
                    d.set('ContentType', mime)
                    self.exts.add(ext)
        self.map[old] = new
        return new

    def clone(self, el):
        el = copy.deepcopy(el)
        for e in el.iter():
            for k, v in list(e.attrib.items()):
                if k.startswith(R) and v in self.src:
                    e.set(k, self.rid(v))
        return el

    def finish(self):
        self.df['[Content_Types].xml'] = etree.tostring(self.ct, xml_declaration=True, encoding='UTF-8', standalone=True)


def _item_of_card(t):
    rs = t.findall('w:tr', NS)
    v = [txt(x) for x in rs[1].findall('w:tc', NS)]
    return v[0] if v else ''


def _item_of_summary(t):
    return txt(t.findall('w:tr', NS)[0])[4:].strip()


def merge(pre_path, post_path, dst_tmp, log=print):
    """合成一份暫存 docx（未整理），回傳 dst_tmp"""
    pf, order, proot, prels = _load(pre_path)
    qf, _o, qroot, qrels = _load(post_path)
    pbody, qbody = proot.find('w:body', NS), qroot.find('w:body', NS)
    imp = Importer(qf, qrels, pf, prels, 'Q')

    # 封面：用汛期後那份
    c1, c2 = _cover(pbody), _cover(qbody)
    if c1 is not None and c2 is not None:
        c1.getparent().replace(c1, imp.clone(c2))
        log('封面：使用汛期後那份')

    # 總表：汛期後構件整張換成汛期後那份的
    post_sum = {}
    for t in qbody.iter(W + 'tbl'):
        if is_summary_table(t) and is_post_item(_item_of_summary(t)):
            post_sum[_item_of_summary(t).replace('／', '/')] = t
    done = []
    for t in list(pbody.iter(W + 'tbl')):
        if is_summary_table(t):
            nm = _item_of_summary(t)
            if is_post_item(nm) and nm.replace('／', '/') in post_sum:
                t.getparent().replace(t, imp.clone(post_sum.pop(nm.replace('／', '/'))))
                done.append(nm)
    log('總表：汛期後構件換成汛期後版本（%s）' % '、'.join(done))
    for nm in post_sum:
        log('提醒：汛期前那份找不到「%s」的總表，沒有放進去' % nm)

    # 缺失卡：汛期前的汛期後構件丟掉，換成汛期後那份的
    drop = [t for t in pbody.iter(W + 'tbl') if is_defect_table(t) and is_post_item(_item_of_card(t))]
    for t in drop:
        bt.remove_with_spacer(t)
    cards = [t for t in qbody.iter(W + 'tbl') if is_defect_table(t) and is_post_item(_item_of_card(t))]
    sect = list(pbody)[-1]
    for t in cards:
        sect.addprevious(imp.clone(t))
        sect.addprevious(etree.fromstring('<w:p xmlns:w="%s"/>' % NS['w']))
    log('缺失卡：汛期前的汛期後構件 %d 張換成汛期後的 %d 張' % (len(drop), len(cards)))

    imp.finish()
    pf['word/document.xml'] = etree.tostring(proot, xml_declaration=True, encoding='UTF-8', standalone=True)
    pf[RELS_PATH] = etree.tostring(prels, xml_declaration=True, encoding='UTF-8', standalone=True)
    with zipfile.ZipFile(dst_tmp, 'w', zipfile.ZIP_DEFLATED) as z:
        for n in order:
            if n in pf:
                z.writestr(n, pf[n])
        for n in pf:
            if n not in order:
                z.writestr(n, pf[n])
    return dst_tmp


def pair_files(paths, log=print):
    """依橋梁編號配對；同編號日期早的＝汛期前，晚的＝汛期後。回傳 [(pre, post)]"""
    g = collections.OrderedDict()
    for p in paths:
        try:
            bid, name, date = info(p)
        except Exception as e:
            log('讀不到封面：%s（%s）' % (os.path.basename(p), e))
            continue
        g.setdefault(bid or name or os.path.basename(p), []).append((date, p))
    out = []
    for k, lst in g.items():
        lst.sort()
        if len(lst) < 2:
            log('略過：%s 只有一份（%s），需要汛期前＋汛期後兩份' % (k, os.path.basename(lst[0][1])))
            continue
        if len(lst) > 2:
            log('提醒：%s 有 %d 份，取日期最早的當汛期前、最晚的當汛期後' % (k, len(lst)))
        if lst[0][0] == lst[-1][0]:
            log('略過：%s 兩份的檢測日期相同（%s），分不出前後' % (k, lst[0][0]))
            continue
        out.append((lst[0][1], lst[-1][1]))
    return out


def make(pre, post, dst, tidy_kw, log=print):
    tmp = os.path.join(tempfile.gettempdir(), 'paper_merge_%d.docx' % os.getpid())
    merge(pre, post, tmp, log)
    try:
        bt.process(tmp, dst, log=log, **tidy_kw)
    finally:
        try:
            os.remove(tmp)
        except OSError:
            pass
