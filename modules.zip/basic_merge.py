# -*- coding: utf-8 -*-
"""
橋梁基本資料整理工具 v1.1.1
把「公路橋梁資訊系統」匯出的壓縮檔（內含 基本／構件／橋孔／橋墩／擴建 資料 5 個 .doc）
合併成「單一個 Word（.docx）」，並且只保留最新的 N 張照片（預設 4 張）。

用法：雙擊「執行.bat」開視窗，把 zip 拖進去；或命令列
      python basic_merge.py 檔案.zip --keep 4 --out D:\\輸出
"""
import argparse
import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import urllib.request
import zipfile
from urllib.parse import unquote, urlparse

ORDER = ['基本資料', '構件資料', '橋孔資料', '橋墩資料', '擴建資料']   # 合併順序
PAGE_BREAK = ("\n<p class=MsoNormal style='page-break-before:always'><span lang=EN-US>"
              "&nbsp;</span></p>\n")


# ----------------------------------------------------------------------------
# 讀取壓縮檔 / 資料夾 / .doc
# ----------------------------------------------------------------------------
def fix_name(n):
    try:
        return n.encode('cp437').decode('utf8')
    except Exception:
        pass
    try:
        return n.encode('cp437').decode('cp950')
    except Exception:
        return n


def read_text(b):
    for enc in ('utf-8-sig', 'cp950', 'big5hkscs'):
        try:
            return b.decode(enc)
        except Exception:
            continue
    return b.decode('utf-8', 'replace')


def bridge_name(fname):
    m = re.match(r'^\[(.+?)\]_', os.path.basename(fname))
    if m:
        return m.group(1)
    base = os.path.splitext(os.path.basename(fname))[0]
    return re.split(r'_(?:基本|構件|橋孔|橋墩|擴建)資料', base)[0] or base


def kind_of(fname):
    for k in ORDER:
        if k in fname:
            return k
    return None


def load_sources(paths):
    """回傳 {橋名: {種類: html字串}}"""
    out = {}

    def put(fname, data):
        k = kind_of(fname)
        if not k:
            return
        txt = read_text(data)
        if '<html' not in txt[:3000].lower() and '<body' not in txt.lower():
            return
        out.setdefault(bridge_name(fname), {})[k] = txt
    for p in paths:
        p = p.strip('"')
        if os.path.isdir(p):
            for root, _d, fs in os.walk(p):
                for f in fs:
                    fp = os.path.join(root, f)
                    if f.lower().endswith('.zip'):
                        _from_zip(fp, put)
                    elif f.lower().endswith(('.doc', '.htm', '.html')):
                        put(f, open(fp, 'rb').read())
        elif p.lower().endswith('.zip'):
            _from_zip(p, put)
        elif p.lower().endswith(('.doc', '.htm', '.html')):
            put(os.path.basename(p), open(p, 'rb').read())
    return out


def _from_zip(path, put):
    with zipfile.ZipFile(path) as z:
        for i in z.infolist():
            if i.is_dir():
                continue
            name = i.filename if i.flag_bits & 0x800 else fix_name(i.filename)
            put(os.path.basename(name), z.read(i))


# ----------------------------------------------------------------------------
# HTML 處理：照片篩選、合併
# ----------------------------------------------------------------------------
TABLE_RE = re.compile(r'<table\b(?:(?!<table\b).)*?</table>', re.S | re.I)
DATE_RE = re.compile(r'拍照日期.*?<div[^>]*>\s*(\d{4})[-/](\d{1,2})[-/](\d{1,2})', re.S)
SRC_RE = re.compile(r'(<img\b[^>]*?\bsrc\s*=\s*)(["\'])(.*?)\2', re.S | re.I)
STAMP_RE = re.compile(r'(20\d{12}|19\d{12})')


def photo_date(tbl):
    m = DATE_RE.search(tbl)
    if m:
        return '%04d%02d%02d' % tuple(map(int, m.groups()))
    s = SRC_RE.search(tbl)
    if s:
        t = STAMP_RE.search(s.group(3))
        if t:
            return t.group(1)[:8]
    return '00000000'


def keep_newest_photos(html, keep):
    """只留拍照日期最新的 keep 張照片，回傳 (新 html, 原張數, 保留日期集合)"""
    ms = [m for m in TABLE_RE.finditer(html) if re.search(r'<img\b', m.group(0), re.I)]
    n = len(ms)
    if n == 0 or keep is None or n <= keep:
        return html, n, {photo_date(m.group(0)) for m in ms}
    dates = [photo_date(m.group(0)) for m in ms]
    order = sorted(range(n), key=lambda i: (-int(dates[i]), i))   # 新→舊，同日依原順序
    keep_idx = set(order[:keep])
    out, pos = [], 0
    for i, m in enumerate(ms):
        nxt = ms[i + 1].start() if i + 1 < n else None
        gap_end = nxt if nxt is not None else m.end()
        out.append(html[pos:m.start()])
        if i in keep_idx:
            out.append(m.group(0))
            gap = html[m.end():gap_end] if nxt is not None else ''
            # 後面接的是被刪的照片 => 不要留下分頁用的空段落
            if nxt is not None and (i + 1) in keep_idx:
                out.append(gap)
            elif nxt is not None:
                out.append('\n<br/>\n')
        pos = gap_end if nxt is not None else m.end()
    out.append(html[pos:])
    return ''.join(out), n, {dates[i] for i in keep_idx}


def body_inner(html):
    m = re.search(r'<body[^>]*>(.*)</body>', html, re.S | re.I)
    inner = m.group(1) if m else html
    inner = re.sub(r'^\s*<div class=WordSection1>', '', inner, count=1)
    inner = re.sub(r'</div>\s*$', '', inner, count=1)
    return inner


def merge_html(docs):
    """docs: [html字串...] 依序合併；以第一份的 head 為準"""
    first = docs[0]
    m = re.search(r'<body[^>]*>', first, re.I)
    head = first[:m.end()]
    parts = [head, '\n<div class=WordSection1>\n']
    for i, d in enumerate(docs):
        if i:
            parts.append(PAGE_BREAK)
        parts.append(body_inner(d))
    parts.append('\n</div>\n</body>\n</html>\n')
    return ''.join(parts)


# ----------------------------------------------------------------------------
# 照片下載 / 嵌入
# ----------------------------------------------------------------------------
def _ssl_context(strict=True, verify=True):
    import ssl
    ctx = ssl.create_default_context()
    if not strict and hasattr(ssl, 'VERIFY_X509_STRICT'):
        # Python 3.13+ 預設很嚴格，政府網站憑證少了 Subject Key Identifier 會被擋；
        # 這裡只放寬這項嚴格檢查，仍然會驗證憑證鏈與網域
        ctx.verify_flags &= ~ssl.VERIFY_X509_STRICT
    if not verify:
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
    return ctx


_JAR = None
_WARMED = set()
BROWSER_HEADERS = {
    'User-Agent': ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
                   'Chrome/124.0.0.0 Safari/537.36'),
    'Accept': 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8',
    'Accept-Language': 'zh-TW,zh;q=0.9,en;q=0.8',
}


def is_image(data):
    """用檔頭判斷是不是真的圖片（伺服器的防機器人驗證頁是 HTML，不是圖片）"""
    d = bytes(data[:16])
    return (d[:3] == b'\xff\xd8\xff' or d[:8] == b'\x89PNG\r\n\x1a\n' or d[:4] == b'GIF8'
            or d[:2] == b'BM' or (d[:4] == b'RIFF' and d[8:12] == b'WEBP')
            or d[:4] in (b'II*\x00', b'MM\x00*'))


def _fetch_py(url, timeout=30):
    """Python 內建下載：瀏覽器標頭＋cookie；憑證問題分三階段放寬（只對 thb.gov.tw）"""
    import http.cookiejar
    import ssl
    global _JAR
    if _JAR is None:
        _JAR = http.cookiejar.CookieJar()
    u = urlparse(url)
    root = '%s://%s/' % (u.scheme, u.netloc)
    headers = dict(BROWSER_HEADERS)
    headers['Referer'] = root
    host = (u.hostname or '').lower()
    steps = ((True, True), (False, True), (False, False)) if url.lower().startswith('https://') else ((True, True),)
    last = None
    for strict, verify in steps:
        # 最後一招（不驗證憑證）只對公路局照片網站 thb.gov.tw 使用
        if not verify and not host.endswith('thb.gov.tw'):
            break
        handlers = [urllib.request.HTTPCookieProcessor(_JAR)]
        if url.lower().startswith('https://'):
            handlers.append(urllib.request.HTTPSHandler(context=_ssl_context(strict, verify)))
        op = urllib.request.build_opener(*handlers)
        try:
            if u.netloc not in _WARMED:      # 先逛一下首頁拿 cookie，像一般瀏覽器
                _WARMED.add(u.netloc)
                try:
                    op.open(urllib.request.Request(root, headers=dict(headers, Accept='text/html,*/*')), timeout=15).read(2000)
                except Exception:
                    pass
            with op.open(urllib.request.Request(url, headers=headers), timeout=timeout) as r:
                return r.read()
        except Exception as e:  # noqa
            last = e
            reason = getattr(e, 'reason', e)
            if not isinstance(reason, ssl.SSLError):
                raise
    raise last


def _fetch_curl(url, timeout=30):
    """備援：用系統的 curl（Windows 10/11 內建 curl.exe，網路指紋與 Python 不同，常能通過防機器人檢查）"""
    exe = shutil.which('curl.exe') or shutil.which('curl')
    if not exe:
        raise RuntimeError('找不到 curl')
    u = urlparse(url)
    cmd = [exe, '-sS', '-L', '--max-time', str(timeout), '--ssl-no-revoke',
           '-A', BROWSER_HEADERS['User-Agent'], '-H', 'Accept: ' + BROWSER_HEADERS['Accept'],
           '-H', 'Accept-Language: ' + BROWSER_HEADERS['Accept-Language'],
           '-e', '%s://%s/' % (u.scheme, u.netloc)]
    if (u.hostname or '').lower().endswith('thb.gov.tw'):
        cmd.append('-k')
    cmd.append(url)
    flags = getattr(subprocess, 'CREATE_NO_WINDOW', 0)
    r = subprocess.run(cmd, capture_output=True, timeout=timeout + 10, creationflags=flags)
    if r.returncode != 0:
        raise RuntimeError('curl 失敗：%s' % r.stderr.decode('utf8', 'ignore').strip()[:80])
    return r.stdout


def fetch(url, timeout=30):
    """下載圖片並確認真的是圖片；伺服器回防機器人網頁時換方法重試，仍不行就丟出錯誤"""
    errs = []
    for fn in (_fetch_py, _fetch_curl):
        try:
            data = fn(url, timeout)
            if is_image(data):
                return data
            errs.append('伺服器回傳驗證網頁，不是圖片')
        except Exception as e:  # noqa
            errs.append(str(e)[:80])
    raise RuntimeError('；'.join(dict.fromkeys(errs)))


def download_images(html, workdir, log, fetcher=fetch):
    """把 <img src=http...> 下載到 workdir/photos，並改成相對路徑；失敗的保留原網址"""
    os.makedirs(os.path.join(workdir, 'photos'), exist_ok=True)
    cache, ok, bad = {}, 0, 0

    def rep(m):
        nonlocal ok, bad
        url = m.group(3)
        if not url.lower().startswith(('http://', 'https://')):
            return m.group(0)
        if url not in cache:
            name = os.path.basename(unquote(urlparse(url).path)) or 'img%d.jpg' % len(cache)
            name = '%03d_%s' % (len(cache), re.sub(r'[^\w.\-]', '_', name))
            try:
                data = fetcher(url)
                open(os.path.join(workdir, 'photos', name), 'wb').write(data)
                cache[url] = 'photos/' + name
                ok += 1
            except Exception as e:  # noqa
                cache[url] = None
                bad += 1
                log('  照片下載失敗：%s（%s）' % (os.path.basename(url), e))
        local = cache[url]
        return m.group(0) if not local else '%s%s%s%s' % (m.group(1), m.group(2), local, m.group(2))
    html = SRC_RE.sub(rep, html)
    return html, ok, bad


def embed_external_images(docx, base_dir, log, fetcher=fetch):
    """把 docx 裡「外部連結」的圖片（網址或本機路徑）抓回來嵌進檔案，回傳嵌入張數"""
    from lxml import etree
    zin = zipfile.ZipFile(docx)
    files = {n: zin.read(n) for n in zin.namelist()}
    order = zin.namelist()
    zin.close()
    rp = 'word/_rels/document.xml.rels'
    root = etree.fromstring(files[rp])
    ns = 'http://schemas.openxmlformats.org/package/2006/relationships'
    n_ok = n_bad = 0
    existing = [int(m.group(1)) for n in files for m in [re.match(r'word/media/embed(\d+)\.', n)] if m]
    seq = max(existing + [0])
    changed = False
    done_ids = []
    for rel in root.findall('{%s}Relationship' % ns):
        if rel.get('TargetMode') != 'External' or not rel.get('Type', '').endswith('/image'):
            continue
        t = rel.get('Target')
        data = None
        try:
            if t.lower().startswith(('http://', 'https://')):
                data = fetcher(t)
            else:
                if t.lower().startswith('file:'):
                    from urllib.request import url2pathname
                    p = url2pathname(urlparse(t).path)
                else:
                    p = unquote(t)
                if not os.path.isabs(p):
                    p = os.path.join(base_dir, p)
                data = open(p, 'rb').read()
        except Exception as e:  # noqa
            n_bad += 1
            log('  照片無法嵌入（保留連結）：%s（%s）' % (os.path.basename(t), e))
            continue
        if not is_image(data):
            n_bad += 1
            log('  照片無法嵌入（保留連結）：%s（不是圖片）' % os.path.basename(t))
            continue
        ext = os.path.splitext(urlparse(t).path)[1].lower() or '.jpg'
        if ext not in ('.jpg', '.jpeg', '.png', '.gif', '.bmp'):
            ext = '.jpg'
        seq += 1
        name = 'embed%d%s' % (seq, ext)
        files['word/media/' + name] = data
        rel.set('Target', 'media/' + name)
        del rel.attrib['TargetMode']
        done_ids.append(rel.get('Id'))
        n_ok += 1
        changed = True
    if changed:
        # 用 XML 解析器改屬性（不用文字取代，避免改壞）：連結圖片 (r:link) 改成嵌入 (r:embed)
        R = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
        try:
            parser = etree.XMLParser(huge_tree=True, resolve_entities=False)
            droot = etree.fromstring(files['word/document.xml'], parser)
            want = set(done_ids)
            for el in droot.iter():
                lk = el.get('{%s}link' % R)
                if lk in want:
                    del el.attrib['{%s}link' % R]
                    el.set('{%s}embed' % R, lk)
            newdoc = etree.tostring(droot, xml_declaration=True, encoding='UTF-8', standalone=True)
            etree.fromstring(newdoc, parser)
        except Exception as ex:  # noqa
            log('  警告：嵌入照片時文件結構異常（%s），已取消嵌入、保留連結' % str(ex)[:80])
            return 0, n_ok + n_bad
        files['word/document.xml'] = newdoc
        files[rp] = etree.tostring(root, xml_declaration=True, encoding='UTF-8', standalone=True)
        ct = files['[Content_Types].xml'].decode('utf8')
        for ext, mime in (('jpg', 'image/jpeg'), ('jpeg', 'image/jpeg'), ('png', 'image/png'),
                          ('gif', 'image/gif'), ('bmp', 'image/bmp')):
            if 'Extension="%s"' % ext not in ct and any(n.lower().endswith('.' + ext) for n in files):
                ct = ct.replace('</Types>', '<Default Extension="%s" ContentType="%s"/></Types>' % (ext, mime))
        files['[Content_Types].xml'] = ct.encode('utf8')
        with zipfile.ZipFile(docx, 'w', zipfile.ZIP_DEFLATED) as z:
            for n in order + [n for n in files if n not in order]:
                z.writestr(n, files[n])
    return n_ok, n_bad


# ----------------------------------------------------------------------------
# 轉成 docx 的引擎（Word 優先，沒有就用 LibreOffice）
# ----------------------------------------------------------------------------
def find_soffice():
    import glob
    for n in ('soffice', 'soffice.exe', 'libreoffice'):
        p = shutil.which(n)
        if p:
            return p
    for base in (os.environ.get('ProgramFiles', r'C:\Program Files'),
                 os.environ.get('ProgramFiles(x86)', r'C:\Program Files (x86)')):
        for p in glob.glob(os.path.join(base, 'LibreOffice*', 'program', 'soffice.exe')):
            return p
    return None


class WordEngine:
    name = 'Microsoft Word'

    @staticmethod
    def available():
        if os.name != 'nt':
            return False
        try:
            import win32com.client  # noqa
            import winreg
            winreg.CloseKey(winreg.OpenKey(winreg.HKEY_CLASSES_ROOT, 'Word.Application'))
            return True
        except Exception:
            return False

    def __init__(self):
        import pythoncom
        import win32com.client
        pythoncom.CoInitialize()
        self.pythoncom = pythoncom
        self.app = win32com.client.DispatchEx('Word.Application')
        self.app.Visible = False
        self.app.DisplayAlerts = 0

    def html_to_docx(self, html_path, docx_path):
        doc = self.app.Documents.Open(html_path, False, True, False)
        try:
            # 下載失敗而保留網址的照片：讓 Word 自己抓，並要求把圖片存進文件
            for coll, typ in ((doc.InlineShapes, 4), (doc.Shapes, 11)):
                try:
                    for sh in list(coll):
                        try:
                            if sh.Type == typ:
                                sh.LinkFormat.SavePictureWithDocument = True
                        except Exception:
                            pass
                except Exception:
                    pass
            doc.SaveAs2(docx_path, 16)  # wdFormatXMLDocument
        finally:
            doc.Close(0)

    def close(self):
        try:
            self.app.Quit(0)
        except Exception:
            pass
        try:
            self.pythoncom.CoUninitialize()
        except Exception:
            pass


class LibreEngine:
    name = 'LibreOffice'

    @staticmethod
    def available():
        return find_soffice() is not None

    def __init__(self):
        self.exe = find_soffice()
        self.profile = tempfile.mkdtemp(prefix='lo_profile_')

    def html_to_docx(self, html_path, docx_path):
        outdir = tempfile.mkdtemp(prefix='lo_out_')
        try:
            uri = 'file:///' + self.profile.replace('\\', '/').lstrip('/')
            cmd = [self.exe, '-env:UserInstallation=' + uri, '--headless', '--norestore',
                   '--infilter=HTML (StarWriter)', '--convert-to', 'docx:MS Word 2007 XML',
                   '--outdir', outdir, html_path]
            flags = 0x08000000 if os.name == 'nt' else 0
            subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                           timeout=900, creationflags=flags)
            out = os.path.join(outdir, os.path.splitext(os.path.basename(html_path))[0] + '.docx')
            if not os.path.exists(out):
                raise RuntimeError('LibreOffice 沒有產生 Word 檔')
            shutil.move(out, docx_path)
        finally:
            shutil.rmtree(outdir, ignore_errors=True)

    def close(self):
        shutil.rmtree(self.profile, ignore_errors=True)


def pick_engine():
    if WordEngine.available():
        return WordEngine
    if LibreEngine.available():
        return LibreEngine
    return None


# ----------------------------------------------------------------------------
# 主流程
# ----------------------------------------------------------------------------
def safe_name(s):
    return re.sub(r'[\\/:*?"<>|]', '_', s).strip() or 'output'


def build_one(name, docs, outdir, keep=4, embed=True, engine=None, log=print, fetcher=fetch):
    kinds = [k for k in ORDER if k in docs]
    extra = [k for k in docs if k not in ORDER]
    missing = [k for k in ORDER if k not in docs]
    log('合併 %d 個檔案：%s' % (len(kinds) + len(extra), '、'.join(kinds + extra)))
    if missing:
        log('  注意：缺少 %s' % '、'.join(missing))
    htmls, total_photos, kept_dates = [], 0, set()
    for k in kinds + extra:
        h, n, dates = keep_newest_photos(docs[k], keep)
        total_photos += n
        if n:
            kept_dates |= dates
        htmls.append(h)
    if total_photos:
        shown = min(total_photos, keep) if keep is not None else total_photos
        log('照片：原有 %d 張，保留最新 %d 張（拍照日期 %s）' % (
            total_photos, shown, '、'.join(sorted(kept_dates, reverse=True)[:3])))
    work = tempfile.mkdtemp(prefix='bm_')
    try:
        merged = merge_html(htmls)
        if embed:
            merged, ok, bad = download_images(merged, work, log, fetcher)
            if ok or bad:
                log('照片下載：成功 %d 張%s' % (ok, '、失敗 %d 張' % bad if bad else ''))
        hp = os.path.join(work, 'merged.html')
        open(hp, 'w', encoding='utf-8').write(merged)
        own = engine is None
        eng = engine or pick_engine()
        if eng is None:
            raise RuntimeError('找不到 Microsoft Word 或 LibreOffice，無法轉成 Word')
        e = eng() if isinstance(eng, type) else eng
        try:
            tmp_docx = os.path.join(work, 'merged.docx')
            log('轉成 Word（%s）…' % e.name)
            e.html_to_docx(hp, tmp_docx)
        finally:
            if own or isinstance(eng, type):
                e.close()
        if embed:
            ok, bad = embed_external_images(tmp_docx, work, log, fetcher)
            if ok or bad:
                log('照片嵌入 Word：%d 張%s' % (ok, '（%d 張保留連結）' % bad if bad else ''))
        os.makedirs(outdir, exist_ok=True)
        base = safe_name(name)
        if not base.endswith('_基本資料'):
            base += '_基本資料'
        dst = os.path.join(outdir, base + '.docx')
        shutil.copyfile(tmp_docx, dst)
        log('完成：%s（%.1f MB）' % (os.path.basename(dst), os.path.getsize(dst) / 1e6))
        return dst
    finally:
        shutil.rmtree(work, ignore_errors=True)


def run_paths(paths, outdir=None, keep=4, embed=True, log=print, on_item=None, fetcher=fetch):
    srcs = load_sources(paths)
    if not srcs:
        raise RuntimeError('壓縮檔裡找不到橋梁資料（基本／構件／橋孔／橋墩／擴建資料 的 .doc）')
    results = []
    Eng = pick_engine()
    if Eng is None:
        raise RuntimeError('找不到 Microsoft Word 或 LibreOffice，無法轉成 Word')
    eng = Eng()
    try:
        for name, docs in srcs.items():
            log('== ' + name)
            od = outdir or os.path.dirname(os.path.abspath(paths[0]))
            try:
                results.append(build_one(name, docs, od, keep, embed, eng, log, fetcher))
                if on_item:
                    on_item(name, True, '')
            except Exception as e:  # noqa
                log('失敗：%s' % e)
                if on_item:
                    on_item(name, False, str(e))
    finally:
        eng.close()
    return results


# ----------------------------------------------------------------------------
# 視窗
# ----------------------------------------------------------------------------
def run_gui():
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk

    try:
        from tkinterdnd2 import TkinterDnD, DND_FILES
        root = TkinterDnD.Tk()
        dnd = True
    except Exception:
        root = tk.Tk()
        dnd = False

    BG, CARD, LINE = '#F3F7F5', '#FFFFFF', '#DCE6E0'
    ACC, ACC_D, ACC_L = '#1B7F5C', '#146347', '#E6F4EE'
    TXT, SUB = '#1F2937', '#6B7280'
    FONT = 'Microsoft JhengHei UI'

    root.title('橋梁基本資料整理')
    root.geometry('900x760')
    root.minsize(800, 680)
    root.configure(bg=BG)
    try:
        base = getattr(sys, '_MEIPASS', os.path.dirname(os.path.abspath(__file__)))
        root.iconbitmap(os.path.join(base, 'icon.ico'))
    except Exception:
        pass
    st = ttk.Style()
    try:
        st.theme_use('clam')
    except Exception:
        pass
    st.configure('Card.TCheckbutton', background=CARD, foreground=TXT, font=(FONT, 10))
    st.map('Card.TCheckbutton', background=[('active', CARD)])
    st.configure('Card.TRadiobutton', background=CARD, foreground=TXT, font=(FONT, 10))
    st.map('Card.TRadiobutton', background=[('active', CARD)])
    st.configure('Card.TLabel', background=CARD, foreground=TXT, font=(FONT, 10))
    st.configure('Acc.Horizontal.TProgressbar', troughcolor=LINE, background=ACC, bordercolor=LINE,
                 lightcolor=ACC, darkcolor=ACC)

    items = []
    busy = {'v': False}
    last = {'dir': None}

    head = tk.Frame(root, bg=ACC)
    head.pack(fill='x')
    tk.Label(head, text='橋梁基本資料整理', bg=ACC, fg='white', font=(FONT, 18, 'bold')).pack(
        anchor='w', padx=24, pady=(14, 0))
    tk.Label(head, text='壓縮檔 → 單一 Word　・　只留最新的照片', bg=ACC, fg='#CBEBDD',
             font=(FONT, 10)).pack(anchor='w', padx=24, pady=(2, 14))
    body = tk.Frame(root, bg=BG)
    body.pack(fill='both', expand=True, padx=20, pady=14)

    def card(parent, title, expand=False):
        o = tk.Frame(parent, bg=CARD, highlightthickness=1, highlightbackground=LINE)
        o.pack(fill='both' if expand else 'x', expand=expand, pady=(0, 10))
        tk.Label(o, text=title, bg=CARD, fg=TXT, font=(FONT, 11, 'bold')).pack(anchor='w', padx=14, pady=(10, 4))
        i = tk.Frame(o, bg=CARD)
        i.pack(fill='both', expand=True, padx=14, pady=(0, 12))
        return i

    def button(parent, text, cmd, primary=False, size=10):
        bgc, hov = (ACC, ACC_D) if primary else (ACC_L, '#CDEBDD')
        b = tk.Label(parent, text=text, bg=bgc, fg='white' if primary else ACC,
                     font=(FONT, size, 'bold'), padx=14, pady=7, cursor='hand2')
        b.bind('<Enter>', lambda e: b.configure(bg=hov))
        b.bind('<Leave>', lambda e: b.configure(bg=bgc))
        b.bind('<Button-1>', lambda e: cmd())
        return b

    fc = card(body, '檔案（壓縮檔 .zip，可一次多個；也可拖整個資料夾）')
    zone = tk.Canvas(fc, height=100, bg=ACC_L, highlightthickness=0, cursor='hand2')
    zone.pack(fill='x')

    def draw(_e=None):
        zone.delete('all')
        w, h = zone.winfo_width(), zone.winfo_height()
        zone.create_rectangle(6, 6, w - 6, h - 6, outline=ACC, dash=(6, 4), width=2)
        zone.create_text(w // 2, h // 2 - 12, text='把壓縮檔拖進這裡' if dnd else '點這裡選擇壓縮檔',
                         fill=ACC, font=(FONT, 14, 'bold'))
        zone.create_text(w // 2, h // 2 + 16, text='或點一下選擇檔案', fill=SUB, font=(FONT, 10))
    zone.bind('<Configure>', draw)
    lf = tk.Frame(fc, bg=CARD)
    lf.pack(fill='both', expand=True, pady=(10, 0))
    lb = tk.Listbox(lf, height=4, bd=0, highlightthickness=1, highlightbackground=LINE, font=(FONT, 10),
                    activestyle='none', selectmode='extended', selectbackground=ACC_L, selectforeground=TXT)
    lb.pack(fill='both', expand=True)

    def add_paths(paths):
        for p in paths:
            p = os.path.normpath(p)
            if (p.lower().endswith('.zip') or os.path.isdir(p)) and p not in items:
                items.append(p)
                lb.insert('end', p)

    def pick(_e=None):
        add_paths(filedialog.askopenfilenames(title='選擇壓縮檔', filetypes=[('壓縮檔', '*.zip')]))

    def remove_sel():
        for i in reversed(lb.curselection()):
            lb.delete(i)
            del items[i]

    zone.bind('<Button-1>', pick)
    lb.bind('<Delete>', lambda e: remove_sel())
    br = tk.Frame(fc, bg=CARD)
    br.pack(fill='x', pady=(8, 0))
    button(br, '移除選取', remove_sel).pack(side='left')
    button(br, '清空', lambda: (items.clear(), lb.delete(0, 'end'))).pack(side='left', padx=8)
    if dnd:
        def on_drop(e):
            add_paths(root.tk.splitlist(e.data))
        for w in (zone, lb):
            w.drop_target_register(DND_FILES)
            w.dnd_bind('<<Drop>>', on_drop)

    oc = card(body, '選項')
    r1 = tk.Frame(oc, bg=CARD)
    r1.pack(anchor='w')
    ttk.Label(r1, text='只保留最新照片張數', style='Card.TLabel').pack(side='left')
    v_keep = tk.IntVar(value=4)
    ttk.Spinbox(r1, from_=1, to=20, width=4, textvariable=v_keep, font=(FONT, 10)).pack(side='left', padx=8)
    ttk.Label(r1, text='（依「拍照日期」，最新的優先）', style='Card.TLabel').pack(side='left')
    ttk.Label(oc, text='照片會自動下載並嵌入 Word（需連網）', style='Card.TLabel').pack(anchor='w', pady=(6, 0))
    v_where = tk.StringVar(value='same')
    v_dir = tk.StringVar(value='')
    ttk.Radiobutton(oc, text='存在壓縮檔旁邊', variable=v_where, value='same', style='Card.TRadiobutton').pack(anchor='w', pady=(6, 0))
    r2 = tk.Frame(oc, bg=CARD)
    r2.pack(anchor='w', fill='x')
    ttk.Radiobutton(r2, text='存到指定資料夾', variable=v_where, value='dir', style='Card.TRadiobutton').pack(side='left')
    tk.Entry(r2, textvariable=v_dir, font=(FONT, 9), relief='solid', bd=1).pack(side='left', fill='x', expand=True, padx=8)

    def choose():
        d = filedialog.askdirectory(title='選擇輸出資料夾')
        if d:
            v_dir.set(d)
            v_where.set('dir')
    button(r2, '選擇…', choose).pack(side='left')

    lc = card(body, '執行紀錄', expand=True)
    prog = ttk.Progressbar(lc, style='Acc.Horizontal.TProgressbar', mode='determinate', maximum=100)
    prog.pack(fill='x', pady=(0, 8))
    tf = tk.Frame(lc, bg=CARD)
    tf.pack(fill='both', expand=True)
    out = tk.Text(tf, height=8, bd=0, highlightthickness=1, highlightbackground=LINE, font=(FONT, 9),
                  bg='#FAFCFB', fg=TXT, state='disabled', wrap='word')
    osb = ttk.Scrollbar(tf, orient='vertical', command=out.yview)
    out.configure(yscrollcommand=osb.set)
    out.pack(side='left', fill='both', expand=True)
    osb.pack(side='right', fill='y')

    def log(s):
        def w():
            out.configure(state='normal')
            out.insert('end', s + '\n')
            out.see('end')
            out.configure(state='disabled')
        root.after(0, w)

    row = tk.Frame(body, bg=BG)
    row.pack(fill='x')
    start = button(row, '開始整理', lambda: go(), primary=True, size=13)
    start.pack(side='left', fill='x', expand=True, ipady=3)
    openb = button(row, '開啟輸出資料夾', lambda: open_out())

    def open_out():
        try:
            os.startfile(last['dir'])
        except Exception:
            pass

    def go():
        if busy['v']:
            return
        if not items:
            messagebox.showinfo('提示', '請先把壓縮檔拖進來')
            return
        outdir = v_dir.get().strip() if v_where.get() == 'dir' else None
        if v_where.get() == 'dir' and not outdir:
            messagebox.showinfo('提示', '請選擇輸出資料夾')
            return
        try:
            keep = max(1, int(v_keep.get()))
        except Exception:
            keep = 4
        paths = list(items)
        busy['v'] = True
        start.configure(text='整理中…')
        openb.pack_forget()
        prog.configure(mode='indeterminate')
        prog.start(12)

        def work():
            t0 = time.time()
            try:
                res = []
                for p in paths:
                    log('######## ' + os.path.basename(p))
                    res += run_paths([p], outdir, keep, True, log)
                    last['dir'] = outdir or os.path.dirname(os.path.abspath(p))
                log('全部結束，共 %d 個 Word，%.1f 秒。請用 Word 開啟檢查。' % (len(res), time.time() - t0))
            except Exception as e:  # noqa
                log('錯誤：%s' % e)

            def fin():
                prog.stop()
                prog.configure(mode='determinate', value=100)
                busy['v'] = False
                start.configure(text='開始整理')
                if last['dir']:
                    openb.pack(side='left', padx=(8, 0), ipady=3)
            root.after(0, fin)
        threading.Thread(target=work, daemon=True).start()

    eng = pick_engine()
    log(('轉換引擎：' + eng.name) if eng else '⚠ 找不到 Microsoft Word 或 LibreOffice，無法轉成 Word')
    if not dnd:
        log('提示：未安裝 tkinterdnd2，不能拖曳，請點選區塊加入檔案。')
    root.mainloop()


def main():
    ap = argparse.ArgumentParser(description='橋梁基本資料整理')
    ap.add_argument('files', nargs='*', help='壓縮檔(.zip) 或資料夾；不給則開視窗')
    ap.add_argument('--keep', type=int, default=4, help='只保留最新幾張照片（預設 4）')
    ap.add_argument('--out', help='輸出資料夾（預設在壓縮檔旁）')
    a = ap.parse_args()
    if not a.files:
        run_gui()
        return
    run_paths(a.files, a.out, a.keep, True)


if __name__ == '__main__':
    main()
