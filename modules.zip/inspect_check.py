# -*- coding: utf-8 -*-
"""檢查檢測紀錄：讀「橋梁 DERU 目視檢測評估表」PDF（可多座橋合訂），檢查資料有沒有錯、
依資料產生檢測員意見草稿，並和表上已寫的意見比對。與視窗無關，方便測試。
流程：extract_pages（pdfplumber 取表格，可多程序）→ build_bridges（整理成各橋資料）
      → check_bridge（規則檢查）→ draft_opinion（意見草稿）→ write_report（Word／文字報告）"""
import collections
import os
import re

ITEMS_ALL = ['河道', '橋台基礎', '橋台', '翼牆／擋土牆', '伸縮縫', '橋梁排水設施', '橋護欄', '引道路堤', '引道路堤護欄',
             '橋面板', '主梁', '橫隔梁', '斜撐', '支承／支承墊／阻尼裝置', '防落設施', '橋墩基礎', '橋墩墩體/帽梁',
             '橋墩／橋基保護設施', '橋台／橋基保護設施', '護床工']
# 汛期後只檢測：橋台、橋墩（含基礎、帽梁）、保護設施、河道
POST_FLOOD_ITEMS = ('河道', '橋台基礎', '橋台', '橋墩基礎', '橋墩墩體/帽梁', '橋墩／橋基保護設施', '橋台／橋基保護設施', '護床工')
COLS = ['D', 'E', 'R', 'U', '劣化類型', '維修工法', '數量', '單位', '備註']


def _c(x):
    return (x or '').replace('\n', '').strip()


# ----------------------------------------------------------------------
# 1. 取表格
# ----------------------------------------------------------------------
def page_count(path):
    import pdfplumber
    with pdfplumber.open(path) as pdf:
        return len(pdf.pages)


def extract_pages(path, start, end):
    """（可在子程序執行）回傳 [(頁碼, [表格, ...]), ...]；表格＝二維字串陣列，頁碼從 1 起算"""
    import pdfplumber
    out = []
    with pdfplumber.open(path) as pdf:
        for i in range(start, min(end, len(pdf.pages))):
            page = pdf.pages[i]
            tabs = [[[_c(x) for x in r] for r in tb] for tb in page.extract_tables()]
            out.append((i + 1, tabs, len(page.images)))
    return out


# ----------------------------------------------------------------------
# 2. 整理成各橋資料
# ----------------------------------------------------------------------
def _cover(tb):
    flat = [[_c(x) for x in r] for r in tb]

    def right(label):
        for r in flat:
            for k, x in enumerate(r):
                if x == label or (x and label.startswith(x) and len(x) >= 3 and x == label[:len(x)] and x != ''):
                    for y in r[k + 1:]:
                        if y:
                            return y
        return ''

    def above(label):
        for i, r in enumerate(flat):
            for k, x in enumerate(r):
                if x == label and i > 0:
                    v = flat[i - 1][k]
                    if v:
                        return v
                    # 合併儲存格：往右找同一列第一個有字的
                    for y in flat[i - 1][k:]:
                        if y:
                            return y
        return ''
    d = dict(name=right('橋梁名稱'), no=right('橋梁編號'), date=above('檢測日期'), unit=above('檢測單位'),
             chief=above('單位主管'), inspectors=right('檢測員'), opinion='', salt='', scour='', scour_pos='',
             debris='', notified='', length=right('橋梁總長'), spans=''.join(c for r in flat for c in r[:0]))
    for i, r in enumerate(flat):
        if r and r[0].startswith('檢測員意') and i > 0:
            d['opinion'] = flat[i - 1][1] if len(flat[i - 1]) > 1 else ''
    def nxt(r, k):
        for y in r[k + 1:]:
            if y:
                return y
        return ''
    for r in flat:
        for k, x in enumerate(r):
            if x.startswith('是否疑似'):
                d['salt'] = nxt(r, k)
            elif x.startswith('有無沖刷'):
                d['scour'] = nxt(r, k)
            elif x.startswith('沖刷位置'):
                d['scour_pos'] = nxt(r, k)
            elif x.startswith('橋下有無'):
                d['debris'] = nxt(r, k)
            elif x.startswith('已通知段長'):
                d['notified'] = nxt(r, k)
    return d


def _item_name(tb):
    for x in tb[0][1:]:
        if x:
            return x
    return ''


def _parse_header(hdr):
    """標題列 → 欄位位置：回傳 (ids 欄位索引, {'D':idx,...})"""
    pos = {}
    for k, x in enumerate(hdr):
        if x in COLS and x not in pos:
            pos[x] = k
    first = min(pos.values()) if pos else len(hdr)
    ids = [k for k in range(first) if hdr[k]]
    return ids, pos


def _row(r, ids, pos, page):
    g = lambda n: r[pos[n]] if n in pos and pos[n] < len(r) else ''
    idv = [r[k] for k in ids if k < len(r)]
    return dict(ids=idv, D=g('D'), E=g('E'), R=g('R'), U=g('U'), typ=g('劣化類型'), method=g('維修工法'),
                qty=g('數量'), unit=g('單位'), remark=g('備註'), page=page)


def _card(tb, page):
    """損傷明細卡（D≥3 的才有）：標題列 + 資料列 + 建議維修工法列"""
    c = dict(page=page, item='', pos='', no='', D='', E='', R='', U='', loc='', typ='', cause='',
             method='', qty='', unit='', cost='', remark='', date='', photos=0)
    for i, r in enumerate(tb):
        if i == 1 and len(r) >= 11:
            c.update(item=r[0], pos=r[1], no=r[2], D=r[3], E=r[4], R=r[5], U=r[6], loc=r[7],
                     typ=r[9], cause=r[10])
        if r and r[0] == '建議維修工法' and i + 1 < len(tb):
            m = tb[i + 1] + [''] * 11
            c.update(method=m[0], qty=m[7], unit=m[8], cost=m[9], remark=m[10])
        if r and r[0] == '拍攝日期':
            for rr in tb[i + 1:i + 3]:
                for x in rr:
                    if re.fullmatch(r'\d{4}[/-]\d\d[/-]\d\d', x or ''):
                        c['date'] = x
                        break
    return c


def build_bridges(page_tables):
    """page_tables：[(頁碼, 表格們, 圖片數)] → 各橋 dict 的 list"""
    bridges = []
    cur = None
    last = None            # 最近一個彙總表的 (item, ids, pos)
    mode = 'summary'
    for pg, tabs, nimg in sorted(page_tables, key=lambda x: x[0]):
        for tb in tabs:
            if not tb or not tb[0]:
                continue
            h = tb[0][0]
            if h == '橋梁名稱':
                cv = _cover(tb)
                if cur is not None and cv['name'] == cur['name'] and pg - cur['page'] <= 3:
                    for k, v in cv.items():            # 封面被換頁切成兩段：補上空白欄位
                        if v and not cur.get(k):
                            cur[k] = v
                    continue
                cur = dict(cv, page=pg, items=collections.OrderedDict(), cards=[], npages=0, images=0)
                bridges.append(cur)
                last, mode = None, 'summary'
                continue
            if cur is None:
                continue
            cur['npages'] = pg - cur['page'] + 1
            if h == '檢測項目' and len(tb) > 1 and len(tb[0]) >= 11 and tb[0][1] == '位置' and tb[0][2] == '編號' and tb[0][3] == 'D' \
                    and tb[0][7] == '損壞位置':
                mode = 'cards'
                cur['cards'].append(_card(tb, pg))
                continue
            if h == '檢測項目':
                name = _item_name(tb)
                if len(tb) < 2:
                    continue
                ids, pos = _parse_header(tb[1])
                if not pos:
                    continue
                mode = 'summary'
                last = (name, ids, pos)
                lst = cur['items'].setdefault(name, [])
                for r in tb[2:]:
                    if any(r) and re.fullmatch(r'\d*', (r[pos['D']] if pos.get('D', 99) < len(r) else '') or ''):
                        lst.append(_row(r, ids, pos, pg))
                continue
            if h.startswith('N/A'):
                continue
            flat_txt = ''.join(''.join(r) for r in tb[:4])
            if '結束照片' in flat_txt or '開始照片' in flat_txt or ('橋梁編' in flat_txt and '檢測' in flat_txt) or '檢測結' in flat_txt:
                mode, last = 'end', None          # 每座橋最後的「檢測開始／結束照片」頁，不是損傷資料
                continue
            if mode == 'end':
                continue
            # 沒有標題的延續表格
            if mode == 'cards' and h in ('建議維修工法', '拍攝日期', '檢測照片') or (mode == 'cards' and cur['cards'] and h == ''):
                if cur['cards']:
                    c2 = _card([['', ''], ['', '', '', '', '', '', '', '', '', '', '']] + tb, pg)
                    for k in ('method', 'qty', 'unit', 'cost', 'remark', 'date'):
                        if c2.get(k) and not cur['cards'][-1].get(k):
                            cur['cards'][-1][k] = c2[k]
                continue
            if mode == 'summary' and last is not None:
                name, ids, pos = last
                lst = cur['items'].setdefault(name, [])
                need = max(pos.values()) + 1
                for r in tb:
                    if any(r) and len(r) >= need and (r[pos['D']] or '') in ('0', '1', '2', '3', '4') and (r[pos['U']] or '') in ('', '1', '2', '3', '4'):
                        lst.append(_row(r, ids, pos, pg))
    # 圖片張數（卡片頁）
    byp = {pg: n for pg, _t, n in page_tables}
    for b in bridges:
        b['images'] = sum(byp.get(p, 0) for p in range(b['page'], b['page'] + b['npages']))
    return bridges


# ----------------------------------------------------------------------
# 3. 規則（可以用 %LOCALAPPDATA%\橋梁檢測工具箱\檢查規則.json 覆蓋）
# ----------------------------------------------------------------------
DEFAULT_RULES = {
    # 維修工法 → 允許的單位
    'units': {
        '水刀鑿除，鋼筋除銹，環氧樹脂砂漿修補': ['平方公尺'],
        '水刀鑿除，鋼筋銹蝕，環氧樹脂砂漿修補': ['平方公尺'],
        '水刀鑿除，環氧樹脂砂漿修補': ['平方公尺'],
        '表面裂縫修補': ['公尺'],
        '裂縫灌注': ['公尺'],
        '持續觀測': ['式'],
        '橋墩基礎持續觀測': ['式'],
        '基礎裸露持續觀測': ['式'],
        '裂縫觀測': ['式'],
        '導水設施修復': ['公尺'],
        '雜物清理': ['處'],
        '植物生長清理': ['處'],
        '伸縮縫清理': ['處'],
        '洩水孔清疏': ['處'],
        '防銹塗裝，手工處理+油漆塗裝': ['平方公尺', '處'],
        'AC刨除加鋪及鋸縫': ['平方公尺'],
        '無收縮混凝土修復(5000PSI)': ['平方公尺', '立方公尺'],
        '既有構造物打除': ['立方公尺'],
    },
    # 每單位單價（元），只用於有「概估維修經費」的明細卡
    'prices': {
        '水刀鑿除，鋼筋除銹，環氧樹脂砂漿修補': 4000,
        '水刀鑿除，環氧樹脂砂漿修補': 3200,
        '表面裂縫修補': 1300,
        '持續觀測': 2000,
        '橋墩基礎持續觀測': 2000,
        '裂縫灌注': 1300,
    },
    # 剝落類：有除銹 → R、U；沒除銹 → R、U
    'spall_with_derust': [2, 2],
    'spall_no_derust': [1, 1],
    'design_len_default': '',
}


def load_rules(path=None):
    import json
    rules = json.loads(json.dumps(DEFAULT_RULES, ensure_ascii=False))
    if path and os.path.exists(path):
        try:
            user = json.load(open(path, encoding='utf-8-sig'))
            for k, v in user.items():
                if isinstance(v, dict) and isinstance(rules.get(k), dict):
                    rules[k].update(v)
                else:
                    rules[k] = v
        except Exception:
            pass
    return rules


def norm_item(s):
    s = (s or '').replace(' ', '').replace('／', '/')
    return {'橋墩/帽梁': '橋墩墩體/帽梁'}.get(s, s)


def norm_pos(s):
    """P017→P17、a001→A1、S018→S18；其他維持原樣"""
    m = re.fullmatch(r'([A-Za-z])0*(\d+)(-\d+)?', (s or '').strip())
    if m:
        return m.group(1).upper() + m.group(2) + (m.group(3) or '')
    return (s or '').strip()


def _num(x):
    try:
        return float(x)
    except Exception:
        return None


def pos_of(item, row):
    ids = [x for x in row['ids'] if x]
    return norm_pos(ids[-1] if ids else '') if item in ('橋墩基礎', '橋墩墩體/帽梁') and len(ids) > 1 else \
        (norm_pos(ids[0]) if ids else '')


def fmt_range(nums, prefix):
    """[1,2,3,5] → 'P1~P3、P5'"""
    nums = sorted(set(nums))
    out, i = [], 0
    while i < len(nums):
        j = i
        while j + 1 < len(nums) and nums[j + 1] == nums[j] + 1:
            j += 1
        if j - i >= 2:
            out.append('%s%d~%s%d' % (prefix, nums[i], prefix, nums[j]))
        else:
            out += ['%s%d' % (prefix, n) for n in nums[i:j + 1]]
        i = j + 1
    return '、'.join(out)


def pier_numbers(rows_pos):
    nums = []
    for p in rows_pos:
        m = re.match(r'P(\d+)', p)
        if m:
            nums.append(int(m.group(1)))
    return sorted(set(nums))


# ----------------------------------------------------------------------
# 4. 檢查
# ----------------------------------------------------------------------
JUNK = re.compile(r'[Xx]{2,}\s*m?|本來|待補|TBD|＊＊|\?\?|？？')
SPALL_WORDS = ('剝落', '破碎')


def _issue(level, where, text, page=None):
    return dict(level=level, where=where, text=text, page=page)


def _rows(b, mode):
    for it, lst in b['items'].items():
        if mode == 'post' and it not in POST_FLOOD_ITEMS:
            continue
        for r in lst:
            yield it, r


def check_bridge(b, mode='pre', rules=None):
    """回傳 issues（level：錯誤／疑似）。mode：'pre' 汛期前（全部項目）／'post' 汛期後（只看橋台、橋墩、保護設施、河道）"""
    rules = rules or DEFAULT_RULES
    iss = []
    A = iss.append
    # ---- 封面
    if not b['date']:
        A(_issue('錯誤', '封面', '檢測日期空白', b['page']))
    elif not re.fullmatch(r'\d{4}-\d\d-\d\d', b['date']):
        A(_issue('疑似', '封面', '檢測日期格式怪怪的：%s' % b['date'], b['page']))
    if not b['inspectors']:
        A(_issue('錯誤', '封面', '檢測員空白', b['page']))
    if not b['opinion']:
        A(_issue('錯誤', '封面', '檢測員意見空白', b['page']))
    elif re.search(r'狀況良好|無異常', b['opinion']) and any(
            _num(r['D']) and _num(r['D']) >= 3 for _i, r in _rows(b, mode)):
        A(_issue('疑似', '封面', '檢測員意見寫「狀況良好」，但資料裡有 D≥3 的項目', b['page']))
    for m in JUNK.finditer(b['opinion']):
        A(_issue('錯誤', '封面／檢測員意見', '意見裡還有未填的範本字或可疑字：「%s」' % m.group(0).strip(), b['page']))
    # ---- 逐列
    seen_unit = set()
    for it, r in _rows(b, mode):
        where = '%s %s' % (it, '/'.join(x for x in r['ids'] if x)) if r['ids'] else it
        pg = r['page']
        D, E, R, U = (_num(r[k]) for k in 'DERU')
        for k in 'DER':
            v = _num(r[k])
            if r[k] != '' and (v is None or v < 0 or v > 4):
                A(_issue('錯誤', where, '%s 值「%s」不在 0～4' % (k, r[k]), pg))
        if r['U'] != '' and (U is None or U < 1 or U > 4):
            A(_issue('錯誤', where, 'U 值「%s」不在 1～4' % r['U'], pg))
        has_damage = D is not None and D >= 2
        if has_damage:
            if not r['method'] and it not in ('河道',):
                A(_issue('錯誤', where, 'D=%d 但沒有維修工法' % D, pg))
            if r['method'] and (not r['qty'] or _num(r['qty']) is None or _num(r['qty']) <= 0):
                A(_issue('錯誤', where, '有維修工法「%s」但數量空白或不是正數（%s）' % (r['method'], r['qty']), pg))
            if r['method'] and not r['unit']:
                A(_issue('錯誤', where, '有維修工法「%s」但單位空白' % r['method'], pg))
            if None in (E, R, U) or '' in (r['E'], r['R'], r['U']):
                A(_issue('疑似', where, 'D=%d 但 E／R／U 有空白' % D, pg))
            if r['typ'] == '其他損傷' and not r['remark']:
                A(_issue('疑似', where, '劣化類型是「其他損傷」但備註空白', pg))
        for fld, txt in (('備註', r['remark']), ('劣化類型', r['typ']), ('維修工法', r['method'])):
            for m in JUNK.finditer(txt or ''):
                A(_issue('錯誤', where, '%s裡有未填的範本字或可疑字：「%s」（%s）' % (fld, m.group(0).strip(), txt[:30]), pg))
        # 單位 vs 工法
        if r['method'] and r['unit'] and r['method'] in rules['units'] and r['unit'] not in rules['units'][r['method']]:
            A(_issue('疑似', where, '維修工法「%s」的單位通常是「%s」，這筆寫「%s」' % (
                r['method'], '／'.join(rules['units'][r['method']]), r['unit']), pg))
        # 剝落類 R/U vs 除銹
        if any(w in r['typ'] for w in SPALL_WORDS) and r['method'].startswith('水刀鑿除') and R is not None and U is not None:
            derust = '鋼筋除銹' in r['method'] or '鋼筋銹蝕' in r['method']
            want = rules['spall_with_derust'] if derust else rules['spall_no_derust']
            if [int(R), int(U)] != want:
                A(_issue('疑似', where, '%s，但 R=%d、U=%d（同類通常是 R=%d、U=%d）' % (
                    '有除銹工法' if derust else '沒有除銹工法', R, U, want[0], want[1]), pg))
        # 裂縫類型 vs 備註
        if r['typ'] == '其他損傷' and re.search(r'(?<!非)結構裂縫', r['remark'] or ''):
            A(_issue('疑似', where, '備註是結構裂縫，但劣化類型填「其他損傷」', pg))
        if r['typ'] == '其他損傷' and any(w in (r['remark'] or '') for w in SPALL_WORDS):
            A(_issue('疑似', where, '備註提到剝落／破碎，但劣化類型填「其他損傷」', pg))
    # ---- 彙總表 vs 明細卡
    sm = collections.Counter()
    for it, r in _rows(b, mode):
        D = _num(r['D'])
        if D is not None and D >= 3:
            sm[(norm_item(it), '', r['D'], r['E'], r['R'], r['U'])] += 1
    cm = collections.Counter()
    for c in b['cards']:
        it = norm_item(c['item'])
        if mode == 'post' and it not in POST_FLOOD_ITEMS:
            continue
        pos = norm_pos(c['no'] or c['pos']) if it in ('橋墩基礎', '橋墩墩體/帽梁') and c['no'] else norm_pos(c['pos'] or c['no'])
        cm[(it, '', c['D'], c['E'], c['R'], c['U'])] += 1
    for k in sorted(set(sm) | set(cm), key=str):
        if sm[k] != cm[k]:
            A(_issue('疑似', k[0], '彙總表 D=%s E=%s R=%s U=%s：彙總表有 %d 筆，明細卡有 %d 筆' % (
                k[2], k[3], k[4], k[5], sm[k], cm[k]), b['page']))
    # ---- 明細卡本身
    for c in b['cards']:
        it = norm_item(c['item'])
        if mode == 'post' and it not in POST_FLOOD_ITEMS:
            continue
        where = '明細卡 %s %s' % (it, c['no'] or c['pos'])
        for fld, txt in (('損壞原因', c['cause']), ('備註', c['remark']), ('維修工法', c['method'])):
            for m in JUNK.finditer(txt or ''):
                A(_issue('錯誤', where, '%s裡有未填的範本字或可疑字：「%s」' % (fld, m.group(0).strip()), c['page']))
        q, cost = _num(c['qty']), _num(c['cost'])
        if q and cost is not None and c['method'] in rules['prices']:
            want = rules['prices'][c['method']]
            if abs(cost / q - want) > 0.5:
                A(_issue('疑似', where, '「%s」單價應為 %s 元，這張算出 %s 元（數量 %s、經費 %s）' % (
                    c['method'], want, round(cost / q, 1), c['qty'], c['cost']), c['page']))
        if c['method'] and c['unit'] and c['method'] in rules['units'] and c['unit'] not in rules['units'][c['method']]:
            A(_issue('疑似', where, '維修工法「%s」的單位通常是「%s」，這張寫「%s」' % (
                c['method'], '／'.join(rules['units'][c['method']]), c['unit']), c['page']))
    # ---- 沖刷、雜物 與封面對照
    scour_cards = [c for c in b['cards'] if '沖刷' in c['typ']]
    scour_rows = [(it, r) for it, r in _rows(b, mode) if '沖刷' in r['typ'] and _num(r['D']) and _num(r['D']) >= 2]
    if (scour_cards or scour_rows) and b['scour'] not in ('有',):
        A(_issue('疑似', '封面', '資料裡有基礎沖刷，但封面「有無沖刷現象」是「%s」' % (b['scour'] or '空白'), b['page']))
    if b['scour'] == '有':
        if not (scour_cards or scour_rows):
            A(_issue('疑似', '封面', '封面「有無沖刷現象」是「有」，但資料裡找不到沖刷項目', b['page']))
        if not b['scour_pos']:
            A(_issue('錯誤', '封面', '有沖刷現象，但「沖刷位置／備註」空白', b['page']))
        if b['notified'] not in ('是',):
            A(_issue('疑似', '封面', '有沖刷現象，但「已通知段長或副段長」是「%s」' % (b['notified'] or '空白'), b['page']))
    # ---- 檢測員意見與資料
    iss += compare_opinion(b, mode)
    return iss


# ----------------------------------------------------------------------
# 5. 檢測員意見草稿
# ----------------------------------------------------------------------
LABEL = {'橋台': '橋台', '橋台基礎': '橋台基礎', '翼牆/擋土牆': '翼牆', '橋護欄': '橋護欄', '引道路堤': '引道路堤',
         '引道路堤護欄': '引道路堤護欄', '橋面板': '橋面板', '主梁': '主梁', '橫隔梁': '橫隔梁', '斜撐': '斜撐',
         '支承/支承墊/阻尼裝置': '支承', '防落設施': '防落設施', '橋墩基礎': '橋墩基礎', '橋墩墩體/帽梁': '橋墩帽梁',
         '橋墩/橋基保護設施': '橋基保護設施', '橋台/橋基保護設施': '橋台保護設施', '護床工': '護床工', '伸縮縫': '伸縮縫',
         '橋梁排水設施': '排水設施', '河道': '河道'}
CAT_KEYS = {'spall': ('剝落', '破碎', '蜂窩'), 'crack_struct': ('結構裂縫',), 'crack_non': ('非結構裂縫', '乾縮裂縫'),
            'scour': ('沖刷',), 'protect': ('保護設施',), 'plate': ('防撞鋼板',), 'seep': ('滲水', '白華'),
            'plant': ('植物',), 'debris': ('雜物', '掛淤', '堆積', '土石'), 'river': ('河道',), 'rust': ('生銹', '銹蝕', '塗裝', '鏽'),
            'joint': ('伸縮縫',), 'leak': ('漏水',)}
CAT_NAME = {'spall': '混凝土剝落／破碎', 'crack_struct': '混凝土結構裂縫', 'crack_non': '非結構裂縫', 'scour': '基礎沖刷',
            'protect': '保護設施損壞', 'plate': '防撞鋼板損傷', 'seep': '滲水白華', 'plant': '植物生長', 'debris': '雜物堆積',
            'river': '河道沖淤', 'rust': '生銹／塗裝劣化', 'joint': '伸縮縫', 'leak': '漏水', 'drain': '排水設施',
            'other': '其他損傷'}
ORDER = ['spall', 'crack_struct', 'crack_non', 'leak', 'joint', 'rust', 'drain', 'protect', 'scour', 'plate', 'seep',
         'river', 'plant', 'debris', 'other']


def classify(it, typ, remark, method):
    typ, rem, method = typ or '', remark or '', method or ''
    allt = typ + rem + method
    if '沖刷' in typ:
        return 'scour'
    if it in ('橋墩/橋基保護設施', '橋台/橋基保護設施', '護床工'):
        return 'protect'
    if '防撞鋼板' in typ:
        return 'plate'
    if '滲水' in typ or '白華' in typ:
        return 'seep'
    if '裂縫' in typ or '裂縫' in rem:
        return 'crack_non' if ('非結構' in rem or '乾縮' in rem or '非結構' in typ) else 'crack_struct'
    if any(w in typ for w in SPALL_WORDS) or any(w in rem for w in ('蜂窩', '破碎', '剝落')):
        return 'spall'
    if '植物' in allt:
        return 'plant'
    if '雜物' in allt or '堆積' in allt or '掛淤' in allt:
        return 'debris'
    if it == '河道':
        return 'river'
    if '生銹' in typ or '腐蝕' in typ or '塗裝' in typ or '防銹' in method:
        return 'rust'
    if '漏水' in typ:
        return 'leak'
    if it == '伸縮縫':
        return 'joint'
    if '排水' in typ or it == '橋梁排水設施':
        return 'drain'
    return 'other'


def _scour_values(texts):
    vals = []
    for t in texts:
        t2 = re.sub(r'原設計長度\s*[（(][^)）]*[)）]', '', t or '')
        for m in re.finditer(r'(\d+(?:\.\d+)?)\s*m', t2):
            vals.append(float(m.group(1)))
    return vals


def _pos_text(item_pos):
    """item_pos：{label: [pos,...]} → 'A1、A2橋台及P1~P5橋墩帽梁'；位置太多就寫「多處」"""
    parts = []
    many = sum(len(set(v)) for v in item_pos.values()) > 8
    labels = []
    for label, ps in item_pos.items():
        ps = sorted(set(p for p in ps if p))
        piers = pier_numbers(ps)
        decks = sorted(set(int(m.group(1)) for p in ps for m in [re.fullmatch(r'S(\d+)', p)] if m))
        if many:
            labels.append(label)
            continue
        if piers and len(piers) == len([p for p in ps if p.startswith('P')]) and all(p.startswith('P') for p in ps if p):
            parts.append(fmt_range(piers, 'P') + label)
        elif decks and len(decks) == len(ps):
            parts.append(fmt_range(decks, 'S') + label)
        else:
            nm = [p for p in ps if re.fullmatch(r'[A-Z]\d+', p)]
            parts.append('、'.join(nm if nm else ps) + label if (nm or ps) else label)
    if many:
        return '多處' + '、'.join(labels)
    return '及'.join(parts) if parts else '、'.join(item_pos)


def analyze(b, mode='pre'):
    """把資料依類別整理：回傳 {cat: dict(rows=[...], U=最大U, labels={label:[pos]})}"""
    cats = collections.OrderedDict()
    rows = []
    for it, r in _rows(b, mode):
        D = _num(r['D'])
        if D is None or D < 2:
            continue
        rows.append((norm_item(it), r['typ'], r['remark'], r['method'], pos_of(it, r), _num(r['U']) or 0, r))
    for c in b['cards']:
        it = norm_item(c['item'])
        if mode == 'post' and it not in POST_FLOOD_ITEMS:
            continue
        # 明細卡的資料已含在彙總表；只補充沖刷數字用
    for it, typ, rem, method, pos, U, r in rows:
        cat = classify(it, typ, rem, method)
        g = cats.setdefault(cat, dict(rows=[], U=0, labels=collections.OrderedDict(), methods=set(), texts=[]))
        g['rows'].append(r)
        g['U'] = max(g['U'], int(U))
        g['labels'].setdefault(LABEL.get(it, it), []).append(pos)
        g['methods'].add(method)
        g['texts'].append(' '.join([typ, rem, method]))
    return cats


def _urgency(U, monitor):
    if monitor:
        return '建議持續觀測'
    return {1: '建議於例行養護時維護', 2: '建議3年內維護', 3: '建議於1年內維護', 4: '建議緊急維修'}.get(U, '建議3年內維護')


def draft_opinion(b, mode='pre'):
    """回傳 (意見句子 list, 備註 list)。備註＝需要人工補的地方"""
    cats = analyze(b, mode)
    out, notes = [], []
    routine = False
    for cat in ORDER:
        g = cats.get(cat)
        if not g or cat in ('plant', 'debris', 'other', 'drain', 'rust', 'joint', 'leak') or (g['U'] < 2 and cat != 'scour'):
            continue
        loc = _pos_text(g['labels'])
        monitor = all(('觀測' in m) for m in g['methods'] if m) and bool(g['methods'])
        U = g['U']
        txts = ' '.join(g['texts'])
        if cat == 'spall':
            det = [w for w in ('保護層不足', '蜂窩') if w in txts]
            s = '%s混凝土剝落%s或破碎，鋼筋%s外露、銹蝕' % (loc, '(' + '及'.join(det) + ')' if det else '',
                                                  '輕微' if U <= 2 else '明顯')
        elif cat == 'crack_struct':
            variants = collections.Counter(m.group(1) for t in g['texts'] for m in [re.search(r'結構裂縫[（(]([^)）]*)[)）]', t)] if m)
            s = '%s混凝土結構裂縫%s' % (loc, '(' + variants.most_common(1)[0][0] + ')' if variants else '')
        elif cat == 'crack_non':
            s = '%s混凝土非結構裂縫%s' % (loc, '(鋼筋生銹膨脹造成)' if '銹' in txts else '')
        elif cat == 'scour':
            s, extra = _scour_sentence(b, g, mode)
            notes += extra
            monitor = True
        elif cat == 'protect':
            s = '%s局部遭洪水掏空與沖失' % loc if ('沖失' in txts or '掏空' in txts) else '%s保護設施損壞' % loc
            monitor = monitor or U <= 2
        elif cat == 'plate':
            s = '%s防撞鋼板輕微損傷(生銹)，不影響其保護功能' % loc
            monitor = True
        elif cat == 'seep':
            s = '%s滲水、白華' % loc
            monitor = True
        elif cat == 'river':
            s = '河道局部沖淤或輕微變遷，不影響河流及洪水通行'
            monitor = True
        elif cat == 'plant':
            s = '%s植物生長' % loc
            if U <= 1:
                routine = True
        elif cat == 'debris':
            s = '%s有雜物堆積' % loc
        elif cat == 'rust':
            s = '%s塗裝劣化、生銹' % loc
        elif cat == 'joint':
            s = '%s伸縮縫異常' % loc
        elif cat == 'leak':
            s = '%s漏水' % loc
        elif cat == 'drain':
            s = '%s排水設施損傷或阻塞' % loc
        else:
            s = '%s其他損傷' % loc
        if cat == 'plant' or cat == 'debris':
            tail = '建議派工清除'
        elif cat == 'scour':
            tail = ''
        else:
            tail = _urgency(U, monitor)
        if U <= 1 and cat not in ('scour', 'river', 'plate', 'seep', 'plant', 'debris'):
            routine = True
            continue
        out.append(s + ('，' + tail if tail else '') + '。')
    out.append('其餘劣化構件建議於例行養護時一併維護。')
    return out, notes


def _scour_sentence(b, g, mode):
    rows = g['rows']
    texts = [r['remark'] for r in rows] + [c['cause'] + ' ' + c['remark'] for c in b['cards'] if '沖刷' in c['typ']]
    vals = _scour_values(texts)
    notes = []
    piers = pier_numbers([p for ps in g['labels'].values() for p in ps])
    kind = '基礎'
    m = re.search(r'(沉箱|基樁|場鑄樁|擴座|擴大)基礎', ' '.join(texts))
    if m:
        kind = m.group(0)
    if vals:
        rng = '%.2fm~%.2fm' % (min(vals), max(vals)) if min(vals) != max(vals) else '%.2fm' % vals[0]
    else:
        rng = 'X.XXm~X.XXm'
        notes.append('沖刷深度：資料裡找不到數值，請自行補上')
    L = ''
    exceed = []
    for c in b['cards']:
        if '沖刷' in c['typ'] and '超過原設計長度' in c['cause']:
            mm = re.search(r'原設計長度\s*[（(](\d+(?:\.\d+)?)m[)）]', c['cause'])
            if mm:
                L = mm.group(1)
            for p in pier_numbers([norm_pos(c['no'] or c['pos'])]):
                exceed.append(p)
    s = '%s%s有局部沖刷 %s 情形' % (fmt_range(piers, 'P') if piers else _pos_text(g['labels']), kind, rng)
    if exceed:
        s += '，其中 %s 露出部分超過原設計長度(%s)的 1/5，但未超過原設計長度的 1/3' % (
            fmt_range(sorted(set(exceed)), 'P'), (L + 'm') if L else 'XXm')
        if not L:
            notes.append('原設計長度：資料裡找不到，請自行補上')
    s += '，建議未改建前應持續觀測是否有下刷之情形，必要時可於颱洪期間封閉橋梁'
    return s, notes


def compare_opinion(b, mode='pre'):
    """表上已寫的檢測員意見 vs 依資料產生的草稿"""
    op = b['opinion']
    iss = []
    if not op:
        return iss
    cats = analyze(b, mode)
    for cat, g in cats.items():
        if cat not in ('spall', 'crack_struct', 'crack_non', 'scour') or g['U'] < 2:
            continue
        keys = CAT_KEYS.get(cat)
        if cat in ('crack_struct', 'crack_non'):
            keys = ('裂縫',)
        if keys and not any(k in op for k in keys):
            iss.append(_issue('疑似', '檢測員意見', '資料裡有「%s」（U 最大 %d），但意見裡沒有提到' % (CAT_NAME[cat], g['U']), b['page']))
    for cat in ('scour', 'crack_struct'):
        keys = CAT_KEYS[cat]
        if any(k in op for k in keys) and cat not in cats and not (cat == 'crack_struct' and 'crack_non' in cats):
            iss.append(_issue('疑似', '檢測員意見', '意見提到「%s」，但資料裡找不到對應的項目（D≥2）' % CAT_NAME[cat], b['page']))
    # 沖刷範圍與墩號
    g = cats.get('scour')
    if g and '沖刷' in op:
        s, _n = _scour_sentence(b, g, mode)
        mm = re.search(r'(\d+\.\d+)m(?:~(\d+\.\d+)m)?', s)
        mo = re.search(r'沖刷\s*(\d+\.\d+)\s*m\s*(?:[~～至]\s*(\d+\.\d+)\s*m)?', op)
        if mm and mo:
            a = (float(mm.group(1)), float(mm.group(2) or mm.group(1)))
            c2 = (float(mo.group(1)), float(mo.group(2) or mo.group(1)))
            if a != c2:
                iss.append(_issue('疑似', '檢測員意見', '沖刷範圍：資料算出 %.2fm~%.2fm，意見寫 %.2fm~%.2fm' % (a + c2), b['page']))
        mp = re.search(r'(P[\d~、\sP-]+?)(?:沉箱|基樁|場鑄樁|擴座|擴大|基礎)', op)
        piers = fmt_range(pier_numbers([p for ps in g['labels'].values() for p in ps]), 'P')
        if mp and piers:
            if _expand(mp.group(1)) != _expand(piers):
                iss.append(_issue('疑似', '檢測員意見', '沖刷墩號：資料是「%s」，意見寫「%s」' % (piers, mp.group(1).strip('、 ')), b['page']))
    for m in JUNK.finditer(op):
        pass
    return iss


def _expand(txt):
    """'P1~P3、P5' → {1,2,3,5}"""
    out = set()
    for m in re.finditer(r'P(\d+)\s*[~～-]\s*P?(\d+)|P(\d+)', txt):
        if m.group(1):
            out |= set(range(int(m.group(1)), int(m.group(2)) + 1))
        else:
            out.add(int(m.group(3)))
    return out


# ----------------------------------------------------------------------
# 6. 執行（讀 PDF → 檢查 → 報告）
# ----------------------------------------------------------------------
def run_file(path, mode, log, progress, cancel, rules=None, make_pool=None, workers=4):
    import time
    n = page_count(path)
    step = 12
    chunks = [(s, min(s + step, n)) for s in range(0, n, step)]
    log('共 %d 頁，分 %d 段讀取' % (n, len(chunks)))
    res = []
    pool = None
    is_proc = False
    if make_pool and n > 40:
        try:
            pool, is_proc = make_pool(workers, log)
        except Exception:
            pool = None
    done = 0
    t0 = time.time()
    if pool is not None:
        futs = [pool.submit(extract_pages, path, s, e) for s, e in chunks]
        for f in futs:
            while True:
                try:
                    res += f.result(timeout=0.3)
                    break
                except Exception as ex:
                    if ex.__class__.__name__ == 'TimeoutError':
                        if cancel.is_set():
                            for g in futs:
                                g.cancel()
                            pool.shutdown(wait=False)
                            return []
                        continue
                    raise
            done += 1
            progress(0.85 * done / len(chunks))
        pool.shutdown(wait=False)
    else:
        for s, e in chunks:
            if cancel.is_set():
                return []
            res += extract_pages(path, s, e)
            done += 1
            progress(0.85 * done / len(chunks))
    log('讀取完成（%.0f 秒）' % (time.time() - t0))
    bridges = build_bridges(res)
    out = []
    for b in bridges:
        out.append((b, check_bridge(b, mode, rules), draft_opinion(b, mode)))
    progress(0.9)
    return out


def write_report(path_base, results, mode, src_name):
    """results：[(b, issues, (draft, notes))] → 寫出報告；回傳實際檔名"""
    mode_txt = '汛期前' if mode == 'pre' else '汛期後'
    nerr = sum(1 for _b, iss, _d in results for i in iss if i['level'] == '錯誤')
    nsus = sum(1 for _b, iss, _d in results for i in iss if i['level'] == '疑似')
    try:
        import docx
        from docx.shared import Pt
        doc = docx.Document()
        st = doc.styles['Normal']
        st.font.name = '微軟正黑體'
        st.font.size = Pt(10)
        doc.add_heading('檢測紀錄檢查報告（%s）' % mode_txt, 1)
        doc.add_paragraph('檔案：%s　橋梁 %d 座　錯誤 %d 筆　疑似 %d 筆' % (src_name, len(results), nerr, nsus))
        doc.add_paragraph('「錯誤」＝幾乎一定要改；「疑似」＝請你判斷。')
        for b, iss, (draft, notes) in results:
            doc.add_heading('%s（PDF 第 %s 頁起）' % (b['name'] or '（無橋名）', b['page']), 2)
            if iss:
                t = doc.add_table(rows=1, cols=4)
                t.style = 'Table Grid'
                for c, h in zip(t.rows[0].cells, ('等級', '位置', '問題', '頁')):
                    c.text = h
                for i in sorted(iss, key=lambda x: (x['level'] != '錯誤', x['page'] or 0)):
                    r = t.add_row().cells
                    r[0].text, r[1].text, r[2].text, r[3].text = i['level'], i['where'], i['text'], str(i['page'] or '')
            else:
                doc.add_paragraph('沒有發現問題。')
            doc.add_paragraph().add_run('表上檢測員意見：').bold = True
            doc.add_paragraph(b['opinion'] or '（空白）')
            doc.add_paragraph().add_run('依資料產生的意見草稿（僅供參考）：').bold = True
            for k, s in enumerate(draft):
                doc.add_paragraph('%d.%s' % (k + 1, s))
            for n in notes:
                doc.add_paragraph('※ ' + n)
        out = path_base + '.docx'
        doc.save(out)
        return out
    except ImportError:
        pass
    L = ['檢測紀錄檢查報告（%s）' % mode_txt, '檔案：%s　橋梁 %d 座　錯誤 %d　疑似 %d' % (src_name, len(results), nerr, nsus), '']
    for b, iss, (draft, notes) in results:
        L.append('■ %s（第 %s 頁起）' % (b['name'], b['page']))
        for i in sorted(iss, key=lambda x: (x['level'] != '錯誤', x['page'] or 0)):
            L.append('  [%s] %s：%s（第%s頁）' % (i['level'], i['where'], i['text'], i['page'] or ''))
        L.append('  表上意見：' + (b['opinion'] or '（空白）'))
        L.append('  意見草稿：')
        L += ['    %d.%s' % (k + 1, s) for k, s in enumerate(draft)]
        L += ['    ※ ' + n for n in notes]
        L.append('')
    out = path_base + '.txt'
    with open(out, 'w', encoding='utf-8-sig') as f:
        f.write('\n'.join(L))
    return out
