# -*- coding: utf-8 -*-
"""照片壓縮：資料夾／圖檔／Word（docx 內嵌照片）。與視窗無關。
- 自動依 EXIF 轉正，縮小長邊、調整品質；可指定「每張不超過 N KB」。
- 壓完比原檔還大就直接沿用原檔，不會越壓越大。
- docx：只重壓 word/media 裡的 JPG／PNG，檔名與格式不變，版面不受影響。"""
import io
import os
import zipfile
from concurrent.futures import ThreadPoolExecutor

from PIL import Image, ImageOps

IMG_EXT = ('.jpg', '.jpeg', '.png', '.bmp', '.tif', '.tiff', '.webp')
DOCX_EXT = ('.docx', '.docm')
MARK = 'BridgeToolbox'        # 壓縮過的照片會被寫入這個標記（JPG：EXIF Software；PNG：Software 文字）
EXIF_SOFTWARE = 0x0131


def is_target(path):
    n = os.path.basename(path)
    if n.startswith('~$'):
        return False
    return n.lower().endswith(IMG_EXT + DOCX_EXT)


def is_marked(data):
    """這張照片是不是本程式壓縮過的"""
    try:
        im = Image.open(io.BytesIO(data))
        if (im.format or '').upper() == 'PNG':
            return str(im.info.get('Software', '')).startswith(MARK)
        return str(im.getexif().get(EXIF_SOFTWARE, '')).startswith(MARK)
    except Exception:
        return False


def low_priority():
    """把目前的執行緒降為「低於標準」優先權，讓視窗保持順暢（只在 Windows 有作用）"""
    try:
        import ctypes
        k = ctypes.windll.kernel32
        k.SetThreadPriority(k.GetCurrentThread(), -1)
    except Exception:
        pass


def _encode(im, fmt, quality, exif):
    buf = io.BytesIO()
    if fmt == 'PNG':
        from PIL import PngImagePlugin
        pi = PngImagePlugin.PngInfo()
        pi.add_text('Software', '%s-q%d' % (MARK, quality))
        im.save(buf, 'PNG', optimize=True, pnginfo=pi)
    else:
        if im.mode not in ('RGB', 'L'):
            im = im.convert('RGB')
        kw = dict(quality=quality, optimize=False, progressive=False)
        if exif:
            kw['exif'] = exif
        im.save(buf, 'JPEG', **kw)
    return buf.getvalue()


def compress_bytes(data, max_edge=0, quality=80, max_kb=0, force_jpeg=False, skip_marked=True):
    """回傳 (新的 bytes, 副檔名)。新的比較大就回傳原 bytes。"""
    if skip_marked and is_marked(data):
        return data, ''
    im = Image.open(io.BytesIO(data))
    src_fmt = (im.format or '').upper()
    if src_fmt == 'JPEG' and max_edge and max(im.size) > max_edge:     # 解碼時直接縮小，速度快數倍
        r = max_edge / float(max(im.size))
        im.draft('RGB', (int(im.width * r) + 1, int(im.height * r) + 1))
    exif = None
    try:
        ex = im.getexif()
        if ex and 0x0112 in ex:
            im = ImageOps.exif_transpose(im)
            ex = im.getexif()
            ex[0x0112] = 1
        ex[EXIF_SOFTWARE] = '%s-q%d' % (MARK, quality)
        exif = ex.tobytes()
    except Exception:
        exif = None
    has_alpha = im.mode in ('RGBA', 'LA') or (im.mode == 'P' and 'transparency' in im.info)
    fmt = 'PNG' if (src_fmt == 'PNG' and not force_jpeg) or has_alpha else 'JPEG'
    if max_edge and max(im.size) > max_edge:
        r = max_edge / float(max(im.size))
        im = im.resize((max(1, round(im.width * r)), max(1, round(im.height * r))), Image.LANCZOS)
    out = _encode(im, fmt, quality, exif)
    if max_kb and fmt == 'JPEG':
        q, tries = quality, 0
        while len(out) > max_kb * 1024 and tries < 12:
            if q > 45:
                q -= 5
            else:                       # 品質已很低 → 再縮小 10%
                im = im.resize((max(1, int(im.width * 0.9)), max(1, int(im.height * 0.9))), Image.LANCZOS)
            out = _encode(im, fmt, q, exif)
            tries += 1
    ext = '.png' if fmt == 'PNG' else '.jpg'
    same_kind = (src_fmt == 'PNG') == (fmt == 'PNG') and (src_fmt in ('JPEG', 'PNG'))
    if same_kind and len(out) >= len(data):
        return data, ext
    return out, ext


def compress_image(src, dst_dir, max_edge=0, quality=80, max_kb=0, tag='', skip_marked=True):
    """壓一張圖，存到 dst_dir，回傳 (輸出路徑, 原大小, 新大小)"""
    data = open(src, 'rb').read()
    out, ext = compress_bytes(data, max_edge, quality, max_kb, force_jpeg=src.lower().endswith(('.bmp', '.tif', '.tiff', '.webp')),
                              skip_marked=skip_marked)
    if out is data and not ext:
        return None, len(data), len(data)           # 已壓縮過，略過
    os.makedirs(dst_dir, exist_ok=True)
    stem = os.path.splitext(os.path.basename(src))[0] + tag
    low = os.path.splitext(src)[1].lower()
    if out is data:
        ext = low
    dst = _unique(os.path.join(dst_dir, stem + ext))
    with open(dst, 'wb') as f:
        f.write(out)
    return dst, len(data), len(out)


def compress_docx(src, dst_dir, max_edge=0, quality=80, max_kb=0, log=None, cancel=None, tag='', workers=4, skip_marked=True, pool=None):
    """重壓 docx 內嵌照片，回傳 (輸出路徑, 原大小, 新大小, 張數)"""
    n = 0
    with zipfile.ZipFile(src) as zi:
        infos = zi.infolist()
        datas = {}
        todo = []
        for it in infos:
            datas[it.filename] = zi.read(it.filename)
            low = it.filename.lower()
            if low.startswith('word/media/') and low.endswith(('.jpg', '.jpeg', '.png')):
                todo.append(it.filename)

    def finish(name, out):
        nonlocal n
        if out is not None and (out[1] == '.png') == name.lower().endswith('.png'):   # 格式要和副檔名一致，不改 rels
            datas[name] = out[0]
            n += 1
    if pool is not None:                       # 交給程序池（多核心、不影響視窗）
        futs = [(name, pool.submit(process_media, datas[name], max_edge, quality, max_kb, skip_marked)) for name in todo]
        for name, fu in futs:
            if cancel is not None and cancel():
                for _n, f2 in futs:
                    f2.cancel()
                raise RuntimeError('已取消')
            try:
                finish(name, fu.result())
            except Exception as e:  # noqa
                if log:
                    log('  略過無法處理的圖：%s（%s）' % (name, e))
    else:
        for name in todo:
            if cancel is not None and cancel():
                raise RuntimeError('已取消')
            try:
                finish(name, process_media(datas[name], max_edge, quality, max_kb, skip_marked))
            except Exception as e:  # noqa
                if log:
                    log('  略過無法處理的圖：%s（%s）' % (name, e))
    if n == 0:
        return None, os.path.getsize(src), os.path.getsize(src), 0
    os.makedirs(dst_dir, exist_ok=True)
    dst = _unique(os.path.join(dst_dir, os.path.splitext(os.path.basename(src))[0] + tag + os.path.splitext(src)[1]))
    with zipfile.ZipFile(dst, 'w') as zo:
        for it in infos:
            zo.writestr(it, datas[it.filename], compress_type=zipfile.ZIP_DEFLATED if it.compress_type else zipfile.ZIP_STORED)
    return dst, os.path.getsize(src), os.path.getsize(dst), n


def _unique(path):
    if not os.path.exists(path):
        return path
    stem, ext = os.path.splitext(path)
    k = 2
    while os.path.exists('%s (%d)%s' % (stem, k, ext)):
        k += 1
    return '%s (%d)%s' % (stem, k, ext)


def process_media(data, max_edge, quality, max_kb, skip_marked):
    """（在子程序執行）壓一張內嵌圖。回傳 (新 bytes, 副檔名) 或 None（不變）"""
    out, ext = compress_bytes(data, max_edge, quality, max_kb, skip_marked=skip_marked)
    return None if out is data else (out, ext)


def process_file(src, dst_dir, max_edge, quality, max_kb, skip_marked):
    """（在子程序執行）壓一個圖檔，回傳 (輸出路徑或 None, 原大小, 新大小)"""
    return compress_image(src, dst_dir, max_edge, quality, max_kb, skip_marked=skip_marked)


def _child_init(moddir=''):
    """子程序啟動：降低優先權（視窗不卡）；若主程式用的是線上更新版，子程序也改用更新版"""
    try:
        import ctypes
        k = ctypes.windll.kernel32
        k.SetPriorityClass(k.GetCurrentProcess(), 0x4000)     # BELOW_NORMAL_PRIORITY_CLASS
    except Exception:
        pass
    if moddir and os.path.isdir(moddir):
        import importlib.machinery
        import sys

        class _F:
            def find_spec(self, name, path=None, target=None):
                if name == 'photo_compress':
                    return importlib.machinery.PathFinder.find_spec(name, [moddir])
        sys.meta_path.insert(0, _F())
        sys.modules.pop('photo_compress', None)


def make_pool(workers, log=None):
    """建立程序池；失敗就退回執行緒池（比較慢、畫面可能較卡，但能用）"""
    from concurrent.futures import ProcessPoolExecutor
    import sys
    try:
        if getattr(sys, 'frozen', False) and not getattr(sys, 'tb_mp_ok', False):
            # 舊版外殼（EXE）不支援多程序：硬開會讓每個子程序都重新啟動整個軟體，電腦會卡死
            raise RuntimeError('目前的 EXE 是舊版外殼，請用最新的「打包成EXE.bat」重新打包一次，才能使用多核心')
        moddir = ''
        try:
            import updater
            md = updater.module_dir()
            if os.path.abspath(__file__).lower().startswith(os.path.abspath(md).lower()):
                moddir = md
        except Exception:
            pass
        pool = ProcessPoolExecutor(max_workers=max(1, workers), initializer=_child_init, initargs=(moddir,))
        pool.submit(abs, 1).result(timeout=90)               # 健康檢查
        return pool, True
    except Exception as e:  # noqa
        if log:
            log('多核心程序啟動失敗（%s），改用單程序多執行緒' % e)
        return ThreadPoolExecutor(max_workers=max(1, min(workers, 3)), initializer=low_priority), False


def default_workers():
    return max(1, min(os.cpu_count() or 2, 16))      # 子程序是低優先權，視窗不會被搶


def fmt_size(n):
    return '%.1f MB' % (n / 1048576.0) if n >= 1048576 else '%d KB' % round(n / 1024.0)
