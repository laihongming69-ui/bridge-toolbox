# -*- coding: utf-8 -*-
"""CAD(DWG) → PDF（progeCAD）：用 progeCAD 的 COM 介面開圖，逐個版面列印到 PDF 印表機，
自動填好跳出的存檔對話框，最後把各版面合併成一個多頁 PDF（一個版面一頁，依版面順序）。
列印設定（紙張、出圖型式表、比例）沿用圖面每個版面自己存的設定。與視窗無關，方便測試。"""
import os
import shutil
import sys
import threading
import time
import traceback

DLG_KEYS = ('pdf',)       # 視窗標題含 PDF 的對話框（Foxit、progeCAD 虛擬印表機等都適用）


def list_progids():
    """登錄檔裡所有 progeCAD(IntelliCAD) 的 COM ProgID，例如 Icad.Application.24.0.x64"""
    if os.name != 'nt':
        return []
    out = []
    try:
        import winreg
        i = 0
        while True:
            try:
                n = winreg.EnumKey(winreg.HKEY_CLASSES_ROOT, i)
            except OSError:
                break
            i += 1
            if n.lower().startswith('icad.application.'):
                out.append(n)
    except Exception:
        pass
    return sorted(out)


def default_progid():
    ids = list_progids()
    for pref in ('24.0', '25.0', '23.0', '22.0'):      # 26.0 在這台電腦上無法使用，排在最後
        for i in ids:
            if '.%s.' % pref in i:
                return i
    return ids[0] if ids else ''


# ----------------------------------------------------------------------------
# 對話框自動填寫（Win32）
# ----------------------------------------------------------------------------
def _win32():
    import win32con
    import win32gui
    return win32con, win32gui


def list_children(hwnd):
    _, g = _win32()
    out = []

    def cb(h, _):
        out.append((h, g.GetClassName(h), g.GetWindowText(h), g.GetDlgCtrlID(h)))
        return True
    g.EnumChildWindows(hwnd, cb, None)
    return out


def find_dialog():
    """找存檔對話框（標題含 PDF、視窗類別 #32770），回傳 hwnd 或 None"""
    _, g = _win32()
    found = []

    def cb(h, _):
        if g.IsWindowVisible(h) and g.GetClassName(h) == '#32770':
            if any(k in g.GetWindowText(h).lower() for k in DLG_KEYS):
                found.append(h)
        return True
    g.EnumWindows(cb, None)
    return found[0] if found else None


def hide_window(hwnd):
    """把對話框瞬間移到螢幕外（不搶焦點），畫面上就看不到它跳出來"""
    try:
        import win32con
        _, g = _win32()
        g.SetWindowPos(hwnd, 0, -32000, -32000, 0, 0,
                       win32con.SWP_NOSIZE | win32con.SWP_NOZORDER | win32con.SWP_NOACTIVATE)
    except Exception:
        pass


def minimize_app(pid):
    """把 progeCAD 主視窗最小化（不搶焦點）"""
    try:
        import win32process
        _, g = _win32()
        hits = []

        def cb(h, _):
            if g.IsWindowVisible(h) and not g.GetParent(h):
                try:
                    if win32process.GetWindowThreadProcessId(h)[1] == pid and g.GetWindowText(h):
                        hits.append(h)
                except Exception:
                    pass
            return True
        g.EnumWindows(cb, None)
        for h in hits:
            g.ShowWindow(h, 7)      # SW_SHOWMINNOACTIVE
        return len(hits)
    except Exception:
        return 0


def top_windows():
    """目前可見的頂層視窗 {hwnd: 標題}"""
    _, g = _win32()
    out = {}

    def cb(h, _):
        if g.IsWindowVisible(h) and not g.GetParent(h):
            t = g.GetWindowText(h)
            if t:
                out[h] = t
        return True
    g.EnumWindows(cb, None)
    return out


def close_new_viewers(before, log=None):
    """Foxit 印完會自動打開那張 PDF 的檢視視窗（標題含我們的暫存檔名 part_xx.pdf）。
    只關「這次工作開始後才出現」的視窗，不會動到你原本開著的 Foxit。"""
    n = 0
    try:
        import win32con
        _, g = _win32()
        for h, t in top_windows().items():
            if h not in before and 'part_' in t and '.pdf' in t.lower():
                g.PostMessage(h, win32con.WM_CLOSE, 0, 0)
                n += 1
    except Exception:
        pass
    return n


def dialog_titles():
    _, g = _win32()
    out = []

    def cb(h, _):
        if g.IsWindowVisible(h) and g.GetClassName(h) == '#32770':
            out.append(g.GetWindowText(h))
        return True
    g.EnumWindows(cb, None)
    return out


def fill_dialog(hwnd, path, append, log):
    con, g = _win32()
    kids = list_children(hwnd)
    if os.environ.get('CAD2PDF_DEBUG'):
        log('  對話框控制項：' + '; '.join('%s|%s|id%d' % (c, t[:14], i) for _, c, t, i in kids))
    # 1) 檔名欄：優先 id 1148（舊式存檔對話框的檔名 Edit），否則第一個 Edit
    edit = None
    for h, c, t, i in kids:
        if i == 1148 and c == 'Edit':
            edit = h
    if edit is None:
        for h, c, t, i in kids:
            if c == 'Edit':
                edit = h
                break
    if edit is None:
        # 不是存檔對話框，而是只有「確定」的提示窗（例如 Foxit 的訊息）：讀出文字、按確定
        texts = [t for _h, c, t, _i in kids if c == 'Static' and t]
        for h, c, t, i in kids:
            if c == 'Button' and i == 1:
                full = ''
                try:
                    full = ' '.join(g.GetWindowText(h2) for h2, c2, _t, _i2 in kids if c2 == 'Static')
                except Exception:
                    pass
                log('  提示窗「%s」→ 按確定' % (full or ' '.join(texts))[:120])
                g.SendMessage(h, con.BM_CLICK, 0, 0)
                return
        raise RuntimeError('找不到檔名輸入欄')
    g.SendMessage(edit, con.WM_SETTEXT, 0, path)
    # 2) 附加頁面（核取方塊）
    for h, c, t, i in kids:
        if c == 'Button' and '附加' in t:
            want = 1 if append else 0
            cur = g.SendMessage(h, con.BM_GETCHECK, 0, 0)
            if cur != want:
                g.SendMessage(h, con.BM_CLICK, 0, 0)
            log('  附加頁面核取方塊 → %s' % ('勾選' if append else '不勾'))
    # 3) 按「存檔」（IDOK=1）
    ok = None
    for h, c, t, i in kids:
        if c == 'Button' and i == 1:
            ok = h
    if ok is None:
        for h, c, t, i in kids:
            if c == 'Button' and ('存檔' in t or 'Save' in t or '儲存' in t):
                ok = h
    if ok is None:
        raise RuntimeError('找不到存檔按鈕')
    g.SendMessage(ok, con.BM_CLICK, 0, 0)


def dismiss_confirm(log):
    """若跳出「檔案已存在，要取代嗎？」之類的確認窗，按「是」"""
    con, g = _win32()
    hits = []

    def cb(h, _):
        if g.IsWindowVisible(h) and g.GetClassName(h) == '#32770':
            t = g.GetWindowText(h)
            if any(k in t for k in ('確認', '另存', 'Confirm', 'Save As')) and not any(k in t.lower() for k in DLG_KEYS):
                hits.append(h)
        return True
    g.EnumWindows(cb, None)
    for h in hits:
        for ch, c, t, i in list_children(h):
            if c == 'Button' and (t.replace('&', '').startswith(('是', 'Yes')) or i == 6):
                g.SendMessage(ch, con.BM_CLICK, 0, 0)
                log('  已確認覆蓋提示')
                return True
    return False


# ----------------------------------------------------------------------------
# progeCAD 工作（在獨立執行緒跑，因為列印時會被對話框卡住）
# ----------------------------------------------------------------------------
class Job:
    def __init__(self, dwg, progid, log, quiet=True):
        self.dwg, self.progid, self.log, self.quiet = dwg, progid, log, quiet
        self.err = None
        self.done = False
        self.stop = False
        self.target = ''
        self.parts = []
        self.busy = threading.Event()
        self.total = 0
        self.index = 0
        import tempfile
        self.tmpdir = tempfile.mkdtemp(prefix='cad2pdf_')

    def enum_layouts(self, doc):
        names = []
        n = doc.Layouts.Count
        for i in range(n):
            lay = doc.Layouts.Item(i)
            nm = ''
            try:
                nm = str(lay.Name or '')
            except Exception:
                pass
            if not nm:       # progeCAD 讀不到名稱時：切換到該版面，讀目前版面名稱 CTAB
                try:
                    doc.ActiveLayout = lay
                    nm = str(doc.GetVariable('CTAB'))
                except Exception:
                    pass
            names.append((i, nm))
        return names

    def run(self):
        import pythoncom
        import win32com.client
        pythoncom.CoInitialize()
        app = doc = None
        try:
            app = win32com.client.DispatchEx(self.progid)
            app.Visible = True
            self.log('  已啟動 progeCAD %s' % app.Version)
            if self.quiet:
                try:
                    minimize_app(int(app.ProcessID))
                except Exception:
                    pass
            doc = app.Documents.Open(self.dwg)
            lays = [(i, nm) for i, nm in self.enum_layouts(doc) if nm and nm.lower() != 'model']
            if not lays:
                raise RuntimeError('這個圖檔找不到可輸出的版面（只有 Model？）')
            self.total = len(lays)
            self.log('  版面：%s' % '、'.join(nm for _i, nm in lays))
            for k, (idx, name) in enumerate(lays):
                if self.stop:
                    break
                self.index = k
                tgt = os.path.join(self.tmpdir, 'part_%02d.pdf' % k)
                self.target = tgt
                self.busy.set()
                try:
                    doc.ActiveLayout = doc.Layouts.Item(idx)
                    app.PlotManager.UseSettingsFromLayout = True
                    app.PlotManager.PrintToDevice()
                    t1 = time.time()
                    while time.time() - t1 < 120 and not self.stop:   # 等對話框被填完、檔案寫好
                        if os.path.exists(tgt) and os.path.getsize(tgt) > 0:
                            time.sleep(0.8)
                            break
                        time.sleep(0.4)
                finally:
                    self.busy.clear()
                if os.path.exists(tgt):
                    self.parts.append((name, tgt))
                    self.log('  ✓ 版面 %s（%d/%d）' % (name, k + 1, lays and len(lays)))
                else:
                    self.log('  ✗ 版面 %s 沒有產生檔案' % name)
        except Exception:
            self.err = traceback.format_exc()
        finally:
            try:
                if doc is not None:
                    doc.Close(False)
            except Exception:
                pass
            try:
                if app is not None:
                    app.Quit()
            except Exception:
                pass
            pythoncom.CoUninitialize()
            self.done = True


def merge_parts(parts, out_pdf, log):
    from pypdf import PdfReader, PdfWriter
    w = PdfWriter()
    for name, p in parts:
        start = len(w.pages)
        for pg in PdfReader(p).pages:
            w.add_page(pg)
        try:
            w.add_outline_item(name, start)
        except Exception:
            pass
    os.makedirs(os.path.dirname(os.path.abspath(out_pdf)), exist_ok=True)
    with open(out_pdf, 'wb') as f:
        w.write(f)
    return len(w.pages)




def convert(dwg, out_pdf, progid=None, log=print, cancel=None, timeout=900, quiet=True):
    """把一個 DWG 輸出成多頁 PDF。成功回傳頁數；失敗丟出 RuntimeError。
    主執行緒負責盯對話框，COM 在另一條執行緒。"""
    progid = progid or default_progid()
    if not progid:
        raise RuntimeError('找不到 progeCAD（沒有登錄 COM 介面）')
    job = Job(os.path.abspath(dwg), progid, log, quiet)
    t = threading.Thread(target=job.run, daemon=True)
    t.start()
    last_fill, last_diag, t0 = 0, time.time(), time.time()
    try:
        before = set(top_windows())
    except Exception:
        before = set()
    try:
        while not job.done:
            time.sleep(0.1)
            if cancel is not None and cancel.is_set():
                job.stop = True
            if time.time() - t0 > timeout:
                job.stop = True
                log('  逾時，放棄這個檔案')
                break
            try:
                close_new_viewers(before)
                h = find_dialog()
                if h and job.target and time.time() - last_fill > 1.5:
                    if quiet:
                        hide_window(h)
                    fill_dialog(h, job.target, append=False, log=log)
                    last_fill = time.time()
                    time.sleep(1.0)
                    dismiss_confirm(log)
                elif job.busy.is_set() and time.time() - last_diag > 30:
                    last_diag = time.time()
                    log('  （等待中…畫面上的對話框：%s）' % ' | '.join(dialog_titles()))
            except Exception as e:  # noqa
                log('  對話框處理錯誤：%s' % e)
                last_fill = time.time()
        t.join(10)
        for _ in range(12):       # 收尾：再清幾秒，把最後一張的檢視視窗也關掉
            close_new_viewers(before)
            time.sleep(0.25)
        if job.err:
            raise RuntimeError(job.err.strip().splitlines()[-1])
        if cancel is not None and cancel.is_set():
            raise RuntimeError('已取消')
        if not job.parts:
            raise RuntimeError('沒有產生任何頁面（請確認圖面版面的印表機是 PDF 印表機）')
        n = merge_parts(job.parts, out_pdf, log)
        if len(job.parts) < job.total:
            log('  ⚠ 只輸出了 %d/%d 個版面，請檢查' % (len(job.parts), job.total))
        return n
    finally:
        shutil.rmtree(job.tmpdir, ignore_errors=True)
