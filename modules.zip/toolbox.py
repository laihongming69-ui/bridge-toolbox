# -*- coding: utf-8 -*-
"""
橋梁檢測百寶袋（製作：泓銘）
  分頁 1  檢測表整理   ：刪無損傷、條件篩選、遠近照片、排序、每頁固定缺失數
  分頁 2  Word 轉 PDF  ：多檔拖入，各自轉成各自的 PDF（不合併）
  分頁 3  基本資料整理 ：壓縮檔 → 單一 Word，只留最新 N 張照片（照片固定下載嵌入）
  分頁 4  PDF 合併     ：多個 PDF 依清單順序合成一個
  分頁 5  送印拆分     ：依「一張紙」拆成彩色版／黑白版（彩色版奇數頁補空白頁）
  分頁 6  CAD 轉 PDF   ：用 progeCAD 把 DWG 的每個版面輸出，合併成一個多頁 PDF
"""
import os
import sys
import threading
import time

import basic_merge
import bridge_tidy
import cad_pdf
import pdf_ops
import photo_compress
import updater
import word2pdf

VERSION = '1.11.1'
AUTHOR = '泓銘'
FONT = 'Microsoft JhengHei UI'
BG, CARD, LINE = '#F3F5F9', '#FFFFFF', '#DCE2EC'
ACC, ACC_D, ACC_L = '#1E5799', '#164678', '#E8F0FB'
TXT, SUB, OKC, BAD = '#1F2937', '#6B7280', '#2E7D32', '#C62828'


# ----------------------------------------------------------------------------
# 三個工作（與視窗無關，方便測試）。ctx 提供 log / progress / status / cancel
# ----------------------------------------------------------------------------
class Ctx:
    def __init__(self, log=print, progress=None, status=None, cancel=None):
        self.log = log
        self.progress = progress or (lambda frac: None)
        self.status = status or (lambda path, kind, text='': None)
        self.cancel = cancel or threading.Event()


def make_pdfs(docx_paths, ctx):
    """把剛產生的 Word 轉成 PDF（放在 Word 旁邊）。Word 失敗會等幾秒重試，再改用 LibreOffice；失敗不影響 Word 結果"""
    docx_paths = [p for p in docx_paths if p and os.path.exists(p)]
    if not docx_paths:
        return
    ctx.log('同時生成 PDF（%d 個）…' % len(docx_paths))
    todo = list(docx_paths)
    engines = [None]
    if word2pdf.LibreEngine.available():
        engines.append(word2pdf.LibreEngine)
    for attempt, eng in enumerate(engines * 1):
        if not todo or ctx.cancel.is_set():
            break
        for rnd in range(2 if eng is None else 1):
            if rnd:
                ctx.log('  稍等幾秒後重試…')
                time.sleep(4)
            failed = []

            def ev(kind, i, text, cur=todo, failed=failed):
                if kind == 'info':
                    ctx.log(text)
                elif kind == 'ok':
                    ctx.log('  PDF ✓ ' + os.path.basename(cur[i]))
                elif kind == 'fail':
                    failed.append(cur[i])
                    ctx.log('  PDF ✗ %s：%s' % (os.path.basename(cur[i]), text))
            try:
                word2pdf.convert_batch(todo, None, 1, True, ev, ctx.cancel, engine=eng)
            except Exception as e:  # noqa
                ctx.log('PDF 生成失敗：%s' % e)
                failed = list(todo)
            todo = failed
            if not todo:
                break
        if todo and eng is None and len(engines) > 1:
            ctx.log('  改用 LibreOffice 轉 PDF…')
    if todo:
        ctx.log('提示：%d 個檔案 PDF 沒轉成功。請先確認 Word 檔能正常開啟，或改用「Word 轉 PDF」分頁。' % len(todo))


def work_tidy(files, o, ctx):
    ok = bad = 0
    d = None
    made = []
    for i, f in enumerate(files):
        if ctx.cancel.is_set():
            break
        ctx.log('== ' + os.path.basename(f))
        ctx.status(f, 'run')
        try:
            d = os.path.join(os.path.dirname(f), '整理後')
            made.append(os.path.join(d, os.path.basename(f)))
            bridge_tidy.process(f, os.path.join(d, os.path.basename(f)), log=ctx.log,
                                del_d1=o['d1'], del_e0=o['e0'], far_near=o['fn'],
                                per_page=o['pp'], sort_mode=o['sort'],
                                conds=o['conds'], match=o['match'])
            ok += 1
            ctx.status(f, 'ok')
        except Exception as e:  # noqa
            bad += 1
            ctx.log('失敗：%s' % e)
            ctx.status(f, 'fail', str(e)[:60])
        ctx.progress((i + 1) / len(files))
    if o.get('pdf'):
        make_pdfs(made if ok else [], ctx)
    return '完成：成功 %d 個%s。請用 Word 開啟檢查分頁與照片。' % (ok, '、失敗 %d 個' % bad if bad else ''), d


def work_pdf(files, o, ctx):
    files = word2pdf.collect(files)
    done = {'n': 0}

    def ev(kind, i, text):
        if kind == 'info':
            ctx.log(text)
            return
        p = files[i]
        if kind == 'start':
            ctx.status(p, 'run')
        else:
            ctx.status(p, kind, text)
            done['n'] += 1
            ctx.progress(done['n'] / len(files))
    ok, bad, secs, dirs = word2pdf.convert_batch(files, o['outdir'], o['jobs'], o['over'], ev, ctx.cancel)
    return '完成：成功 %d 個%s，共 %.1f 秒' % (ok, '、失敗 %d 個' % bad if bad else '', secs), \
        (sorted(dirs)[0] if dirs else None)


def work_merge(files, o, ctx):
    res, d = [], None
    for i, p in enumerate(files):
        if ctx.cancel.is_set():
            break
        ctx.log('######## ' + os.path.basename(p))
        ctx.status(p, 'run')
        try:
            r = basic_merge.run_paths([p], o['outdir'], o['keep'], o['embed'], ctx.log)
            res += r
            d = o['outdir'] or os.path.dirname(os.path.abspath(p))
            ctx.status(p, 'ok')
        except Exception as e:  # noqa
            ctx.log('失敗：%s' % e)
            ctx.status(p, 'fail', str(e)[:60])
        ctx.progress((i + 1) / len(files))
    if o.get('pdf'):
        make_pdfs([x if isinstance(x, str) else getattr(x, 'path', None) for x in res], ctx)
    return '完成：共產生 %d 個 Word。請用 Word 開啟檢查。' % len(res), d


def work_pdfmerge(files, o, ctx):
    ctx.log('合併 %d 個 PDF（依清單順序）' % len(files))
    for f in files:
        ctx.status(f, 'run')
    name = o['name'] if o['name'].lower().endswith('.pdf') else o['name'] + '.pdf'
    od = o['outdir'] or os.path.dirname(os.path.abspath(files[0]))
    try:
        out, pages = pdf_ops.merge_pdfs(files, os.path.join(od, name), o['bookmarks'], ctx.log)
    except Exception:
        for f in files:
            ctx.status(f, 'fail')
        raise
    for f in files:
        ctx.status(f, 'ok')
    ctx.progress(1)
    return '完成：已合併成 %s（%d 頁）' % (os.path.basename(out), pages), os.path.dirname(out)


def work_cad(files, o, ctx):
    ok = bad = 0
    d = None
    for i, f in enumerate(files):
        if ctx.cancel.is_set():
            break
        ctx.log('== ' + os.path.basename(f))
        ctx.status(f, 'run')
        try:
            od = o['outdir'] or os.path.dirname(os.path.abspath(f))
            out = pdf_ops.unique_path(os.path.join(od, os.path.splitext(os.path.basename(f))[0] + '.pdf'))
            n = cad_pdf.convert(f, out, o['progid'], ctx.log, ctx.cancel, quiet=o['quiet'])
            ctx.log('  完成：%s（%d 頁）' % (os.path.basename(out), n))
            d = od
            ok += 1
            ctx.status(f, 'ok', '%d 頁' % n)
        except Exception as e:  # noqa
            bad += 1
            ctx.log('  失敗：%s' % e)
            ctx.status(f, 'fail', str(e)[:60])
        ctx.progress((i + 1) / len(files))
    return '完成：成功 %d 個%s' % (ok, '、失敗 %d 個' % bad if bad else ''), d


def work_inspect(files, o, ctx):
    import inspect_check
    allres = []
    for i, f in enumerate(files):
        if ctx.cancel.is_set():
            return
        ctx.log('== ' + os.path.basename(f))
        try:
            res = inspect_check.run_file(f, o['mode'], ctx.log, lambda x: ctx.progress((i + 0.9 * x) / len(files)),
                                         ctx.cancel, inspect_check.load_rules(o.get('rules')),
                                         make_pool=photo_compress.make_pool, workers=min(6, photo_compress.default_workers()))
        except ImportError:
            ctx.log('缺少 pdfplumber：請用最新的「打包成EXE.bat」重新打包一次（只要一次）')
            return
        except Exception as e:
            ctx.log('失敗：%s' % e)
            continue
        if not res:
            ctx.log('沒有讀到任何橋梁（是不是選錯 PDF？）')
            continue
        od = o['outdir'] or os.path.dirname(f)
        base = os.path.join(od, os.path.splitext(os.path.basename(f))[0] + '_檢查報告_' + ('汛期前' if o['mode'] == 'pre' else '汛期後'))
        out = inspect_check.write_report(base, res, o['mode'], os.path.basename(f))
        ne = sum(1 for _b, iss, _d in res for x in iss if x['level'] == '錯誤')
        ns = sum(1 for _b, iss, _d in res for x in iss if x['level'] == '疑似')
        ctx.log('%d 座橋：錯誤 %d、疑似 %d → %s' % (len(res), ne, ns, os.path.basename(out)))
        ctx.progress((i + 1) / len(files))


def work_photo(files, o, ctx):
    """多核心（子程序）壓縮：畫面所在的程序只負責顯示，所以不會卡；每張完成就在清單打勾"""
    from concurrent.futures import wait
    n = len(files)
    st = {'skip': 0, 'ok': 0, 'bad': 0, 'old': 0, 'new': 0, 'done': 0, 'dir': None}
    lock = threading.Lock()
    t_start = time.time()
    pool, is_proc = photo_compress.make_pool(o['workers'], ctx.log)
    ctx.log('背景程序準備好：%.1f 秒' % (time.time() - t_start))
    ctx.log(('使用多核心，%d 個同時壓縮' % o['workers']) if is_proc else '單程序模式（較慢）：重新打包最新的 EXE 後就能使用多核心')

    def settle(f, res, err=None):
        with lock:
            st['done'] += 1
            done = st['done']
            if done == 1:
                ctx.log('第一個完成：%.1f 秒' % (time.time() - t_start))
            if err is not None:
                st['bad'] += 1
                ctx.log('%s：失敗：%s' % (os.path.basename(f), err))
                ctx.status(f, 'fail', str(err)[:60])
            elif res[0] is None:
                st['skip'] += 1
                ctx.log('%s：已經夠小或已壓縮過，略過' % os.path.basename(f))
                ctx.status(f, 'ok', '略過')
            else:
                out, a, b, note = res
                st['ok'] += 1
                st['old'] += a
                st['new'] += b
                st['dir'] = os.path.dirname(out)
                ctx.log('%s：%s → %s（省 %d%%）%s' % (os.path.basename(f), photo_compress.fmt_size(a),
                        photo_compress.fmt_size(b), round((1 - b / float(a)) * 100) if a else 0, '  ' + note if note else ''))
                ctx.status(f, 'ok', '%s→%s' % (photo_compress.fmt_size(a), photo_compress.fmt_size(b)))
        ctx.progress(done / float(n))

    def outdir_of(f):
        return o['outdir'] or os.path.join(os.path.dirname(os.path.abspath(f)), '壓縮後')

    imgs = [f for f in files if not f.lower().endswith(photo_compress.DOCX_EXT)]
    docs = [f for f in files if f.lower().endswith(photo_compress.DOCX_EXT)]
    pending = set()
    try:
        for f in imgs:
            fu = pool.submit(photo_compress.process_file, f, outdir_of(f), o['edge'], o['quality'], o['max_kb'], o['skip'], o['target_kb'])
            pending.add(fu)

            def cb(fu, f=f):
                try:
                    r = fu.result()
                except Exception as e:  # noqa
                    if fu.cancelled() or ctx.cancel.is_set():
                        return
                    settle(f, None, e)
                    return
                settle(f, (r[0], r[1], r[2], '') if r[0] else (None,))
            fu.add_done_callback(cb)
        for f in docs:                                  # Word：一份一份處理，內部的照片丟給程序池平行壓
            if ctx.cancel.is_set():
                break
            ctx.status(f, 'run')
            try:
                out, a, b, k = photo_compress.compress_docx(f, outdir_of(f), o['edge'], o['quality'], o['max_kb'],
                                                             log=ctx.log, cancel=ctx.cancel.is_set, pool=pool,
                                                             skip_marked=o['skip'], target_kb=o['target_kb'])
                settle(f, (out, a, b, '%d 張照片' % k) if out else (None,))
            except Exception as e:  # noqa
                settle(f, None, e)
        while pending:
            if ctx.cancel.is_set():
                for fu in pending:
                    fu.cancel()
                photo_compress.kill_all()               # 按「停止」＝馬上結束背景程序
                break
            _d, pending = wait(pending, timeout=0.3)
    finally:
        try:
            pool.shutdown(wait=False, cancel_futures=True)
        except TypeError:
            pool.shutdown(wait=False)
        if pool in photo_compress.ACTIVE_POOLS:
            photo_compress.ACTIVE_POOLS.remove(pool)
    sv = '，共 %s → %s' % (photo_compress.fmt_size(st['old']), photo_compress.fmt_size(st['new'])) if st['old'] else ''
    return '完成：成功 %d 個%s%s%s' % (st['ok'], '、略過 %d 個' % st['skip'] if st['skip'] else '',
                                      '、失敗 %d 個' % st['bad'] if st['bad'] else '', sv), st['dir']


def work_print(files, o, ctx):
    ok = bad = 0
    d = None
    for i, f in enumerate(files):
        if ctx.cancel.is_set():
            break
        ctx.log('== ' + os.path.basename(f))
        ctx.status(f, 'run')
        try:
            cs = o['colors'](f)
            outs = pdf_ops.split_print(f, cs, per=o['per'], outdir=o['outdir'], log=ctx.log, by_size=o['by_size'])
            if outs:
                d = os.path.dirname(outs[0])
            ok += 1
            ctx.status(f, 'ok')
        except Exception as e:  # noqa
            bad += 1
            ctx.log('  失敗：%s' % e)
            ctx.status(f, 'fail', str(e)[:60])
        ctx.progress((i + 1) / len(files))
    return '完成：成功 %d 個%s' % (ok, '、失敗 %d 個' % bad if bad else ''), d


class CpuMeter:
    """整台電腦的 CPU 使用率（%）。Windows 用 GetSystemTimes，不需要額外套件；取不到就回傳 None"""

    def __init__(self):
        self.prev = None

    def _times(self):
        if os.name == 'nt':
            import ctypes
            from ctypes import wintypes
            idle, kern, user = wintypes.FILETIME(), wintypes.FILETIME(), wintypes.FILETIME()
            if not ctypes.windll.kernel32.GetSystemTimes(ctypes.byref(idle), ctypes.byref(kern), ctypes.byref(user)):
                return None
            v = [(x.dwHighDateTime << 32) | x.dwLowDateTime for x in (idle, kern, user)]
            return v[0], v[1] + v[2]            # kernel 時間已含 idle
        with open('/proc/stat') as f:
            p = [int(x) for x in f.readline().split()[1:]]
        return p[3] + (p[4] if len(p) > 4 else 0), sum(p)

    def read(self):
        try:
            cur = self._times()
        except Exception:
            return None
        if cur is None:
            return None
        prev, self.prev = self.prev, cur
        if prev is None or cur[1] <= prev[1]:
            return None
        busy = 1 - (cur[0] - prev[0]) / (cur[1] - prev[1])
        return max(0.0, min(100.0, busy * 100))


# ----------------------------------------------------------------------------
# 視窗
# ----------------------------------------------------------------------------
def single_instance():
    """一次只能開一個視窗：已經有在跑的就把它叫到前面，這個直接結束（只在 Windows 有作用）"""
    if os.name != 'nt':
        return True
    try:
        import ctypes
        k, u = ctypes.windll.kernel32, ctypes.windll.user32
        h = k.CreateMutexW(None, False, 'Local\\BridgeToolbox_BaiBaoDai_SingleInstance')
        if k.GetLastError() != 183:               # ERROR_ALREADY_EXISTS
            single_instance.keep = h
            return True
        found = []
        WNDENUM = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)

        def cb(hwnd, _):
            n = u.GetWindowTextLengthW(hwnd)
            if n:
                buf = ctypes.create_unicode_buffer(n + 1)
                u.GetWindowTextW(hwnd, buf, n + 1)
                if buf.value.startswith('橋梁檢測百寶袋') and u.IsWindowVisible(hwnd):
                    found.append(hwnd)
            return True
        u.EnumWindows(WNDENUM(cb), 0)
        if found:
            u.ShowWindow(found[0], 9)             # SW_RESTORE
            u.SetForegroundWindow(found[0])
        return False
    except Exception:
        return True


def boot_log(msg):
    """在 %LOCALAPPDATA%\\橋梁檢測工具箱\\啟動紀錄.txt 記一行（排查「更新後又變回舊版」用）"""
    try:
        d = updater.data_root()
        os.makedirs(d, exist_ok=True)
        p = os.path.join(d, '啟動紀錄.txt')
        if os.path.exists(p) and os.path.getsize(p) > 40000:
            os.remove(p)
        with open(p, 'a', encoding='utf-8') as f:
            f.write('%s  %s\n' % (time.strftime('%Y-%m-%d %H:%M:%S'), msg))
    except Exception:
        pass


def run_gui():
    if not single_instance():
        # 第二個視窗：不要留下「開機中」旗標，否則下次啟動會誤以為更新版壞了而退回內建版
        try:
            os.remove(os.path.join(updater.data_root(), '.booting'))
        except OSError:
            pass
        boot_log('第二個視窗被擋下（已有一個在執行）')
        return
    boot_log('啟動 v%s  載入自 %s' % (VERSION, os.path.dirname(os.path.abspath(__file__))))
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk

    try:
        from tkinterdnd2 import TkinterDnD, DND_FILES
        root = TkinterDnD.Tk()
        dnd = True
    except Exception:
        root = tk.Tk()
        dnd = False

    root.title('橋梁檢測百寶袋 v%s' % VERSION)
    root.geometry('860x620')
    root.minsize(720, 540)
    root.configure(bg=BG)
    try:
        base = getattr(sys, '_MEIPASS', os.path.dirname(os.path.abspath(__file__)))
        root.iconbitmap(os.path.join(base, 'icon.ico'))
    except Exception:
        pass

    st = ttk.Style()
    try:
        st.theme_use('clam')
    except Exception:
        pass
    st.configure('Card.TCheckbutton', background=CARD, foreground=TXT, font=(FONT, 10))
    st.map('Card.TCheckbutton', background=[('active', CARD)])
    st.configure('Card.TRadiobutton', background=CARD, foreground=TXT, font=(FONT, 10))
    st.map('Card.TRadiobutton', background=[('active', CARD)])
    st.configure('Card.TLabel', background=CARD, foreground=TXT, font=(FONT, 10))
    st.configure('Sub.TLabel', background=CARD, foreground=SUB, font=(FONT, 9))
    st.configure('TCombobox', font=(FONT, 10))
    st.configure('Acc.Horizontal.TProgressbar', troughcolor=LINE, background=ACC, bordercolor=LINE,
                 lightcolor=ACC, darkcolor=ACC)

    # ---------- 標題列 + 分頁列
    head = tk.Frame(root, bg=ACC)
    head.pack(fill='x')
    titlerow = tk.Frame(head, bg=ACC)
    titlerow.pack(anchor='w', padx=24, pady=(14, 0))
    back = tk.Label(titlerow, text='‹ 首頁', bg=ACC_D, fg='white', font=(FONT, 11, 'bold'), padx=12, pady=3, cursor='hand2')
    title_lbl = tk.Label(titlerow, text='橋梁檢測百寶袋', bg=ACC, fg='white', font=(FONT, 18, 'bold'))
    title_lbl.pack(side='left')
    back.bind('<Enter>', lambda e: back.configure(bg='#0F3358'))
    back.bind('<Leave>', lambda e: back.configure(bg=ACC_D))
    sub = tk.Label(head, text='', bg=ACC, fg='#C9DBF2', font=(FONT, 10))
    sub.pack(anchor='w', padx=24, pady=(2, 8))
    tk.Label(head, text='製作：%s　v%s' % (AUTHOR, VERSION), bg=ACC, fg='#C9DBF2', font=(FONT, 10)).place(
        relx=1.0, rely=0.0, anchor='ne', x=-20, y=14)
    upd_btn = tk.Label(head, text='檢查更新', bg=ACC, fg='#C9DBF2', font=(FONT, 10, 'underline'), cursor='hand2')
    upd_btn.place(relx=1.0, rely=0.0, anchor='ne', x=-20, y=40)
    tk.Frame(head, bg=ACC, height=6).pack()
    content = tk.Frame(root, bg=BG)
    content.pack(fill='both', expand=True)

    def card(parent, title, expand=False):
        o = tk.Frame(parent, bg=CARD, highlightthickness=1, highlightbackground=LINE)
        o.pack(fill='both' if expand else 'x', expand=expand, pady=(0, 10))
        tk.Label(o, text=title, bg=CARD, fg=TXT, font=(FONT, 11, 'bold')).pack(anchor='w', padx=14, pady=(10, 4))
        i = tk.Frame(o, bg=CARD)
        i.pack(fill='both', expand=True, padx=14, pady=(0, 12))
        return i

    def button(parent, text, cmd, primary=False, size=10):
        bgc, hov = (ACC, ACC_D) if primary else (ACC_L, '#D3E3F8')
        b = tk.Label(parent, text=text, bg=bgc, fg='white' if primary else ACC,
                     font=(FONT, size, 'bold'), padx=14, pady=7, cursor='hand2')
        b.bind('<Enter>', lambda e: b.configure(bg=hov))
        b.bind('<Leave>', lambda e: b.configure(bg=bgc))
        b.bind('<Button-1>', lambda e: cmd())
        return b

    # ------------------------------------------------------------------
    class Page:
        """一個分頁：左＝拖曳區＋清單＋紀錄；右＝選項＋開始"""

        def __init__(self, title, subtitle, zone_text, zone_sub, filetypes, accept, build_opts, worker,
                     start_text, dirs_ok=False, reorder=False, preview=False, expand_pdf=False):
            self.title, self.subtitle = title, subtitle
            self.accept, self.worker, self.filetypes, self.dirs_ok = accept, worker, filetypes, dirs_ok
            self.expand_pdf = expand_pdf
            self.preview = None
            self.items, self.status = [], {}
            self.busy = False
            self._logbuf, self._logflag = [], False
            self.cancel = threading.Event()
            self.outdir = None
            self.frame = tk.Frame(content, bg=BG)
            body = tk.Frame(self.frame, bg=BG)
            body.pack(fill='both', expand=True, padx=20, pady=14)
            body.columnconfigure(0, weight=3, uniform='c')
            body.columnconfigure(1, weight=2, uniform='c')
            body.rowconfigure(0, weight=1)
            left = tk.Frame(body, bg=BG)
            right = tk.Frame(body, bg=BG)
            left.grid(row=0, column=0, sticky='nsew', padx=(0, 10))
            right.grid(row=0, column=1, sticky='nsew', padx=(10, 0))

            # 上＝檔案／預覽（重點），下＝執行紀錄；中間的橫條可以用滑鼠上下拖曳調整高度
            pw = tk.PanedWindow(left, orient='vertical', bg=BG, sashwidth=8, sashrelief='flat', bd=0, opaqueresize=True)
            pw.pack(fill='both', expand=True)
            topf = tk.Frame(pw, bg=BG)
            logf = tk.Frame(pw, bg=BG)
            pw.add(topf, stretch='always', minsize=220)
            pw.add(logf, stretch='never', minsize=60, height=96)
            fc = card(topf, '檔案', expand=not preview)
            self.zone = tk.Canvas(fc, height=84, bg=ACC_L, highlightthickness=0, cursor='hand2')
            self.zone.pack(fill='x')

            def draw(_e=None, z=self.zone):
                z.delete('all')
                w, h = z.winfo_width(), z.winfo_height()
                z.create_rectangle(6, 6, w - 6, h - 6, outline=ACC, dash=(6, 4), width=2)
                z.create_text(w // 2, h // 2 - 13, text=zone_text if dnd else '點這裡選擇檔案',
                              fill=ACC, font=(FONT, 14, 'bold'))
                z.create_text(w // 2, h // 2 + 16, text=zone_sub, fill=SUB, font=(FONT, 10))
            self.zone.bind('<Configure>', draw)
            lf = tk.Frame(fc, bg=CARD)
            lf.pack(fill='both', expand=True, pady=(10, 0))
            self.lb = tk.Listbox(lf, height=4, bd=0, highlightthickness=1, highlightbackground=LINE,
                                 font=(FONT, 10), activestyle='none', selectmode='extended',
                                 selectbackground=ACC_L, selectforeground=TXT)
            sb = ttk.Scrollbar(lf, orient='vertical', command=self.lb.yview)
            self.lb.configure(yscrollcommand=sb.set)
            self.lb.pack(side='left', fill='both', expand=True)
            sb.pack(side='right', fill='y')
            br = tk.Frame(fc, bg=CARD)
            br.pack(fill='x', pady=(8, 0))
            button(br, '移除選取', self.remove_sel).pack(side='left')
            button(br, '清空', self.clear_all).pack(side='left', padx=8)
            if reorder:
                button(br, '▲', lambda: self.move(-1)).pack(side='left')
                button(br, '▼', lambda: self.move(1)).pack(side='left', padx=8)
                button(br, '依檔名排序', self.sort_names).pack(side='left')
            self.cnt = tk.Label(br, text='共 0 個', bg=CARD, fg=SUB, font=(FONT, 10))
            self.cnt.pack(side='right')
            self.zone.bind('<Button-1>', self.pick)
            self.lb.bind('<Delete>', lambda e: self.remove_sel())
            if dnd:
                for w in (self.zone, self.lb):
                    w.drop_target_register(DND_FILES)
                    w.dnd_bind('<<Drop>>', lambda e: self.add_paths(root.tk.splitlist(e.data)))

            if preview:
                self.preview = SheetPreview(topf, self)
                self.lb.bind('<<ListboxSelect>>', self.on_select)
            lc = card(logf, '執行紀錄', expand=True)
            self.prog = ttk.Progressbar(lc, style='Acc.Horizontal.TProgressbar', maximum=100)
            self.prog.pack(fill='x', pady=(0, 8))
            tf = tk.Frame(lc, bg=CARD)
            tf.pack(fill='both', expand=True)
            self.out = tk.Text(tf, height=2, bd=0, highlightthickness=1, highlightbackground=LINE,
                               font=(FONT, 9), bg='#FAFBFD', fg=TXT, state='disabled', wrap='word')
            osb = ttk.Scrollbar(tf, orient='vertical', command=self.out.yview)
            self.out.configure(yscrollcommand=osb.set)
            self.out.pack(side='left', fill='both', expand=True)
            osb.pack(side='right', fill='y')

            bot = tk.Frame(right, bg=BG)
            bot.pack(fill='x', side='bottom')
            # 右側選項放在畫布內：不顯示捲軸，空間不夠時可用滑鼠滾輪
            sc = tk.Canvas(right, bg=BG, highlightthickness=0)
            sc.pack(side='left', fill='both', expand=True)
            optsf = tk.Frame(sc, bg=BG)
            win = sc.create_window((0, 0), window=optsf, anchor='nw')
            optsf.bind('<Configure>', lambda e, sc=sc: sc.configure(scrollregion=sc.bbox('all')))
            sc.bind('<Configure>', lambda e, sc=sc, win=win: sc.itemconfigure(win, width=e.width))

            def wheel(e, sc=sc, f=optsf):
                if f.winfo_reqheight() > sc.winfo_height():
                    sc.yview_scroll(int(-e.delta / 120), 'units')
            sc.bind('<Enter>', lambda e, sc=sc, wheel=wheel: sc.bind_all('<MouseWheel>', wheel))
            sc.bind('<Leave>', lambda e, sc=sc: sc.unbind_all('<MouseWheel>'))
            self.opts_parent = optsf
            self.get_opts = build_opts(optsf, self)
            row = tk.Frame(bot, bg=BG)
            row.pack(fill='x')
            self.start_text = start_text
            self.start = button(row, start_text, self.go, primary=True, size=13)
            self.start.pack(side='left', fill='x', expand=True, ipady=3)
            self.openb = button(row, '開啟輸出資料夾', self.open_out)
            self.msg = tk.Label(bot, text='', bg=BG, fg=SUB, font=(FONT, 9), wraplength=300, justify='left')
            self.msg.pack(anchor='w', pady=(6, 0))

        # --- 清單
        def label_of(self, p):
            kind, _, extra = self.status.get(p, '').partition('|')
            mark = {'run': '… ', 'ok': '✓ ', 'fail': '✗ '}.get(kind, '　')
            return '%s%s    %s' % (mark, os.path.basename(p), extra or os.path.dirname(p))

        def _color(self, k):
            kind = self.status.get(self.items[k], '').split('|')[0]
            self.lb.itemconfig(k, foreground={'ok': OKC, 'fail': BAD}.get(kind, TXT))

        def _rebuild(self):
            """整批重畫清單（一次刪、一次插）。Tk 清單逐列刪插在上千筆時會變成平方級的慢，會讓視窗沒有回應"""
            sel = self.lb.curselection()
            y = self.lb.yview()[0]
            self.lb.delete(0, 'end')
            if self.items:
                self.lb.insert('end', *[self.label_of(p) for p in self.items])
            for k, p in enumerate(self.items):
                if self.status.get(p, '').partition('|')[0] in ('ok', 'fail'):
                    self._color(k)
            for s in sel:
                if s < len(self.items):
                    self.lb.selection_set(s)
            self.lb.yview_moveto(y)

        def refresh(self, i=None):
            if i is None:
                self._rebuild()
                return
            self.lb.delete(i)
            self.lb.insert(i, self.label_of(self.items[i]))
            self._color(i)

        def refresh_many(self, ks):
            if len(ks) > 8:
                self._rebuild()
            else:
                for k in ks:
                    self.refresh(k)

        def counter(self):
            self.cnt.configure(text='共 %d 個' % len(self.items))

        def add_paths(self, paths):
            for p in paths:
                p = os.path.normpath(p.strip('"'))
                found = [p]
                if self.expand_pdf and os.path.isdir(p):
                    found = []
                    for rt, _d, fs in os.walk(p):
                        found += [os.path.join(rt, f) for f in sorted(fs)]
                for f in found:
                    if f not in self.items and self.accept(f):
                        self.items.append(f)
                        self.lb.insert('end', self.label_of(f))
                        if self.preview:
                            self.preview.add(f)
            self.counter()
            if self.preview and self.items and self.preview.cur not in self.items:
                self.lb.selection_clear(0, 'end')
                self.lb.selection_set(0)
                self.preview.show(self.items[0])

        def on_select(self, _e=None):
            sel = self.lb.curselection()
            if sel and self.preview:
                self.preview.show(self.items[sel[0]])

        def move(self, d):
            sel = list(self.lb.curselection())
            if not sel or self.busy:
                return
            for i in (sel if d < 0 else sel[::-1]):
                j = i + d
                if 0 <= j < len(self.items) and j not in sel:
                    self.items[i], self.items[j] = self.items[j], self.items[i]
            self.refresh()
            self.lb.selection_clear(0, 'end')
            for i in sel:
                self.lb.selection_set(min(max(i + d, 0), len(self.items) - 1))

        def sort_names(self):
            if self.busy:
                return
            self.items.sort(key=lambda p: os.path.basename(p).lower())
            self.refresh()

        def pick(self, _e=None):
            self.add_paths(filedialog.askopenfilenames(title='選擇檔案', filetypes=self.filetypes))

        def remove_sel(self):
            if self.busy:
                return
            for i in reversed(self.lb.curselection()):
                self.lb.delete(i)
                self.status.pop(self.items[i], None)
                if self.preview:
                    self.preview.forget(self.items[i])
                del self.items[i]
            self.counter()
            if self.preview and self.preview.cur not in self.items:
                self.preview.show(self.items[0] if self.items else None)

        def clear_all(self):
            if self.busy:
                return
            self.items.clear()
            self.status.clear()
            self.lb.delete(0, 'end')
            self.prog.configure(value=0)
            self.counter()
            if self.preview:
                self.preview.clear()

        # --- 紀錄
        def log(self, s):
            # 合併更新：每 0.2 秒一次把累積的紀錄寫進視窗，避免大量更新塞住畫面
            self._logbuf.append(s)
            if not self._logflag:
                self._logflag = True
                root.after(0, lambda: root.after(200, self._flush_log))

        def _flush_log(self):
            self._logflag = False
            lines, self._logbuf = self._logbuf, []
            if not lines:
                return
            self.out.configure(state='normal')
            self.out.insert('end', '\n'.join(lines) + '\n')
            self.out.see('end')
            self.out.configure(state='disabled')

        def open_out(self):
            if self.outdir and os.path.isdir(self.outdir):
                try:
                    os.startfile(self.outdir)
                except Exception:
                    pass

        # --- 執行
        def go(self):
            if self.busy:
                self.cancel.set()
                self.msg.configure(text='停止中…（目前這個檔案處理完就停）')
                return
            if not self.items:
                messagebox.showinfo('提示', '請先把檔案拖進來，或點選加入')
                return
            try:
                opts = self.get_opts()
            except ValueError as e:
                messagebox.showerror('設定錯誤', str(e))
                return
            files = list(self.items)
            had = any([self.status.pop(f, None) for f in files])
            if had:
                self.refresh()
            self.cancel.clear()
            self.busy = True
            self.start.configure(text='停止')
            self.openb.pack_forget()
            self.prog.configure(value=0)
            self.msg.configure(text='處理中…')

            run = {'t0': time.time(), 'frac': 0.0, 'done': 0, 'on': True, 'cpu': CpuMeter()}
            run['cpu'].read()

            def fmt(sec):
                sec = int(max(0, sec))
                return '%d:%02d' % (sec // 60, sec % 60)

            def tick():
                if not run['on']:
                    return
                el = time.time() - run['t0']
                txt = '處理中…　已進行 %s' % fmt(el)
                f = run['frac']
                if 0.05 <= f < 1:
                    txt += '　預估還要約 %s' % fmt(el * (1 - f) / f)
                c = run['cpu'].read()
                if c is not None:
                    txt += '　CPU %d%%' % round(c)
                self.msg.configure(text='停止中…（目前這個檔案處理完就停）' if self.cancel.is_set() else txt)
                root.after(1000, tick)

            pend = {}
            flag = {'on': False}

            def flush():
                flag['on'] = False
                self.prog.configure(value=run['frac'] * 100)
                got = dict(pend)
                pend.clear()
                if got:
                    idx = {p: k for k, p in enumerate(self.items)}
                    ks = []
                    for p, v in got.items():
                        if v.partition('|')[0] in ('ok', 'fail') and self.status.get(p, '').partition('|')[0] not in ('ok', 'fail'):
                            run['done'] += 1
                        self.status[p] = v
                        if p in idx:
                            ks.append(idx[p])
                    if ks:
                        self.refresh_many(ks)
                        self.lb.see(max(ks))              # 清單跟著打勾的進度往下捲
                    el = max(0.001, time.time() - run['t0'])
                    self.cnt.configure(text='共 %d 個　已完成 %d　%.1f 個/秒' % (len(self.items), run['done'], run['done'] / el))

            def schedule():
                if not flag['on']:
                    flag['on'] = True
                    root.after(0, lambda: root.after(200 if len(self.items) < 300 else 500, flush))

            def progress(frac):
                run['frac'] = frac
                schedule()

            def status(p, kind, text=''):
                pend[p] = '%s|%s' % (kind, text)
                schedule()
            ctx = Ctx(self.log, progress, status, self.cancel)

            def work():
                t0 = time.time()
                try:
                    summary, outdir = self.worker(files, opts, ctx)
                except Exception as e:  # noqa
                    summary, outdir = '錯誤：%s' % e, None
                self.log(summary)

                def fin():
                    flush()
                    self._flush_log()
                    self.counter()
                    run['on'] = False
                    self.busy = False
                    self.start.configure(text=self.start_text)
                    self.msg.configure(text='%s（共 %s）' % (summary, fmt(time.time() - t0)))
                    self.outdir = outdir
                    if outdir:
                        self.openb.pack(side='left', padx=(8, 0), ipady=3)
                root.after(0, fin)
            tick()
            threading.Thread(target=work, daemon=True).start()


    # ------------------------------------------------------------------
    # 送印拆分的「每張紙」縮圖預覽（點一下切換彩色／黑白）
    class SheetPreview:
        def __init__(self, parent, page):
            import base64
            self.b64 = base64.b64encode
            self.page = page
            self.data, self.cur = {}, None
            self.grid = pdf_ops.SheetGrid()
            self.per_var, self.sens_var = None, None
            self._pending = False
            c = card(parent, '每張紙預覽（點一下＝切換彩色／黑白，雙擊＝看大圖）', expand=True)
            leg = tk.Frame(c, bg=CARD)
            leg.pack(fill='x', pady=(0, 4))
            tk.Label(leg, text='■ 彩色紙', bg=CARD, fg='#E8710A', font=(FONT, 10, 'bold')).pack(side='left')
            tk.Label(leg, text='　■ 黑白紙', bg=CARD, fg=SUB, font=(FONT, 10, 'bold')).pack(side='left')
            self.stat = tk.Label(leg, text='', bg=CARD, fg=TXT, font=(FONT, 10))
            self.stat.pack(side='right')
            tk.Label(c, text='自動判斷不對時：直接點縮圖上的紙張，就能在彩色／黑白間切換；也可以在下面輸入頁碼一次改',
                     bg=CARD, fg=ACC, font=(FONT, 9, 'bold'), anchor='w', justify='left').pack(fill='x', pady=(0, 4))
            mr = tk.Frame(c, bg=CARD)
            mr.pack(fill='x', pady=(0, 4))
            tk.Label(mr, text='頁碼', bg=CARD, fg=TXT, font=(FONT, 10)).pack(side='left')
            self.spec = tk.StringVar()
            tk.Entry(mr, textvariable=self.spec, font=(FONT, 10), relief='solid', bd=1, width=16).pack(side='left', padx=6)
            button(mr, '設為彩色', lambda: self.set_spec(True)).pack(side='left')
            button(mr, '設為黑白', lambda: self.set_spec(False)).pack(side='left', padx=6)
            tk.Label(mr, text='例：1-2,7-', bg=CARD, fg=SUB, font=(FONT, 9)).pack(side='left')
            cf = tk.Frame(c, bg=CARD)
            cf.pack(fill='both', expand=True)
            self.cv = tk.Canvas(cf, bg='#EEF1F6', cursor='hand2', highlightthickness=1, highlightbackground=LINE, height=120)
            vs = ttk.Scrollbar(cf, orient='vertical', command=self.cv.yview)
            self.cv.configure(yscrollcommand=vs.set)
            self.cv.pack(side='left', fill='both', expand=True)
            vs.pack(side='right', fill='y')
            self.cv.bind('<Configure>', self.on_resize)
            self.cv.bind('<Button-1>', self.on_click)
            self.cv.bind('<Double-Button-1>', self.on_double)
            self.cv.bind('<MouseWheel>', lambda e: self.cv.yview_scroll(int(-e.delta / 120) * 2, 'units'))
            self.cv.bind('<Button-4>', lambda e: self.cv.yview_scroll(-2, 'units'))
            self.cv.bind('<Button-5>', lambda e: self.cv.yview_scroll(2, 'units'))

        def per(self):
            try:
                return int(self.per_var.get())
            except Exception:
                return 2

        def thr(self):
            try:
                return pdf_ops.SENS[self.sens_var.get()]
            except Exception:
                return pdf_ops.SENS['一般']

        def add(self, p):
            n = pdf_ops.page_count(p) or 0
            d = dict(n=n, fracs=[], thumbs={}, color=set(), done=False, labels=[], err='' if n else '檔案有密碼保護或已損壞')
            self.data[p] = d
            if not n:
                return

            def work():
                try:
                    for i, png, w, h, frac in pdf_ops.analyze(p, cancel=lambda: p not in self.data):
                        d['fracs'].append(frac)
                        root.after(0, lambda i=i, png=png: self.put(p, d, i, png))
                    try:
                        d['labels'] = pdf_ops.page_labels(p)
                    except Exception:
                        d['labels'] = []
                    d['color'] = pdf_ops.auto_color_sheets(d['fracs'], self.per(), self.thr())
                    d['done'] = True
                except Exception as ex:  # noqa
                    d['err'] = '無法分析：%s' % ex
                root.after(0, self.schedule)
            threading.Thread(target=work, daemon=True).start()

        def put(self, p, d, i, png):
            if p in self.data:
                d['thumbs'][i] = tk.PhotoImage(data=self.b64(png))
                if p == self.cur:
                    self.schedule()

        def forget(self, p):
            self.data.pop(p, None)

        def clear(self):
            self.data.clear()
            self.cur = None
            self.schedule()

        def show(self, p):
            self.cur = p
            self.schedule()

        def reauto(self):
            for d in self.data.values():
                if d['done']:
                    d['color'] = pdf_ops.auto_color_sheets(d['fracs'], self.per(), self.thr())
            self.schedule()

        def setall(self, color):
            d = self.data.get(self.cur)
            if d and d['done']:
                d['color'] = set(range(pdf_ops.n_sheets(d['n'], self.per()))) if color else set()
                self.schedule()

        def set_spec(self, color):
            d = self.data.get(self.cur)
            if not d or not d['done']:
                messagebox.showinfo('提示', '請先選一個已分析完的 PDF')
                return
            try:
                sh = pdf_ops.pages_to_sheets(self.spec.get(), d['n'], self.per())
            except ValueError as e:
                messagebox.showerror('頁碼錯誤', str(e))
                return
            if color:
                d['color'] |= sh
            else:
                d['color'] -= sh
            self.schedule()

        def colors_for(self, p):
            """在背景執行緒呼叫：回傳該檔的彩色紙集合（還沒分析完就等或現算）"""
            d = self.data.get(p)
            t0 = time.time()
            while d and not d['done'] and not d['err'] and time.time() - t0 < 120:
                time.sleep(0.2)
            if d and d['done']:
                return set(d['color'])
            fr = [f for *_a, f in pdf_ops.analyze(p)]
            return pdf_ops.auto_color_sheets(fr, self.per(), self.thr())

        def on_resize(self, e):
            self.grid.width = max(e.width - 4, 140)
            self.schedule()

        def schedule(self):
            if not self._pending:
                self._pending = True
                root.after(40, self.redraw)

        def redraw(self):
            self._pending = False
            cv, g = self.cv, self.grid
            g.per = self.per()
            cv.delete('all')
            d = self.data.get(self.cur)
            self.stat.configure(text='')
            if not d:
                cv.create_text(g.width // 2, 50, text='拖入 PDF，這裡會顯示每一張紙', fill=SUB, font=(FONT, 11))
                return
            if d['err']:
                cv.create_text(g.width // 2, 50, text=d['err'], fill=BAD, font=(FONT, 10), width=g.width - 30)
                return
            g.n = d['n']
            for s in range(g.sheets()):
                x, y = g.sheet_pos(s)
                iscol = s in d['color']
                cv.create_rectangle(x + 3, y + 3, x + g.bw - g.gap + 3, y + g.ch - 3,
                                    fill='#FFF1E3' if iscol else '#FFFFFF', outline='#E8710A' if iscol else '#C9D2DD',
                                    width=3 if iscol else 1)
                for k in range(g.per):
                    i = s * g.per + k
                    if i >= d['n']:
                        break
                    px, py = g.page_pos(i)
                    im = d['thumbs'].get(i)
                    if im is not None:
                        cv.create_image(px + g.cw // 2, py + 8 + (g.ch - 46) // 2, image=im)
                    else:
                        cv.create_text(px + g.cw // 2, py + g.ch // 2 - 10, text='…', fill=SUB)
                    cv.create_text(px + g.cw // 2, py + g.ch - 20, text=str(i + 1), fill=TXT, font=(FONT, 9))
                lab = d['labels'][s * g.per] if len(d['labels']) > s * g.per else ''
                multi = len(set(d['labels'])) > 1
                cv.create_text(x + g.bw - g.gap - 6, y + 12, anchor='e',
                               text=((lab + ' ') if multi else '') + ('彩' if iscol else '黑白'),
                               fill='#E8710A' if iscol else SUB, font=(FONT, 9, 'bold'))
            cv.configure(scrollregion=(0, 0, g.width, g.total_height()))
            if d['done']:
                tot = pdf_ops.n_sheets(d['n'], g.per)
                c = len(d['color'])
                zs = sorted(set(d['labels']))
                extra = ('　尺寸：' + '、'.join(zs)) if len(zs) > 1 else ''
                self.stat.configure(text='共 %d 頁／%d 張紙　彩色 %d・黑白 %d%s' % (d['n'], tot, c, tot - c, extra))
            else:
                self.stat.configure(text='分析中…')

        def hit(self, e):
            d = self.data.get(self.cur)
            if not d or not d['done']:
                return None, None, None
            x, y = self.cv.canvasx(e.x), self.cv.canvasy(e.y)
            s = self.grid.hit_sheet(x, y)
            return d, s, x

        def on_click(self, e):
            d, s, _x = self.hit(e)
            if s is not None:
                d['color'] ^= {s}
                self.schedule()

        def on_double(self, e):
            d, s, x = self.hit(e)
            if s is None:
                return
            sx, _ = self.grid.sheet_pos(s)
            k = min(self.grid.per - 1, int((x - sx) // self.grid.cw))
            i = min(s * self.grid.per + k, d['n'] - 1)
            try:
                png = pdf_ops.render_page_png(self.cur, i, 620)
                top = tk.Toplevel(root)
                top.title('第 %d 頁' % (i + 1))
                top.configure(bg=BG)
                img = tk.PhotoImage(data=self.b64(png))
                lab = tk.Label(top, image=img, bg=BG)
                lab.image = img
                lab.pack(padx=10, pady=10)
            except Exception as ex:  # noqa
                messagebox.showerror('預覽失敗', str(ex))

    def out_block(parent, same_text='存在原檔旁邊'):
        v_where, v_dir = tk.StringVar(value='same'), tk.StringVar(value='')
        ttk.Radiobutton(parent, text=same_text, variable=v_where, value='same', style='Card.TRadiobutton').pack(anchor='w', pady=(6, 0))
        r2 = tk.Frame(parent, bg=CARD)
        r2.pack(anchor='w', fill='x')
        ttk.Radiobutton(r2, text='指定資料夾', variable=v_where, value='dir', style='Card.TRadiobutton').pack(side='left')
        tk.Entry(r2, textvariable=v_dir, font=(FONT, 9), relief='solid', bd=1, width=14).pack(
            side='left', fill='x', expand=True, padx=6)

        def choose():
            d = filedialog.askdirectory(title='選擇輸出資料夾')
            if d:
                v_dir.set(d)
                v_where.set('dir')
        button(r2, '選擇…', choose).pack(side='left')

        def get():
            od = v_dir.get().strip() if v_where.get() == 'dir' else None
            if v_where.get() == 'dir' and not od:
                raise ValueError('請選擇輸出資料夾')
            return od
        return get

    # 分頁 4：PDF 合併
    def opts_pdfmerge(parent, page):
        oc = card(parent, '合併設定')
        ttk.Label(oc, text='合併順序＝清單順序（用 ▲▼ 調整，或「依檔名排序」）', style='Sub.TLabel',
                  wraplength=330, justify='left').pack(anchor='w')
        r = tk.Frame(oc, bg=CARD)
        r.pack(anchor='w', pady=(8, 0))
        ttk.Label(r, text='輸出檔名', style='Card.TLabel').pack(side='left')
        v_name = tk.StringVar(value='合併後.pdf')
        tk.Entry(r, textvariable=v_name, font=(FONT, 10), relief='solid', bd=1, width=18).pack(side='left', padx=8)
        v_bm = tk.BooleanVar(value=True)
        ttk.Checkbutton(oc, text='每個來源檔加一個書籤（檔名）', variable=v_bm, style='Card.TCheckbutton').pack(anchor='w', pady=(6, 0))
        g = out_block(oc)
        ttk.Label(oc, text='已有同名檔時自動改名，不會覆蓋', style='Sub.TLabel').pack(anchor='w', pady=(6, 0))

        def get():
            name = v_name.get().strip()
            if not name:
                raise ValueError('請輸入輸出檔名')
            return dict(name=name, bookmarks=v_bm.get(), outdir=g())
        return get

    # 分頁 5：送印拆分
    def opts_print(parent, page):
        pv = page.preview
        oc = card(parent, '設定')
        v_per = tk.IntVar(value=2)
        ttk.Radiobutton(oc, text='雙面列印（一張紙＝2 頁：1-2、3-4…）', variable=v_per, value=2, style='Card.TRadiobutton').pack(anchor='w')
        ttk.Radiobutton(oc, text='單面列印（一張紙＝1 頁）', variable=v_per, value=1, style='Card.TRadiobutton').pack(anchor='w')
        r = tk.Frame(oc, bg=CARD)
        r.pack(anchor='w', pady=(8, 0))
        ttk.Label(r, text='彩色判斷', style='Card.TLabel').pack(side='left')
        v_sens = tk.StringVar(value='一般')
        cb = ttk.Combobox(r, textvariable=v_sens, values=list(pdf_ops.SENS), width=22, state='readonly')
        cb.pack(side='left', padx=8)
        pv.per_var, pv.sens_var = v_per, v_sens
        cb.bind('<<ComboboxSelected>>', lambda e: pv.reauto())
        v_per.trace_add('write', lambda *a: pv.reauto())
        ttk.Label(oc, text='一張紙只要任何一面有彩色，就歸彩色版。判斷不對可在縮圖上點一下改。',
                  style='Sub.TLabel', wraplength=340, justify='left').pack(anchor='w', pady=(4, 0))
        rr = tk.Frame(oc, bg=CARD)
        rr.pack(anchor='w', pady=(8, 0))
        button(rr, '全部彩色', lambda: pv.setall(True)).pack(side='left')
        button(rr, '全部黑白', lambda: pv.setall(False)).pack(side='left', padx=6)
        button(rr, '重新判斷', pv.reauto).pack(side='left')
        v_size = tk.BooleanVar(value=True)
        ttk.Checkbutton(oc, text='依紙張大小分開輸出（A3、A4 混在一起時各自拆出）', variable=v_size,
                        style='Card.TCheckbutton').pack(anchor='w', pady=(8, 0))
        g = out_block(oc)
        ttk.Label(oc, text='輸出到「原檔名_送印」資料夾，檔名如：A4雙面彩色.pdf、A4雙面黑白.pdf（混有 A3 時另有 A3雙面…）；雙面時彩色版奇數頁自動補一張空白頁',
                  style='Sub.TLabel', wraplength=340, justify='left').pack(anchor='w', pady=(6, 0))

        def get():
            return dict(per=v_per.get(), outdir=g(), colors=pv.colors_for, by_size=v_size.get())
        return get

    # ------------------------------------------------------------------
    # 分頁 1：檢測表整理
    def opts_tidy(parent, page=None):
        oc = card(parent, '整理項目')
        v_d1, v_e0, v_fn = tk.BooleanVar(value=True), tk.BooleanVar(value=True), tk.BooleanVar(value=True)
        ttk.Checkbutton(oc, text='刪除 D=1（無損傷）的缺失', variable=v_d1, style='Card.TCheckbutton').pack(anchor='w', pady=1)
        ttk.Checkbutton(oc, text='刪除 E=0 的缺失', variable=v_e0, style='Card.TCheckbutton').pack(anchor='w', pady=1)
        ttk.Checkbutton(oc, text='每個缺失只留 遠／近 兩張照片', variable=v_fn, style='Card.TCheckbutton').pack(anchor='w', pady=1)
        ttk.Label(oc, text='前面的總表一律保留，不會被刪', style='Sub.TLabel').pack(anchor='w')
        v_pdf = tk.BooleanVar(value=False)
        ttk.Checkbutton(oc, text='同時生成 PDF（放在 Word 旁邊）', variable=v_pdf, style='Card.TCheckbutton').pack(anchor='w', pady=(6, 0))
        pf = tk.Frame(oc, bg=CARD)
        pf.pack(anchor='w', pady=(6, 0))
        ttk.Label(pf, text='每頁缺失數', style='Card.TLabel').pack(side='left')
        v_pp = tk.IntVar(value=3)
        ttk.Spinbox(pf, from_=1, to=6, width=4, textvariable=v_pp, font=(FONT, 10)).pack(side='left', padx=8)

        cc = card(parent, '只保留符合條件的缺失')
        v_cf = tk.BooleanVar(value=False)
        ttk.Checkbutton(cc, text='啟用條件篩選（其餘刪除）', variable=v_cf, style='Card.TCheckbutton').pack(anchor='w')
        rows = []
        for i in range(3):
            r = tk.Frame(cc, bg=CARD)
            r.pack(anchor='w', pady=2)
            f_, o_, n_ = tk.StringVar(value=['D', 'R', 'U'][i]), tk.StringVar(value='>='), tk.StringVar(value='')
            ttk.Label(r, text='條件%d' % (i + 1), style='Card.TLabel').pack(side='left', padx=(0, 8))
            ttk.Combobox(r, textvariable=f_, values=['D', 'E', 'R', 'U'], width=3, state='readonly').pack(side='left')
            ttk.Combobox(r, textvariable=o_, values=['=', '>=', '<=', '>', '<'], width=3, state='readonly').pack(side='left', padx=4)
            tk.Entry(r, textvariable=n_, width=4, font=(FONT, 10), relief='solid', bd=1).pack(side='left')
            rows.append((f_, o_, n_))
        v_m = tk.StringVar(value='any')
        mr = tk.Frame(cc, bg=CARD)
        mr.pack(anchor='w', pady=(3, 0))
        ttk.Radiobutton(mr, text='任一符合', variable=v_m, value='any', style='Card.TRadiobutton').pack(side='left')
        ttk.Radiobutton(mr, text='全部符合', variable=v_m, value='all', style='Card.TRadiobutton').pack(side='left', padx=10)
        ttk.Label(cc, text='數字留空的條件不使用', style='Sub.TLabel').pack(anchor='w')

        sc = card(parent, '缺失排序')
        v_sort = tk.StringVar(value='ASP')
        for val, t1, t2 in (('ASP', 'ASP 交錯', 'A1 → S1 → P1 → S2 → P2 … → A2'),
                            ('PS', 'PS 交錯', 'A1 → P1 → S1 → P2 → S2 … → A2'),
                            ('none', '不排序', '保持原本順序')):
            ttk.Radiobutton(sc, text=t1 + '　' + t2, variable=v_sort, value=val, style='Card.TRadiobutton').pack(anchor='w')

        def get():
            conds = []
            if v_cf.get():
                for f_, o_, n_ in rows:
                    if n_.get().strip():
                        conds.append('%s%s%s' % (f_.get(), o_.get(), n_.get().strip()))
                conds = bridge_tidy.parse_conds(conds)
            try:
                pp = max(1, int(v_pp.get()))
            except Exception:
                pp = 3
            return dict(d1=v_d1.get(), e0=v_e0.get(), fn=v_fn.get(), pp=pp, sort=v_sort.get(),
                        conds=conds, match=v_m.get(), pdf=v_pdf.get())
        return get

    # 分頁 2：Word 轉 PDF
    def opts_pdf(parent, page=None):
        oc = card(parent, '輸出')
        v_where, v_dir = tk.StringVar(value='same'), tk.StringVar(value='')
        ttk.Radiobutton(oc, text='存在原檔旁邊', variable=v_where, value='same', style='Card.TRadiobutton').pack(anchor='w')
        r2 = tk.Frame(oc, bg=CARD)
        r2.pack(anchor='w', fill='x')
        ttk.Radiobutton(r2, text='指定資料夾', variable=v_where, value='dir', style='Card.TRadiobutton').pack(side='left')
        tk.Entry(r2, textvariable=v_dir, font=(FONT, 9), relief='solid', bd=1, width=14).pack(
            side='left', fill='x', expand=True, padx=6)

        def choose():
            d = filedialog.askdirectory(title='選擇輸出資料夾')
            if d:
                v_dir.set(d)
                v_where.set('dir')
        button(r2, '選擇…', choose).pack(side='left')
        r3 = tk.Frame(oc, bg=CARD)
        r3.pack(anchor='w', pady=(8, 0))
        ttk.Label(r3, text='同時轉幾個（建議 2～3）', style='Card.TLabel').pack(side='left')
        v_jobs = tk.IntVar(value=2)
        ttk.Spinbox(r3, from_=1, to=4, width=3, textvariable=v_jobs, font=(FONT, 10)).pack(side='left', padx=8)
        v_over = tk.BooleanVar(value=True)
        ttk.Checkbutton(oc, text='已有同名 PDF 時覆蓋', variable=v_over, style='Card.TCheckbutton').pack(anchor='w', pady=(6, 0))
        e = word2pdf.pick_engine()
        ttk.Label(oc, text=('轉換引擎：' + e.name) if e else '⚠ 找不到 Word 或 LibreOffice',
                  style='Sub.TLabel').pack(anchor='w', pady=(4, 0))
        ttk.Label(oc, text='每個檔案各自產生一個 PDF，不合併', style='Sub.TLabel').pack(anchor='w')

        def get():
            od = v_dir.get().strip() if v_where.get() == 'dir' else None
            if v_where.get() == 'dir' and not od:
                raise ValueError('請選擇輸出資料夾')
            try:
                jobs = max(1, min(4, int(v_jobs.get())))
            except Exception:
                jobs = 2
            return dict(outdir=od, jobs=jobs, over=v_over.get())
        return get

    # 分頁 3：基本資料整理
    def opts_merge(parent, page=None):
        oc = card(parent, '選項')
        r1 = tk.Frame(oc, bg=CARD)
        r1.pack(anchor='w')
        ttk.Label(r1, text='只保留最新照片張數', style='Card.TLabel').pack(side='left')
        v_keep = tk.IntVar(value=4)
        ttk.Spinbox(r1, from_=1, to=20, width=4, textvariable=v_keep, font=(FONT, 10)).pack(side='left', padx=8)
        ttk.Label(oc, text='依「拍照日期」，最新的優先', style='Sub.TLabel').pack(anchor='w')
        ttk.Label(oc, text='照片會自動下載並嵌入 Word（需連網）', style='Sub.TLabel').pack(anchor='w', pady=(6, 0))
        v_pdf = tk.BooleanVar(value=False)
        ttk.Checkbutton(oc, text='同時生成 PDF（放在 Word 旁邊）', variable=v_pdf, style='Card.TCheckbutton').pack(anchor='w', pady=(6, 0))
        v_where, v_dir = tk.StringVar(value='same'), tk.StringVar(value='')
        ttk.Radiobutton(oc, text='存在壓縮檔旁邊', variable=v_where, value='same', style='Card.TRadiobutton').pack(anchor='w', pady=(6, 0))
        r2 = tk.Frame(oc, bg=CARD)
        r2.pack(anchor='w', fill='x')
        ttk.Radiobutton(r2, text='指定資料夾', variable=v_where, value='dir', style='Card.TRadiobutton').pack(side='left')
        tk.Entry(r2, textvariable=v_dir, font=(FONT, 9), relief='solid', bd=1, width=14).pack(
            side='left', fill='x', expand=True, padx=6)

        def choose():
            d = filedialog.askdirectory(title='選擇輸出資料夾')
            if d:
                v_dir.set(d)
                v_where.set('dir')
        button(r2, '選擇…', choose).pack(side='left')
        e = basic_merge.pick_engine()
        ttk.Label(oc, text=('轉換引擎：' + e.name) if e else '⚠ 找不到 Word 或 LibreOffice',
                  style='Sub.TLabel').pack(anchor='w', pady=(4, 0))
        ttk.Label(oc, text='合併順序：基本→構件→橋孔→橋墩→擴建', style='Sub.TLabel').pack(anchor='w')

        def get():
            od = v_dir.get().strip() if v_where.get() == 'dir' else None
            if v_where.get() == 'dir' and not od:
                raise ValueError('請選擇輸出資料夾')
            try:
                keep = max(1, int(v_keep.get()))
            except Exception:
                keep = 4
            return dict(outdir=od, keep=keep, embed=True, pdf=v_pdf.get())
        return get

    # 分頁 6：CAD 轉 PDF
    def opts_cad(parent, page=None):
        oc = card(parent, '輸出')
        g = out_block(oc, '存在圖檔旁邊')
        ids = cad_pdf.list_progids()
        r = tk.Frame(oc, bg=CARD)
        r.pack(anchor='w', pady=(8, 0))
        ttk.Label(r, text='progeCAD 版本', style='Card.TLabel').pack(side='left')
        v_id = tk.StringVar(value=cad_pdf.default_progid())
        ttk.Combobox(r, textvariable=v_id, values=ids, width=26, state='readonly').pack(side='left', padx=8)
        ttk.Label(oc, text=('偵測到 %d 個 progeCAD 介面' % len(ids)) if ids else '⚠ 找不到 progeCAD',
                  style='Sub.TLabel').pack(anchor='w', pady=(4, 0))
        v_quiet = tk.BooleanVar(value=True)
        ttk.Checkbutton(oc, text='安靜模式：最小化 progeCAD、把跳出的對話框藏起來', variable=v_quiet,
                        style='Card.TCheckbutton').pack(anchor='w', pady=(6, 0))
        ttk.Label(oc, text='每個版面輸出成一頁，合併成「圖檔名.pdf」；紙張、出圖型式表沿用圖面版面的設定。'
                           '執行時 progeCAD 會自己打開並操作，請不要碰滑鼠鍵盤，一個檔案約數十秒。',
                  style='Sub.TLabel', wraplength=340, justify='left').pack(anchor='w', pady=(6, 0))

        def get():
            if not v_id.get():
                raise ValueError('找不到 progeCAD，無法轉換')
            return dict(outdir=g(), progid=v_id.get(), quiet=v_quiet.get())
        return get

    def opts_photo(parent, page=None):
        oc = card(parent, '壓縮大小')
        sizes = {'約 700 KB（推薦）': 700, '約 500 KB': 500, '約 1 MB': 1000, '約 300 KB': 300}
        v_size = tk.StringVar(value='約 700 KB（推薦）')
        ttk.Combobox(oc, textvariable=v_size, values=list(sizes), width=22, state='readonly').pack(anchor='w')
        g = out_block(oc, '存在原檔旁的「壓縮後」資料夾')
        ttk.Label(oc, text='解析度不會改變。可拖入照片、資料夾或 Word／PPT／Excel，原檔不會被改動。',
                  style='Sub.TLabel', wraplength=340, justify='left').pack(anchor='w', pady=(6, 0))

        def get():
            return dict(outdir=g(), target_kb=sizes.get(v_size.get(), 700), edge=0, quality=50, max_kb=0,
                        workers=photo_compress.default_workers(), skip=True)
        return get

    def opts_inspect(parent, page=None):
        oc = card(parent, '檢查時期')
        v_mode = tk.StringVar(value='pre')
        ttk.Radiobutton(oc, text='汛期前（全部項目）', variable=v_mode, value='pre', style='Card.TRadiobutton').pack(anchor='w')
        ttk.Radiobutton(oc, text='汛期後（只看河道、橋台、橋墩、保護設施）', variable=v_mode, value='post',
                        style='Card.TRadiobutton').pack(anchor='w')
        g = out_block(oc, '存在原檔旁邊')
        rp = os.path.join(updater.data_root(), '檢查規則.json')

        def get():
            return dict(mode=v_mode.get(), outdir=g(), rules=rp if os.path.exists(rp) else None)
        return get

    pages = [
        Page('檢測表整理', '刪除無損傷缺失・條件篩選・只留遠近照片・依位置排序・每頁固定缺失數',
             '把檢測表 Word 檔拖進這裡', '或點一下選擇檔案（.docx，可一次多個）',
             [('Word 檔', '*.docx')],
             lambda p: p.lower().endswith('.docx') and not os.path.basename(p).startswith('~$'),
             opts_tidy, work_tidy, '開始整理'),
        Page('Word 轉 PDF', '多檔拖入，各自轉成各自的 PDF，不合併',
             '把 Word 檔或資料夾拖進這裡', '或點一下選擇檔案（.docx .doc .docm .rtf）',
             [('Word 檔', '*.docx *.doc *.docm *.rtf *.odt')],
             lambda p: bool(word2pdf.collect([p])), opts_pdf, work_pdf, '開始轉換'),
        Page('基本資料整理', '系統匯出的壓縮檔 → 單一 Word，只留最新的照片',
             '把壓縮檔拖進這裡', '或點一下選擇檔案（.zip，可一次多個；也可拖資料夾）',
             [('壓縮檔', '*.zip')],
             lambda p: p.lower().endswith('.zip') or os.path.isdir(p), opts_merge, work_merge, '開始整理'),
        Page('PDF 合併', '多個 PDF 依清單順序合成一個，可加書籤',
             '把 PDF 或資料夾拖進這裡', '或點一下選擇檔案（.pdf，可一次多個）',
             [('PDF', '*.pdf')], lambda p: p.lower().endswith('.pdf'),
             opts_pdfmerge, work_pdfmerge, '開始合併', reorder=True, expand_pdf=True),
        Page('送印拆分', '依「一張紙」拆成 彩色版／黑白版，彩色版奇數頁自動補空白頁',
             '把 PDF 拖進這裡', '或點一下選擇檔案（.pdf，可一次多個）',
             [('PDF', '*.pdf')], lambda p: p.lower().endswith('.pdf'),
             opts_print, work_print, '開始拆分', preview=True, expand_pdf=True),
        Page('CAD 轉 PDF（測試）', '【測試中】用 progeCAD 把 DWG 每個版面輸出成一頁，合併成一個多頁 PDF',
             '把 DWG 圖檔拖進這裡', '或點一下選擇檔案（.dwg，可一次多個）',
             [('DWG 圖檔', '*.dwg')], lambda p: p.lower().endswith('.dwg') and not os.path.basename(p).startswith('~'),
             opts_cad, work_cad, '開始轉換', expand_pdf=True),
        Page('照片壓縮（高速）', '把照片壓到約 700 KB（多核心高速，解析度不變）：圖檔、資料夾、Word／PPT／Excel 內嵌照片',
             '把照片、資料夾或 Word／PPT／Excel 拖進這裡', '或點一下選擇檔案（.jpg .png .docx .pptx .xlsx，可一次多個）',
             [('照片或 Office 檔', '*.jpg *.jpeg *.png *.bmp *.tif *.tiff *.webp *.docx *.docm *.pptx *.pptm *.xlsx *.xlsm')], photo_compress.is_target,
             opts_photo, work_photo, '開始壓縮', expand_pdf=True),
        Page('檢查檢測紀錄', '讀檢測成果 PDF：找出數值、單位、工法、封面、明細卡的錯誤，並比對檢測員意見',
             '把檢測成果 PDF 拖進這裡', '或點一下選擇檔案（.pdf，可一次多個）',
             [('PDF', '*.pdf')], lambda p: p.lower().endswith('.pdf'), opts_inspect, work_inspect, '開始檢查'),
    ]

    # ---------- 首頁（功能方格）
    home = tk.Frame(content, bg=BG)
    cur = {'p': None}

    def rr(cv, x1, y1, x2, y2, r, **kw):
        pts = [x1 + r, y1, x2 - r, y1, x2, y1, x2, y1 + r, x2, y2 - r, x2, y2, x2 - r, y2,
               x1 + r, y2, x1, y2, x1, y2 - r, x1, y1 + r, x1, y1]
        return cv.create_polygon(pts, smooth=True, **kw)

    def draw_icon(cv, kind, dk, lt):
        W = 'white'
        rr(cv, 2, 2, 74, 74, 16, fill=lt, outline='')
        ln = dict(fill=dk, width=3, capstyle='round', joinstyle='round')
        if kind == 'tidy':
            rr(cv, 21, 17, 55, 63, 4, fill=W, outline=dk, width=2)
            rr(cv, 30, 11, 46, 22, 3, fill=dk, outline='')
            for y in (33, 44, 55):
                cv.create_line(26, y, 29, y + 3, 33, y - 3, **ln)
                cv.create_line(37, y, 50, y, fill=dk, width=3, capstyle='round')
        elif kind == 'word':
            for x0, t in ((9, 'W'), (43, 'PDF')):
                cv.create_polygon(x0, 17, x0 + 17, 17, x0 + 24, 24, x0 + 24, 59, x0, 59, fill=W, outline=dk, width=2)
                cv.create_text(x0 + 12, 42, text=t, fill=dk, font=(FONT, 9 if t == 'PDF' else 13, 'bold'))
            cv.create_line(35, 38, 41, 38, 38, 35, **ln)
            cv.create_line(41, 38, 38, 41, **ln)
        elif kind == 'basic':
            cv.create_polygon(12, 22, 30, 22, 35, 28, 64, 28, 64, 60, 12, 60, fill=W, outline=dk, width=2)
            cv.create_polygon(19, 54, 30, 40, 38, 49, 44, 43, 57, 54, fill=dk, outline='')
            cv.create_oval(47, 33, 55, 41, fill=dk, outline='')
        elif kind == 'merge':
            for y in (11, 42):
                cv.create_rectangle(9, y, 29, y + 23, fill=W, outline=dk, width=2)
                cv.create_line(14, y + 8, 24, y + 8, fill=dk, width=2)
                cv.create_line(14, y + 14, 22, y + 14, fill=dk, width=2)
            cv.create_line(32, 24, 41, 35, **ln)
            cv.create_line(32, 52, 41, 41, **ln)
            cv.create_rectangle(44, 20, 66, 56, fill=W, outline=dk, width=2)
            for y in (29, 36, 43):
                cv.create_line(49, y, 61, y, fill=dk, width=2)
        elif kind == 'print':
            cv.create_rectangle(23, 12, 53, 31, fill=W, outline=dk, width=2)
            rr(cv, 10, 28, 66, 54, 6, fill=dk, outline='')
            cv.create_rectangle(23, 44, 53, 64, fill=W, outline=dk, width=2)
            for y in (50, 56):
                cv.create_line(28, y, 48, y, fill=dk, width=2)
            cv.create_oval(55, 34, 60, 39, fill=W, outline='')
        elif kind == 'cad':
            cv.create_polygon(13, 62, 13, 14, 62, 62, fill=W, outline=dk, width=3, joinstyle='round')
            cv.create_polygon(24, 53, 24, 36, 41, 53, fill=lt, outline=dk, width=2)
            for k in range(5):
                x = 22 + k * 8
                cv.create_line(x, 62, x, 57 if k % 2 else 55, fill=dk, width=2)
        elif kind == 'check':
            rr(cv, 17, 11, 53, 63, 4, fill=W, outline=dk, width=2)
            for y in (22, 32, 42):
                cv.create_line(24, y, 46, y, fill=dk, width=2)
            cv.create_oval(38, 38, 62, 62, fill=W, outline=dk, width=3)
            cv.create_line(55, 55, 66, 66, **ln)
        elif kind == 'photo':
            rr(cv, 10, 14, 66, 58, 5, fill=W, outline=dk, width=2)
            cv.create_polygon(14, 54, 28, 34, 38, 46, 46, 38, 62, 54, fill=dk, outline='')
            cv.create_oval(46, 20, 56, 30, fill=dk, outline='')
            cv.create_oval(44, 44, 68, 68, fill=W, outline=dk, width=2)
            cv.create_line(56, 49, 56, 62, **ln)
            cv.create_line(50, 57, 56, 63, 62, 57, **ln)

    tiles = [
        ('檢測表整理', 'tidy', '#1E5799', '#E3EEFB', '刪除無損傷缺失、條件篩選、只留遠近照片、依位置排序'),
        ('Word 轉 PDF', 'word', '#C0504D', '#F9E3E2', '多個 Word 檔批次轉成各自的 PDF'),
        ('基本資料整理', 'basic', '#2E8B57', '#E0F2E8', '系統匯出的壓縮檔合併成單一 Word'),
        ('PDF 合併', 'merge', '#6C4DB8', '#ECE6F8', '多個 PDF 依順序合成一個，可加書籤'),
        ('送印拆分', 'print', '#D9822B', '#FBEBDA', '依一張紙拆成彩色版／黑白版，自動補空白頁'),
        ('CAD 轉 PDF（測試）', 'cad', '#0F8B8D', '#DFF3F3', '用 progeCAD 把每個版面輸出成一頁'),
        ('照片壓縮（高速）', 'photo', '#C2417A', '#FBE4EF', '多核心高速壓到約 700 KB，解析度不變，圖檔與 Word／PPT／Excel 內嵌都可以'),
        ('檢查檢測紀錄', 'check', '#B8860B', '#FBF1D6', '檢查成果 PDF 的數值與單位，比對檢測員意見，可選汛期前／後'),
    ]
    grid = tk.Frame(home, bg=BG)
    grid.pack(fill='both', expand=True, padx=26, pady=(22, 10))
    COLS = 4
    for k in range(COLS):
        grid.columnconfigure(k, weight=1, uniform='tile')
    for k in range((len(tiles) + COLS - 1) // COLS):
        grid.rowconfigure(k, weight=1, uniform='trow')

    wraps = []

    def on_grid(e):
        w = max(100, e.width // COLS - 40)
        for d in wraps:
            d.configure(wraplength=w)
    grid.bind('<Configure>', on_grid)

    def make_tile(idx, title, kind, dk, lt, desc):
        f = tk.Frame(grid, bg=CARD, highlightthickness=1, highlightbackground=LINE, cursor='hand2')
        f.grid(row=idx // COLS, column=idx % COLS, sticky='nsew', padx=7, pady=7)
        cv = tk.Canvas(f, width=76, height=76, bg=CARD, highlightthickness=0, cursor='hand2')
        cv.pack(pady=(18, 6))
        draw_icon(cv, kind, dk, lt)
        t = tk.Label(f, text=title, bg=CARD, fg=TXT, font=(FONT, 12, 'bold'), cursor='hand2')
        t.pack()
        d = tk.Label(f, text=desc, bg=CARD, fg=SUB, font=(FONT, 9), wraplength=170, justify='center', cursor='hand2')
        d.pack(padx=10, pady=(4, 14))
        parts = (f, cv, t, d)
        wraps.append(d)

        def enter(_e=None):
            for w in parts:
                w.configure(bg=lt)
            f.configure(highlightbackground=dk)

        def leave(_e=None):
            for w in parts:
                w.configure(bg=CARD)
            f.configure(highlightbackground=LINE)
        for w in parts:
            w.bind('<Enter>', enter)
            w.bind('<Leave>', leave)
            w.bind('<Button-1>', lambda e, n=title: show(by_title[n]))
    by_title = {p.title: i for i, p in enumerate(pages)}
    for idx, (title, kind, dk, lt, desc) in enumerate(tiles):
        make_tile(idx, title, kind, dk, lt, desc)

    def show_home():
        if cur['p'] is not None:
            cur['p'].frame.pack_forget()
            cur['p'] = None
        back.pack_forget()
        home.pack(fill='both', expand=True)
        sub.configure(text='選一個功能開始（也可以把檔案拖進該功能頁面）')

    def show(i):
        home.pack_forget()
        if cur['p'] is not None:
            cur['p'].frame.pack_forget()
        cur['p'] = pages[i]
        back.pack(side='left', padx=(0, 14), before=title_lbl)
        pages[i].frame.pack(fill='both', expand=True)
        sub.configure(text=pages[i].title + '　—　' + pages[i].subtitle)

    back.bind('<Button-1>', lambda e: show_home())
    show_home()

    # ---------- 線上更新（GitHub Releases）
    def app_dirs():
        exe_dir = os.path.dirname(sys.executable) if updater.is_frozen() else os.path.dirname(os.path.abspath(__file__))
        return [exe_dir, getattr(sys, '_MEIPASS', None)]

    def do_module_update(info):
        top = tk.Toplevel(root)
        top.title('更新中')
        top.configure(bg=BG)
        top.geometry('360x110')
        top.resizable(False, False)
        lab = tk.Label(top, text='正在下載 v%s …' % info['version'], bg=BG, fg=TXT, font=(FONT, 11))
        lab.pack(pady=(18, 8))
        pb = ttk.Progressbar(top, style='Acc.Horizontal.TProgressbar', maximum=100, length=300)
        pb.pack()

        def work():
            try:
                updater.apply_modules(info, lambda f: root.after(0, lambda: pb.configure(value=f * 100)))
            except Exception as e:  # noqa
                msg = str(e)
                root.after(0, lambda: (top.destroy(), messagebox.showerror('更新失敗', msg)))
                return

            def restart():
                lab.configure(text='更新完成，程式即將重新開啟…')
                try:
                    updater.relaunch()
                except Exception as e:  # noqa
                    top.destroy()
                    messagebox.showinfo('更新完成', '請手動關閉再重新開啟程式。（%s）' % e)
                    return
                root.after(600, lambda: os._exit(0))
            root.after(0, restart)
        threading.Thread(target=work, daemon=True).start()

    def do_update(info):
        if any(p.busy for p in pages):
            messagebox.showinfo('稍後再更新', '目前有工作正在進行，請等它跑完，再按右上角「檢查更新」。')
            return
        if info.get('kind') == 'modules':
            return do_module_update(info)
        if not updater.is_frozen() or not info['url']:
            import webbrowser
            webbrowser.open(info['page'])
            messagebox.showinfo('請手動更新', '已開啟下載頁面。' + ('' if info['url'] else '（這個版本沒有附 EXE 檔）') +
                                '\n目前是用 Python 直接執行，請自行下載新版取代。')
            return
        top = tk.Toplevel(root)
        top.title('更新中')
        top.configure(bg=BG)
        top.geometry('360x110')
        top.resizable(False, False)
        lab = tk.Label(top, text='正在下載 v%s …' % info['version'], bg=BG, fg=TXT, font=(FONT, 11))
        lab.pack(pady=(18, 8))
        pb = ttk.Progressbar(top, style='Acc.Horizontal.TProgressbar', maximum=100, length=300)
        pb.pack()
        dest = os.path.join(os.path.dirname(sys.executable), os.path.basename(sys.executable) + '.new')
        try:
            open(dest, 'ab').close()
        except Exception:
            import tempfile
            dest = os.path.join(tempfile.gettempdir(), 'toolbox_new.exe')

        def work():
            try:
                updater.download(info['url'], dest, lambda f: root.after(0, lambda: pb.configure(value=f * 100)),
                                 sha256=info['sha256'])
            except Exception as e:  # noqa
                msg = str(e)
                root.after(0, lambda: (top.destroy(), messagebox.showerror('更新失敗', msg)))
                return

            def go_restart():
                try:
                    updater.apply_update(dest)
                except Exception as e:  # noqa
                    top.destroy()
                    messagebox.showerror('更新失敗', str(e))
                    return
                lab.configure(text='下載完成，程式即將重新開啟…')
                root.after(600, lambda: os._exit(0))
            root.after(0, go_restart)
        threading.Thread(target=work, daemon=True).start()

    def on_info(info, manual):
        if info is None:
            if manual:
                messagebox.showinfo('檢查更新', '目前已是最新版本（v%s）。' % VERSION)
            return
        notes = info['notes'][:600] + ('…' if len(info['notes']) > 600 else '')
        tail = ('要現在更新嗎？更新完會自動重新開啟。' if info.get('kind') == 'modules'
                else '這次更新需要換新的 EXE，要現在下載並更新嗎？')
        if messagebox.askyesno('有新版本', '發現新版本 v%s（目前 v%s）\n\n%s\n\n%s' % (
                info['version'], VERSION, notes or '（沒有更新說明）', tail)):
            do_update(info)

    def check_update(manual=False):
        repo = updater.read_repo(app_dirs())
        if not repo:
            if manual:
                messagebox.showinfo('尚未設定更新來源', '還沒設定線上更新來源。\n請在程式旁邊放 update_repo.txt，第一行寫 帳號/專案名（見「線上更新說明.txt」）。')
            return

        def work():
            try:
                m = updater.check_modules(repo, VERSION)
                info = updater.check(repo, VERSION) if (m is not None and m['kind'] == 'exe') else m
            except Exception as e:  # noqa
                msg = str(e)
                if manual:
                    root.after(0, lambda: messagebox.showwarning('檢查更新失敗', '連不上更新來源：%s' % msg))
                return
            root.after(0, lambda: on_info(info, manual))
        threading.Thread(target=work, daemon=True).start()

    def boot_ok():       # 能走到這裡＝更新版載入成功，移除「開機中」旗標
        try:
            os.remove(os.path.join(updater.data_root(), '.booting'))
        except OSError:
            pass
    root.after(800, boot_ok)          # 視窗都出來了就算開機成功（不再等 3 秒）

    def on_close():       # 關閉視窗＝連背景壓縮程序一起結束，不留殘留
        boot_ok()         # 能正常關閉＝更新版沒壞，一定要清掉旗標（不管開多久）
        boot_log('關閉')
        for p in pages:
            p.cancel.set()
        photo_compress.kill_all()
        try:
            root.destroy()
        finally:
            os._exit(0)
    root.protocol('WM_DELETE_WINDOW', on_close)

    upd_btn.bind('<Button-1>', lambda e: check_update(True))
    root.after(2000, lambda: check_update(False))
    if not dnd:
        pages[0].log('提示：未安裝 tkinterdnd2，不能拖曳，請點選區塊加入檔案。')
    root.mainloop()


if __name__ == '__main__':
    run_gui()
