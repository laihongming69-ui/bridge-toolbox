# -*- coding: utf-8 -*-
"""
Word 轉 PDF 批次工具（高速、可拖曳、多檔各自轉成各自的 PDF，不合併）

引擎：
  1. Microsoft Word（優先；排版與 Word 完全一致）。用同一個隱藏的 Word 連續轉，
     不會每個檔案都重開 Word；可同時開 2～4 個 Word 並行加速。
  2. LibreOffice（沒有安裝 Word 時自動改用；排版可能與 Word 略有不同）

用法：雙擊「執行.bat」開啟視窗；或命令列
      python word2pdf.py a.docx b.docx --out D:\\PDF --jobs 3
"""
import argparse
import glob
import os
import queue
import shutil
import subprocess
import sys
import tempfile
import threading
import time

EXTS = ('.docx', '.doc', '.docm', '.rtf', '.odt')


def collect(paths):
    """展開資料夾、過濾 Word 檔、去掉 ~$ 暫存檔與重複"""
    out, seen = [], set()
    for p in paths:
        p = os.path.abspath(p.strip('"'))
        cand = []
        if os.path.isdir(p):
            for root, _d, fs in os.walk(p):
                cand += [os.path.join(root, f) for f in sorted(fs)]
        else:
            cand = [p]
        for f in cand:
            b = os.path.basename(f)
            if f.lower().endswith(EXTS) and not b.startswith('~$') and f not in seen:
                seen.add(f)
                out.append(f)
    return out


def unique_target(src, outdir, taken, overwrite):
    d = outdir or os.path.dirname(src)
    stem = os.path.splitext(os.path.basename(src))[0]
    t = os.path.join(d, stem + '.pdf')
    n = 1
    while t.lower() in taken or (not overwrite and os.path.exists(t)):
        n += 1
        t = os.path.join(d, '%s (%d).pdf' % (stem, n))
    taken.add(t.lower())
    return t


# ----------------------------------------------------------------------------
# 引擎
# ----------------------------------------------------------------------------
class WordEngine:
    name = 'Word'

    @staticmethod
    def available():
        if os.name != 'nt':
            return False
        try:
            import win32com.client  # noqa
            import winreg
            winreg.CloseKey(winreg.OpenKey(winreg.HKEY_CLASSES_ROOT, 'Word.Application'))
            return True
        except Exception:
            return False

    def __init__(self):
        import pythoncom
        import win32com.client
        pythoncom.CoInitialize()
        self.pythoncom = pythoncom
        self.app = win32com.client.DispatchEx('Word.Application')
        self.app.Visible = False
        self.app.DisplayAlerts = 0
        try:
            self.app.AutomationSecurity = 3  # 不執行巨集
        except Exception:
            pass
        try:
            self.app.Options.UpdateFieldsAtPrint = False
            self.app.Options.CheckSpellingAsYouType = False
            self.app.Options.CheckGrammarAsYouType = False
        except Exception:
            pass

    def convert(self, src, dst):
        # Open(檔名, 不問轉換, 唯讀, 不加入最近使用)
        doc = self.app.Documents.Open(src, False, True, False)
        try:
            try:
                # 檔名, PDF(17), 不自動開啟, 最佳化=0(列印品質)
                doc.ExportAsFixedFormat(dst, 17, False, 0)
            except Exception:
                doc.SaveAs2(dst, 17)
        finally:
            doc.Close(0)

    def close(self):
        try:
            self.app.Quit(0)
        except Exception:
            pass
        try:
            self.pythoncom.CoUninitialize()
        except Exception:
            pass


def find_soffice():
    for n in ('soffice', 'soffice.exe', 'libreoffice'):
        p = shutil.which(n)
        if p:
            return p
    for base in (os.environ.get('ProgramFiles', r'C:\Program Files'),
                 os.environ.get('ProgramFiles(x86)', r'C:\Program Files (x86)')):
        for p in glob.glob(os.path.join(base, 'LibreOffice*', 'program', 'soffice.exe')):
            return p
    return None


class LibreEngine:
    name = 'LibreOffice'

    @staticmethod
    def available():
        return find_soffice() is not None

    def __init__(self):
        self.exe = find_soffice()
        self.profile = tempfile.mkdtemp(prefix='lo_profile_')

    def convert(self, src, dst):
        tmp = tempfile.mkdtemp(prefix='lo_out_')
        try:
            uri = 'file:///' + self.profile.replace('\\', '/').lstrip('/')
            cmd = [self.exe, '-env:UserInstallation=' + uri, '--headless', '--norestore',
                   '--convert-to', 'pdf', '--outdir', tmp, src]
            flags = 0x08000000 if os.name == 'nt' else 0  # 不跳出黑視窗
            subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                           timeout=600, creationflags=flags)
            out = os.path.join(tmp, os.path.splitext(os.path.basename(src))[0] + '.pdf')
            if not os.path.exists(out):
                raise RuntimeError('LibreOffice 沒有產生 PDF')
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            if os.path.exists(dst):
                os.remove(dst)
            shutil.move(out, dst)
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    def close(self):
        shutil.rmtree(self.profile, ignore_errors=True)


def pick_engine():
    if WordEngine.available():
        return WordEngine
    if LibreEngine.available():
        return LibreEngine
    return None


# ----------------------------------------------------------------------------
# 批次
# ----------------------------------------------------------------------------
def convert_batch(files, outdir=None, jobs=2, overwrite=True, on_event=None, cancel=None, engine=None):
    """
    on_event(kind, index, text)：kind = 'start' | 'ok' | 'fail' | 'info'
    回傳 (成功數, 失敗數, 秒數, 目標資料夾集合)
    """
    emit = on_event or (lambda *a: None)
    cancel = cancel or threading.Event()
    Engine = engine or pick_engine()
    if Engine is None:
        raise RuntimeError('找不到 Microsoft Word 或 LibreOffice，無法轉檔')
    if Engine is LibreEngine:
        jobs = max(1, min(jobs, 2))
    taken = set()
    targets = [unique_target(f, outdir, taken, overwrite) for f in files]
    q = queue.Queue()
    for i in range(len(files)):
        q.put(i)
    stat = {'ok': 0, 'fail': 0}
    lock = threading.Lock()
    t0 = time.time()
    emit('info', -1, '使用 %s，同時 %d 個程序' % (Engine.name, min(jobs, len(files)) or 1))

    def worker():
        try:
            eng = Engine()
        except Exception as e:  # noqa
            emit('info', -1, '啟動 %s 失敗：%s' % (Engine.name, e))
            return
        try:
            while not cancel.is_set():
                try:
                    i = q.get_nowait()
                except queue.Empty:
                    break
                emit('start', i, '')
                s = time.time()
                try:
                    os.makedirs(os.path.dirname(targets[i]), exist_ok=True)
                    eng.convert(files[i], targets[i])
                    with lock:
                        stat['ok'] += 1
                    emit('ok', i, '%.1f 秒' % (time.time() - s))
                except Exception as e:  # noqa
                    with lock:
                        stat['fail'] += 1
                    emit('fail', i, str(e).splitlines()[0][:80] if str(e) else '失敗')
        finally:
            eng.close()

    ths = [threading.Thread(target=worker, daemon=True) for _ in range(max(1, min(jobs, len(files))))]
    for t in ths:
        t.start()
    for t in ths:
        t.join()
    return stat['ok'], stat['fail'], time.time() - t0, {os.path.dirname(t) for t in targets}


# ----------------------------------------------------------------------------
# 視窗
# ----------------------------------------------------------------------------
def run_gui():
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk

    try:
        from tkinterdnd2 import TkinterDnD, DND_FILES
        root = TkinterDnD.Tk()
        dnd = True
    except Exception:
        root = tk.Tk()
        dnd = False

    BG, CARD, LINE = '#F6F7FA', '#FFFFFF', '#E1E5EE'
    ACC, ACC_D, ACC_L = '#D32F2F', '#A92323', '#FDECEC'
    TXT, SUB, OKC = '#1F2937', '#6B7280', '#2E7D32'
    FONT = 'Microsoft JhengHei UI'

    root.title('Word 轉 PDF 批次轉換')
    root.geometry('860x700')
    root.minsize(760, 620)
    root.configure(bg=BG)
    try:
        base = getattr(sys, '_MEIPASS', os.path.dirname(os.path.abspath(__file__)))
        root.iconbitmap(os.path.join(base, 'icon.ico'))
    except Exception:
        pass

    st = ttk.Style()
    try:
        st.theme_use('clam')
    except Exception:
        pass
    st.configure('Card.TCheckbutton', background=CARD, foreground=TXT, font=(FONT, 10))
    st.map('Card.TCheckbutton', background=[('active', CARD)])
    st.configure('Card.TRadiobutton', background=CARD, foreground=TXT, font=(FONT, 10))
    st.map('Card.TRadiobutton', background=[('active', CARD)])
    st.configure('Card.TLabel', background=CARD, foreground=TXT, font=(FONT, 10))
    st.configure('Acc.Horizontal.TProgressbar', troughcolor=LINE, background=ACC, bordercolor=LINE,
                 lightcolor=ACC, darkcolor=ACC)

    items = []          # 路徑
    status = {}         # 路徑 -> 狀態字串
    cancel = threading.Event()
    busy = {'v': False}
    last_dirs = {'v': set()}

    head = tk.Frame(root, bg=ACC)
    head.pack(fill='x')
    tk.Label(head, text='Word 轉 PDF', bg=ACC, fg='white', font=(FONT, 18, 'bold')).pack(
        anchor='w', padx=24, pady=(14, 0))
    tk.Label(head, text='一次拖入多個檔案，各自轉成各自的 PDF，不合併', bg=ACC, fg='#FAD4D4',
             font=(FONT, 10)).pack(anchor='w', padx=24, pady=(2, 14))

    body = tk.Frame(root, bg=BG)
    body.pack(fill='both', expand=True, padx=20, pady=14)

    def card(parent, title, expand=False):
        o = tk.Frame(parent, bg=CARD, highlightthickness=1, highlightbackground=LINE)
        o.pack(fill='both' if expand else 'x', expand=expand, pady=(0, 10))
        tk.Label(o, text=title, bg=CARD, fg=TXT, font=(FONT, 11, 'bold')).pack(anchor='w', padx=14, pady=(10, 4))
        i = tk.Frame(o, bg=CARD)
        i.pack(fill='both', expand=True, padx=14, pady=(0, 12))
        return i

    def button(parent, text, cmd, primary=False, size=10):
        bgc, hov = (ACC, ACC_D) if primary else (ACC_L, '#F9D3D3')
        b = tk.Label(parent, text=text, bg=bgc, fg='white' if primary else ACC,
                     font=(FONT, size, 'bold'), padx=14, pady=7, cursor='hand2')
        b.bind('<Enter>', lambda e: b.configure(bg=hov))
        b.bind('<Leave>', lambda e: b.configure(bg=bgc))
        b.bind('<Button-1>', lambda e: cmd())
        return b

    fc = card(body, '檔案', expand=True)
    zone = tk.Canvas(fc, height=110, bg=ACC_L, highlightthickness=0, cursor='hand2')
    zone.pack(fill='x')

    def draw(_e=None):
        zone.delete('all')
        w, h = zone.winfo_width(), zone.winfo_height()
        zone.create_rectangle(6, 6, w - 6, h - 6, outline=ACC, dash=(6, 4), width=2)
        zone.create_text(w // 2, h // 2 - 13, text='把 Word 檔或資料夾拖進這裡' if dnd else '點這裡選擇 Word 檔',
                         fill=ACC, font=(FONT, 14, 'bold'))
        zone.create_text(w // 2, h // 2 + 16, text='或點一下選擇檔案（.docx .doc .docm .rtf）',
                         fill=SUB, font=(FONT, 10))
    zone.bind('<Configure>', draw)

    lf = tk.Frame(fc, bg=CARD)
    lf.pack(fill='both', expand=True, pady=(10, 0))
    lb = tk.Listbox(lf, bd=0, highlightthickness=1, highlightbackground=LINE, font=(FONT, 10),
                    activestyle='none', selectmode='extended', selectbackground=ACC_L, selectforeground=TXT)
    sb = ttk.Scrollbar(lf, orient='vertical', command=lb.yview)
    lb.configure(yscrollcommand=sb.set)
    lb.pack(side='left', fill='both', expand=True)
    sb.pack(side='right', fill='y')

    def label_of(p):
        s = status.get(p, '')
        mark = {'run': '… ', 'ok': '✓ ', 'fail': '✗ '}.get(s.split('|')[0], '　')
        extra = s.split('|', 1)[1] if '|' in s else ''
        return '%s%s    %s' % (mark, os.path.basename(p), extra)

    def refresh(i=None):
        rng = range(len(items)) if i is None else [i]
        for k in rng:
            lb.delete(k)
            lb.insert(k, label_of(items[k]))
            col = {'ok': OKC, 'fail': ACC}.get(status.get(items[k], '').split('|')[0], TXT)
            lb.itemconfig(k, foreground=col)

    def add_paths(paths):
        n = 0
        for f in collect(paths):
            if f not in items:
                items.append(f)
                lb.insert('end', label_of(f))
                n += 1
        counter()
        return n

    def pick(_e=None):
        add_paths(filedialog.askopenfilenames(title='選擇 Word 檔',
                                              filetypes=[('Word 檔', '*.docx *.doc *.docm *.rtf')]))

    def remove_sel():
        if busy['v']:
            return
        for i in reversed(lb.curselection()):
            lb.delete(i)
            status.pop(items[i], None)
            del items[i]
        counter()

    def clear_all():
        if busy['v']:
            return
        items.clear()
        status.clear()
        lb.delete(0, 'end')
        prog.configure(value=0)
        counter()

    zone.bind('<Button-1>', pick)
    lb.bind('<Delete>', lambda e: remove_sel())
    br = tk.Frame(fc, bg=CARD)
    br.pack(fill='x', pady=(8, 0))
    button(br, '移除選取', remove_sel).pack(side='left')
    button(br, '清空', clear_all).pack(side='left', padx=8)
    cnt = tk.Label(br, text='', bg=CARD, fg=SUB, font=(FONT, 10))
    cnt.pack(side='right')

    def counter():
        cnt.configure(text='共 %d 個檔案' % len(items))

    if dnd:
        def on_drop(e):
            add_paths(root.tk.splitlist(e.data))
        for w in (zone, lb):
            w.drop_target_register(DND_FILES)
            w.dnd_bind('<<Drop>>', on_drop)

    oc = card(body, '輸出')
    v_where = tk.StringVar(value='same')
    v_dir = tk.StringVar(value='')
    ttk.Radiobutton(oc, text='存在原檔旁邊', variable=v_where, value='same', style='Card.TRadiobutton').pack(anchor='w')
    r2 = tk.Frame(oc, bg=CARD)
    r2.pack(anchor='w', fill='x')
    ttk.Radiobutton(r2, text='存到指定資料夾', variable=v_where, value='dir', style='Card.TRadiobutton').pack(side='left')
    tk.Entry(r2, textvariable=v_dir, font=(FONT, 9), relief='solid', bd=1).pack(side='left', fill='x', expand=True, padx=8)

    def choose():
        d = filedialog.askdirectory(title='選擇輸出資料夾')
        if d:
            v_dir.set(d)
            v_where.set('dir')
    button(r2, '選擇…', choose).pack(side='left')
    r3 = tk.Frame(oc, bg=CARD)
    r3.pack(anchor='w', pady=(8, 0))
    ttk.Label(r3, text='同時轉幾個（越多越快，建議 2～3）', style='Card.TLabel').pack(side='left')
    v_jobs = tk.IntVar(value=2)
    ttk.Spinbox(r3, from_=1, to=4, width=3, textvariable=v_jobs, font=(FONT, 10)).pack(side='left', padx=8)
    v_over = tk.BooleanVar(value=True)
    ttk.Checkbutton(oc, text='已有同名 PDF 時覆蓋（取消勾選則自動改名）', variable=v_over,
                    style='Card.TCheckbutton').pack(anchor='w', pady=(6, 0))

    bot = tk.Frame(body, bg=BG)
    bot.pack(fill='x')
    prog = ttk.Progressbar(bot, style='Acc.Horizontal.TProgressbar', maximum=100)
    prog.pack(fill='x', pady=(0, 8))
    msg = tk.Label(bot, text='', bg=BG, fg=SUB, font=(FONT, 10), anchor='w')
    msg.pack(fill='x', pady=(0, 6))
    row = tk.Frame(bot, bg=BG)
    row.pack(fill='x')
    start = button(row, '開始轉換', lambda: go(), primary=True, size=13)
    start.pack(side='left', fill='x', expand=True, ipady=3)
    openb = button(row, '開啟輸出資料夾', lambda: open_out())

    def open_out():
        for d in list(last_dirs['v'])[:1]:
            try:
                os.startfile(d)
            except Exception:
                pass

    def post(fn):
        root.after(0, fn)

    def go():
        if busy['v']:
            cancel.set()
            msg.configure(text='停止中…（目前這幾個檔案轉完就停）')
            return
        if not items:
            messagebox.showinfo('提示', '請先拖入或選擇 Word 檔')
            return
        outdir = v_dir.get().strip() if v_where.get() == 'dir' else None
        if v_where.get() == 'dir' and not outdir:
            messagebox.showinfo('提示', '請選擇輸出資料夾')
            return
        try:
            jobs = max(1, min(4, int(v_jobs.get())))
        except Exception:
            jobs = 2
        files = list(items)
        for f in files:
            status.pop(f, None)
        refresh()
        cancel.clear()
        busy['v'] = True
        done = {'n': 0}
        start.configure(text='停止')
        openb.pack_forget()
        prog.configure(value=0)
        msg.configure(text='轉換中…')

        def ev(kind, i, text):
            def f():
                if kind == 'info':
                    msg.configure(text=text)
                    return
                p = files[i]
                if kind == 'start':
                    status[p] = 'run'
                else:
                    status[p] = '%s|%s' % (kind, text)
                    done['n'] += 1
                    prog.configure(value=done['n'] * 100 / len(files))
                refresh(items.index(p) if p in items else None)
            post(f)

        def work():
            try:
                ok, bad, secs, dirs = convert_batch(files, outdir, jobs, v_over.get(), ev, cancel)
                last_dirs['v'] = dirs
                t = '完成：成功 %d 個%s，共 %.1f 秒' % (ok, '、失敗 %d 個' % bad if bad else '', secs)
            except Exception as e:  # noqa
                t = '錯誤：%s' % e

            def fin():
                busy['v'] = False
                start.configure(text='開始轉換')
                msg.configure(text=t)
                if last_dirs['v']:
                    openb.pack(side='left', padx=(8, 0), ipady=3)
            post(fin)
        threading.Thread(target=work, daemon=True).start()

    eng = pick_engine()
    msg.configure(text=('轉換引擎：' + eng.name) if eng else '⚠ 找不到 Microsoft Word 或 LibreOffice，無法轉檔')
    if not dnd:
        msg.configure(text=msg.cget('text') + '　（未安裝 tkinterdnd2，不能拖曳，請點選加入）')
    counter()
    root.mainloop()


def main():
    ap = argparse.ArgumentParser(description='Word 轉 PDF 批次工具')
    ap.add_argument('files', nargs='*')
    ap.add_argument('--out', help='輸出資料夾（預設存在原檔旁）')
    ap.add_argument('--jobs', type=int, default=2)
    ap.add_argument('--no-overwrite', action='store_true')
    a = ap.parse_args()
    if not a.files:
        run_gui()
        return
    fs = collect(a.files)

    def ev(kind, i, text):
        if kind == 'info':
            print(text)
        elif kind != 'start':
            print(('OK  ' if kind == 'ok' else 'FAIL'), os.path.basename(fs[i]), text)
    ok, bad, secs, _ = convert_batch(fs, a.out, a.jobs, not a.no_overwrite, ev)
    print('成功 %d、失敗 %d、%.1f 秒' % (ok, bad, secs))


if __name__ == '__main__':
    main()
